# SQRM v2 — Saksham Digi QR Menu
## Complete Setup & Developer Guide

> **Version:** 2.0.0
> **Domain:** sqrm.srpdigitalstudios.qzz.io
> **Stack:** React 18 + TypeScript + Vite + Tailwind CSS + shadcn/ui + React Router v6
> **Storage:** Browser localStorage (zero-backend, production-ready SPA)

---

## Table of Contents

1. [Overview](#1-overview)
2. [Project Structure](#2-project-structure)
3. [Local Development Setup](#3-local-development-setup)
4. [Authentication](#4-authentication)
5. [Admin Credentials](#5-admin-credentials)
6. [Feature Reference by Role](#6-feature-reference-by-role)
7. [Subscription Plans](#7-subscription-plans)
8. [URL / Route Reference](#8-url--route-reference)
9. [Order Flow](#9-order-flow)
10. [QR Code System](#10-qr-code-system)
11. [PDF Bill System](#11-pdf-bill-system)
12. [Order Sound Notifications](#12-order-sound-notifications)
13. [PWA & Offline Support](#13-pwa--offline-support)
14. [Dark Mode](#14-dark-mode)
15. [Deployment](#15-deployment)
16. [Security Notes](#16-security-notes)

---

## 1. Overview

**Saksham Digi QR Menu (SQRM)** is a fully client-side React SPA for restaurant digital menus.

### For Restaurant Owners
- Login with Google (simulated for local dev — replace with real Google OAuth before production)
- Create restaurants, upload menus with images and categories
- Generate branded QR codes for tables (download as PNG or PDF)
- Receive and manage customer orders with real-time sound notifications
- Download PDF bills per order
- View revenue and order analytics dashboard

### For Customers
- Scan QR code → browse menu → add to cart → place order
- Real-time order status tracking: Pending → Accepted → Completed
- Download PDF bill after completion
- Leave star ratings and written reviews

### For Super Admin
- URL: `/admin1` (NOT `/admin`)
- Manage all owners, assign subscription plans
- Suspend / reactivate restaurants
- Moderate customer reviews
- Configure site settings (name, logo, support contact, maintenance mode)

---

## 2. Project Structure

```
src/
├── components/
│   ├── common/       Logo, StarRating, OfflineBanner, RouteGuard, PageMeta
│   ├── layouts/      PublicLayout, PublicHeader, PublicFooter, OwnerLayout, AdminLayout
│   └── ui/           shadcn/ui components (DO NOT modify)
├── hooks/            useTheme
├── pages/
│   ├── admin/        AdminDashboard, AdminRestaurantsPage, AdminOwnersPage,
│   │                 AdminReviewsPage, AdminSettingsPage, AdminLoginPage
│   ├── owner/        OwnerDashboard, OwnerRestaurantsPage, OwnerProfilePage,
│   │                 RestaurantFormPage, MenuManagementPage, OrdersPage,
│   │                 QRPage, OwnerLoginPage, VerifyPhonePage
│   └── public/       HomePage, RestaurantsPage, RestaurantProfilePage,
│                     MenuPage, CartPage, OrderTrackingPage
├── store/
│   └── index.ts      All localStorage stores + admin credential validation
├── types/
│   └── index.ts      TypeScript interfaces
├── routes.tsx        React Router route definitions
└── App.tsx           BrowserRouter + Toaster + route rendering
public/
├── manifest.json     PWA manifest
├── sw.js             Service worker (cache-first)
├── ding.mp3          New order notification sound  ← ADD THIS FILE
└── offline.html      Offline fallback page
tasks/
└── GUIDE.md          This file
```

---

## 3. Local Development Setup

### Prerequisites
- Node.js 18+
- pnpm (recommended) or npm

### Steps

```bash
# 1. Install dependencies
pnpm install

# 2. Start dev server
pnpm dev
# Opens at http://localhost:5173

# 3. Build for production
pnpm build
# Output in dist/

# 4. Lint check
pnpm lint
```

### Add ding.mp3

Place your notification sound at `public/ding.mp3`.
If missing, the app falls back to a Web Audio API 880 Hz sine tone automatically.

---

## 4. Authentication

### Owner Login — Google Sign-In

The login page (`/owner/login`) shows a single **"Continue with Google"** button.

**Current state (testing):** Simulates Google OAuth with fake profiles for local development.

**To connect real Google OAuth before going live:**

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create OAuth 2.0 credentials (Web application)
3. Add Authorized redirect URIs:
   ```
   https://sqrm.srpdigitalstudios.qzz.io/owner/login
   ```
4. Replace `handleGoogleLogin` in `src/pages/owner/OwnerLoginPage.tsx` with real Google Identity Services:
   ```ts
   google.accounts.id.initialize({
     client_id: 'YOUR_GOOGLE_CLIENT_ID',
     callback: (response) => {
       // decode response.credential JWT
       // extract email + name from payload
       // call ownerStore.save() / ownerStore.setCurrent()
     }
   });
   google.accounts.id.prompt();
   ```

### Admin Login — Email + Password

Admin login is at `/admin1` only. Credentials use **exact string match** — no SQL, no bypass.

---

## 5. Admin Credentials

| Field    | Value                                  |
|----------|----------------------------------------|
| Email    | `sqrmadmin@srpdigitalstudios.qzz.io`   |
| Password | `sqrm15112010@`                        |
| URL      | `/admin1`                              |

> `1=1` and all injection patterns are **rejected** — validation is pure string equality.
> To change credentials: update `ADMIN_EMAIL` and `ADMIN_PASS` in `src/store/index.ts`.

---

## 6. Feature Reference by Role

### Customer (no login required)

| Feature | Available |
|---------|-----------|
| Browse restaurants | Yes |
| View restaurant profile + reviews | Yes |
| Browse menu by category | Yes |
| Add items to cart | Yes |
| Place order (Cash / Online) | Yes |
| Real-time order status tracking | Yes |
| Download PDF bill | Yes (on completion) |
| Submit star rating + review | Yes (on completion) |

### Restaurant Owner

| Feature | Free | Basic | Premium |
|---------|------|-------|---------|
| Restaurants | 1 | 5 | Unlimited |
| Menu Items | 20 | Unlimited | Unlimited |
| QR Code Generation | Yes | Yes | Yes |
| QR PNG + PDF Download | Yes | Yes | Yes |
| Live Order Management | Yes | Yes | Yes |
| Sound Notifications | Yes | Yes | Yes |
| PDF Receipts | Yes | Yes | Yes |
| Ratings and Reviews | Yes | Yes | Yes |
| Revenue Dashboard | Yes | Yes | Yes |
| Monthly Analytics | No | Yes | Yes |
| Best Selling Items | No | Yes | Yes |
| Menu Categories | Yes | Yes | Yes |
| Lifetime Analytics | No | No | Yes |
| Popular Category Insights | No | No | Yes |
| Most Active Hours Report | No | No | Yes |
| Custom Restaurant Theme | No | No | Yes |

### Admin

| Feature | Available |
|---------|-----------|
| View all owners + plans | Yes |
| Assign / change owner plan | Yes |
| Suspend / reactivate restaurants | Yes |
| Delete reviews | Yes |
| Edit site name + logo | Yes |
| Set support phone + email | Yes |
| Enable maintenance mode | Yes |

---

## 7. Subscription Plans

Plans are assigned by the super admin. Assigning sets a 30-day expiry automatically.

| Plan | Price | Restaurants | Menu Items |
|------|-------|-------------|------------|
| Free | 0 | 1 | 20 |
| Basic | 29/mo | 5 | Unlimited |
| Premium | 49/mo | Unlimited | Unlimited |

Owners upgrade via WhatsApp: profile page shows an "Upgrade via WhatsApp" button
pointing to the support number set in Admin Settings.

When a plan expires the system auto-falls back to free limits.
Re-assigning any plan resets the 30-day clock.

---

## 8. URL / Route Reference

### Public Routes

| URL | Page |
|-----|------|
| `/` | Homepage |
| `/restaurants` | Browse all restaurants |
| `/r/:slug` | Restaurant public profile + reviews |
| `/m/:slug` | Menu page (cart + ordering) |
| `/cart` | Cart and order placement |
| `/order/:orderId` | Order tracking |
| `/privacy-policy` | Privacy policy |
| `/cookie-policy` | Cookie policy |

### Owner Routes (require Google login)

| URL | Page |
|-----|------|
| `/owner/login` | Google sign-in |
| `/owner/verify-phone` | Phone verification (new accounts) |
| `/owner/dashboard` | Owner home |
| `/owner/restaurants` | My restaurants list |
| `/owner/restaurants/create` | Create restaurant |
| `/owner/restaurants/:id/edit` | Edit restaurant |
| `/owner/restaurants/:id/menu` | Menu management |
| `/owner/restaurants/:id/orders` | Live orders |
| `/owner/restaurants/:id/qr` | QR code generator |
| `/owner/profile` | Profile + plan upgrade |

### Admin Routes (require admin session)

| URL | Page |
|-----|------|
| `/admin1` | Admin login |
| `/admin1/dashboard` | Stats overview |
| `/admin1/restaurants` | Restaurant management |
| `/admin1/owners` | Owner list |
| `/admin1/reviews` | Review moderation |
| `/admin1/settings` | Site settings |

> Navigating to `/admin` returns 404. Admin URL is `/admin1` only.

---

## 9. Order Flow

```
Customer scans QR → /m/{random-16-char-slug}
     ↓
Browses menu, adds to cart
     ↓
/cart — enters name + phone, selects Cash or Online payment
     ↓
Order placed → redirected to /order/:orderId
     ↓
Status: PENDING  (polls localStorage every 3s)
     ↓
Owner hears ding + sees toast in /owner/restaurants/:id/orders
     ↓
Owner clicks Accept or Reject
     ↓
[Accepted] → status ACCEPTED
[Rejected] → status REJECTED + reason shown to customer
     ↓
Owner clicks Mark as Completed
     ↓
Status COMPLETED → PDF bill available → review dialog shown
```

### Order Status Values

| Status | Meaning |
|--------|---------|
| pending | Submitted, awaiting owner action |
| accepted | Owner confirmed the order |
| rejected | Owner declined with reason |
| completed | Order delivered, bill available |

---

## 10. QR Code System

QR codes are generated client-side using `qrcode.react`.

### QR URL Format

Every restaurant gets a random 16-character alphanumeric slug:
```
https://sqrm.srpdigitalstudios.qzz.io/m/AsOnl097ncdjk89u
```

Characters used: A-Z a-z 2-9 (no 0, 1, O, I, l to avoid visual confusion).

### QR Download Options
- PNG — html2canvas renders the branded card, saved as PNG
- PDF — jspdf wraps the canvas, saved as PDF

---

## 11. PDF Bill System

Bills are generated client-side using `jspdf`. No server required.

### Bill Includes
- Restaurant logo (top center)
- Restaurant name, location, phone
- Order ID, date/time, payment method
- Customer name
- Itemized table: Item, Qty, Amount
- Bold total row
- Disclaimer footer

### How to Trigger
- Owner: orders page → Download Bill on any completed order
- Customer: order tracking page → Download Bill after status = completed

---

## 12. Order Sound Notifications

New order alerts use two layers:

1. Primary: `public/ding.mp3` via HTML5 Audio API
2. Fallback: Web Audio API generates an 880 Hz sine tone

The orders page polls every 3 seconds. When a new pending order is found, sound plays and a toast appears.

Add `public/ding.mp3` — any short sound (0.5–2 seconds) works.

---

## 13. PWA and Offline Support

### Features
- Install prompt — "Install App" button in header when `beforeinstallprompt` fires
- Offline banner — red fixed banner when `navigator.onLine` is false
- Service worker — cache-first for static assets

### PWA Manifest
Located at `public/manifest.json`. Update name, short_name, icons, start_url for your domain.

### Update cache version on each deploy
In `public/sw.js`:
```js
const CACHE_NAME = 'sqrm-v3'; // increment this
```

---

## 14. Dark Mode

Toggled by the sun/moon button in every header (public, owner, admin).
Preference persisted in localStorage under `sqrm_theme`.
Default is system preference (`prefers-color-scheme`).

Design tokens: dark navy #0B1120, off-white #FAFAF8, orange primary #F97316, amber accents #F59E0B.

---

## 15. Deployment

### Static Host (Netlify / Vercel / GitHub Pages)

```bash
pnpm build
# Deploy dist/ folder
```

SPA redirect rule required — all 404s must serve index.html:

**Netlify** — `public/_redirects`:
```
/*  /index.html  200
```

**Vercel** — `vercel.json`:
```json
{ "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }] }
```

**Apache** — `.htaccess` in `dist/`:
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^ index.html [L]
```

**Nginx:**
```nginx
location / { try_files $uri $uri/ /index.html; }
```

### Moving admin credentials to env vars (recommended for production)

In `.env`:
```
VITE_ADMIN_EMAIL=sqrmadmin@srpdigitalstudios.qzz.io
VITE_ADMIN_PASS=sqrm15112010@
```

In `src/store/index.ts`:
```ts
const ADMIN_EMAIL = import.meta.env.VITE_ADMIN_EMAIL;
const ADMIN_PASS  = import.meta.env.VITE_ADMIN_PASS;
```

---

## 16. Security Notes

- Admin credentials: exact string equality — no regex, no SQL, no injection possible
- `1=1` and all bypass patterns are rejected
- Admin session stored in localStorage under `sqrm_admin_session`
- All data is per-browser and per-domain — not shared across devices
- No API keys exposed in the frontend
- Google OAuth client_secret must be kept server-side (never in frontend code)
- Maintenance mode blocks all public routes; admin session bypasses it
