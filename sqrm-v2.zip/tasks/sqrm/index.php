<?php
/**
 * Front Controller / Router
 * All requests pass through index.php
 */

// Bootstrap
require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/google.php';
require_once __DIR__ . '/includes/Database.php';
require_once __DIR__ . '/includes/Auth.php';
require_once __DIR__ . '/includes/Settings.php';
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/ImageUpload.php';

Auth::startSession();

// Maintenance mode check (allow admin1 through)
$uri = strtok($_SERVER['REQUEST_URI'], '?');
$uri = '/' . trim($uri, '/');

$isAdminRoute = str_starts_with($uri, '/admin1');

if (!$isAdminRoute && Settings::isMaintenanceMode()) {
 require __DIR__ . '/app/views/shared/maintenance.php';
 exit;
}

// Simple router
$method = $_SERVER['REQUEST_METHOD'];
$segments = explode('/', trim($uri, '/'));
$seg0 = $segments[0] ?? '';
$seg1 = $segments[1] ?? '';
$seg2 = $segments[2] ?? '';
$seg3 = $segments[3] ?? '';

// Route matching
switch (true) {

 // ── Home ──────────────────────────────────────────────
 case $uri === '/' || $uri === '':
 require __DIR__ . '/app/controllers/HomeController.php';
 HomeController::index();
 break;

 // ── Public restaurants list ───────────────────────────
 case $uri === '/restaurants':
 require __DIR__ . '/app/controllers/PublicController.php';
 PublicController::restaurants();
 break;

 // ── Public restaurant profile ─────────────────────────
 case $seg0 === 'r' && $seg1:
 require __DIR__ . '/app/controllers/PublicController.php';
 PublicController::restaurantProfile($seg1);
 break;

 // ── Public menu ───────────────────────────────────────
 case $seg0 === 'm' && $seg1:
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::publicMenu($seg1);
 break;

 // ── Cart / order ──────────────────────────────────────
 case $uri === '/cart':
 require __DIR__ . '/app/controllers/OrderController.php';
 OrderController::cart();
 break;

 case $seg0 === 'order' && $seg1:
 require __DIR__ . '/app/controllers/OrderController.php';
 OrderController::trackOrder($seg1);
 break;

 // ── Owner Auth ────────────────────────────────────────
 case $uri === '/owner/login':
 require __DIR__ . '/app/controllers/AuthController.php';
 AuthController::ownerLogin();
 break;

 case $uri === '/auth/google':
 require __DIR__ . '/app/controllers/AuthController.php';
 AuthController::googleRedirect();
 break;

 case $uri === '/auth/google/callback':
 require __DIR__ . '/app/controllers/AuthController.php';
 AuthController::googleCallback();
 break;

 case $uri === '/owner/verify-phone':
 require __DIR__ . '/app/controllers/AuthController.php';
 AuthController::verifyPhone();
 break;

 case $uri === '/owner/logout':
 require __DIR__ . '/app/controllers/AuthController.php';
 AuthController::ownerLogout();
 break;

 // ── Owner Dashboard ───────────────────────────────────
 case $uri === '/owner/dashboard':
 require __DIR__ . '/app/controllers/OwnerController.php';
 OwnerController::dashboard();
 break;

 case $uri === '/owner/profile':
 require __DIR__ . '/app/controllers/OwnerController.php';
 OwnerController::profile();
 break;

 case $uri === '/owner/delete-account' && $method === 'POST':
 require __DIR__ . '/app/controllers/OwnerController.php';
 OwnerController::deleteAccount();
 break;

 // ── Restaurants Management ────────────────────────────
 case $uri === '/owner/restaurants':
 require __DIR__ . '/app/controllers/RestaurantController.php';
 RestaurantController::index();
 break;

 case $uri === '/owner/restaurants/create':
 require __DIR__ . '/app/controllers/RestaurantController.php';
 RestaurantController::create();
 break;

 case $seg0 === 'owner' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'edit':
 require __DIR__ . '/app/controllers/RestaurantController.php';
 RestaurantController::edit((int)$seg2);
 break;

 case $seg0 === 'owner' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'delete':
 require __DIR__ . '/app/controllers/RestaurantController.php';
 RestaurantController::delete((int)$seg2);
 break;

 // ── Menu Management ───────────────────────────────────
 case $seg0 === 'owner' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'menu':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::manage((int)$seg2);
 break;

 case $seg0 === 'owner' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'qr':
 require __DIR__ . '/app/controllers/QRController.php';
 QRController::show((int)$seg2);
 break;

 case $seg0 === 'owner' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'orders':
 require __DIR__ . '/app/controllers/OrderController.php';
 OrderController::ownerOrders((int)$seg2);
 break;

 // ── API endpoints ─────────────────────────────────────
 case $uri === '/api/order/status':
 require __DIR__ . '/app/controllers/OrderController.php';
 OrderController::apiStatus();
 break;

 case $uri === '/api/order/place':
 require __DIR__ . '/app/controllers/OrderController.php';
 OrderController::apiPlace();
 break;

 case $uri === '/api/order/update':
 require __DIR__ . '/app/controllers/OrderController.php';
 OrderController::apiUpdate();
 break;

 case $uri === '/api/review/submit':
 require __DIR__ . '/app/controllers/PublicController.php';
 PublicController::apiSubmitReview();
 break;

 case $uri === '/api/orders/pending':
 require __DIR__ . '/app/controllers/OrderController.php';
 OrderController::apiPendingCount();
 break;

 case $uri === '/api/menu/items':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::apiItems();
 break;

 case $uri === '/api/menu/category/add':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::apiAddCategory();
 break;

 case $uri === '/api/menu/category/delete':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::apiDeleteCategory();
 break;

 case $uri === '/api/menu/item/add':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::apiAddItem();
 break;

 case $uri === '/api/menu/item/delete':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::apiDeleteItem();
 break;

 case $uri === '/api/menu/item/edit':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::apiEditItem();
 break;

 // ── Admin ─────────────────────────────────────────────
 case $uri === '/admin':
 http_response_code(404);
 require __DIR__ . '/app/views/shared/404.php';
 break;

 case $uri === '/admin1' || $uri === '/admin1/login':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::login();
 break;

 case $uri === '/admin1/logout':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::logout();
 break;

 case $uri === '/admin1/dashboard':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::dashboard();
 break;

 case $uri === '/admin1/owners':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::owners();
 break;

 case $uri === '/admin1/owners/assign-plan' && $method === 'POST':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::assignPlan();
 break;

 case $seg0 === 'admin1' && $seg1 === 'owners' && is_numeric($seg2):
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::ownerDetail((int)$seg2);
 break;

 case $uri === '/admin1/restaurants':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::restaurants();
 break;

 case $seg0 === 'admin1' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'suspend' && $method === 'POST':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::suspendRestaurant((int)$seg2);
 break;

 case $seg0 === 'admin1' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'reactivate' && $method === 'POST':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::reactivateRestaurant((int)$seg2);
 break;

 case $seg0 === 'admin1' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'reviews':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::restaurantReviews((int)$seg2);
 break;

 case $uri === '/admin1/reviews':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::reviews();
 break;

 case $uri === '/admin1/reviews/delete' && $method === 'POST':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::deleteReview();
 break;

 case $uri === '/admin1/settings':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::settings();
 break;

 case $uri === '/admin1/settings/maintenance' && $method === 'POST':
 require __DIR__ . '/app/controllers/AdminController.php';
 AdminController::maintenancePost();
 break;

 // ── Menu form routes (owner) ───────────────────────────
 case $seg0 === 'owner' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'menu' && ($segments[4] ?? '') === 'add' && $method === 'POST':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::addItem((int)$seg2);
 break;

 case $seg0 === 'owner' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'menu' && is_numeric($segments[4] ?? '') && ($segments[5] ?? '') === 'edit':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::editItem((int)$seg2, (int)$segments[4]);
 break;

 case $seg0 === 'owner' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'menu' && is_numeric($segments[4] ?? '') && ($segments[5] ?? '') === 'delete' && $method === 'POST':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::deleteItem((int)$seg2, (int)$segments[4]);
 break;

 case $seg0 === 'owner' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'categories' && ($segments[4] ?? '') === 'add' && $method === 'POST':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::addCategory((int)$seg2);
 break;

 case $seg0 === 'owner' && $seg1 === 'restaurants' && is_numeric($seg2) && $seg3 === 'categories' && is_numeric($segments[4] ?? '') && ($segments[5] ?? '') === 'delete' && $method === 'POST':
 require __DIR__ . '/app/controllers/MenuController.php';
 MenuController::deleteCategory((int)$seg2, (int)$segments[4]);
 break;

 // ── Legal ─────────────────────────────────────────────
 case $uri === '/privacy-policy':
 require __DIR__ . '/app/views/home/privacy.php';
 break;

 case $uri === '/cookie-policy':
 require __DIR__ . '/app/views/home/cookie.php';
 break;

 // ── Sitemap ───────────────────────────────────────────
 case $uri === '/sitemap.xml':
 require __DIR__ . '/app/controllers/HomeController.php';
 HomeController::sitemap();
 break;

 // ── API: bill HTML for PDF generation ─────────────────
 case $uri === '/api/order/bill':
 require __DIR__ . '/app/controllers/OrderController.php';
 OrderController::apiBill();
 break;

 // ── PWA manifest & service worker ─────────────────────
 case $uri === '/manifest.json':
 header('Content-Type: application/manifest+json');
 readfile(__DIR__ . '/public/manifest.json');
 break;

 case $uri === '/sw.js':
 header('Content-Type: application/javascript');
 readfile(__DIR__ . '/public/sw.js');
 break;

 // ── 404 ───────────────────────────────────────────────
 default:
 http_response_code(404);
 require __DIR__ . '/app/views/shared/404.php';
}
