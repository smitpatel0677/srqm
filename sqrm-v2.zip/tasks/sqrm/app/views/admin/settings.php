<?php
$pageTitle = 'Site Settings';
require __DIR__ . '/layout.php';
?>

<div class="page-header">
 <h1>Site Settings</h1>
 <p>Update global platform settings. Changes apply immediately site-wide.</p>
</div>

<?php if ($success ?? false): ?><div class="alert alert-success" data-auto-hide="4000"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error ?? false): ?><div class="alert alert-error" data-auto-hide="5000"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(440px,1fr));gap:1.5rem;max-width:960px;">
 <!-- General settings -->
 <div class="card">
 <div class="card-header"><div class="card-title"> General Settings</div></div>
 <form method="POST" enctype="multipart/form-data" action="/admin1/settings">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <input type="hidden" name="section" value="general"/>

 <div class="form-group">
 <label class="form-label">Site Name</label>
 <input type="text" name="site_name" class="form-control" value="<?= htmlspecialchars($settings['site_name'] ?? 'Saksham Digital Menu') ?>" required/>
 </div>

 <div class="form-group">
 <label class="form-label">Site Logo</label>
 <div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap;margin-bottom:.5rem;">
 <?php $logoPath = $settings['site_logo'] ?? ''; ?>
 <?php if ($logoPath): ?>
 <img src="<?= htmlspecialchars($logoPath) ?>" id="logo-cur" style="height:44px;border-radius:8px;object-fit:contain;" alt="Current Logo"/>
 <?php else: ?>
 <div id="logo-cur" style="width:44px;height:44px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div>
 <?php endif; ?>
 <input type="file" name="site_logo" accept="image/*" onchange="previewSiteLogo(this)"/>
 </div>
 <span class="form-hint">Stored locally. Displayed in header & footer.</span>
 </div>

 <div class="form-group">
 <label class="form-label">Support Phone Number</label>
 <input type="text" name="support_number" class="form-control" value="<?= htmlspecialchars($settings['support_number'] ?? '') ?>" placeholder="e.g. 9876543210"/>
 </div>

 <div class="form-group">
 <label class="form-label">WhatsApp Number (for plan upgrades)</label>
 <input type="text" name="whatsapp_number" class="form-control" value="<?= htmlspecialchars($settings['whatsapp_number'] ?? '') ?>" placeholder="e.g. 919876543210 (with country code)"/>
 </div>

 <div class="form-group">
 <label class="form-label">Support Email</label>
 <input type="email" name="support_email" class="form-control" value="<?= htmlspecialchars($settings['support_email'] ?? '') ?>"/>
 </div>

 <button type="submit" class="btn btn-primary"> Save Settings</button>
 </form>
 </div>

 <!-- Maintenance -->
 <div class="card">
 <div class="card-header"><div class="card-title"> Maintenance Mode</div></div>
 <form method="POST" action="/admin1/settings/maintenance">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <div style="padding:1rem;background:var(--bg-3);border-radius:var(--radius);margin-bottom:1.25rem;">
 <div style="font-weight:600;margin-bottom:.35rem;">Current Status:
 <?php if ($settings['maintenance_mode'] ?? false): ?>
 <span class="badge badge-warning"> Maintenance ON</span>
 <?php else: ?>
 <span class="badge badge-accent">Online</span>
 <?php endif; ?>
 </div>
 <p style="font-size:.875rem;color:var(--text-2);">When maintenance mode is ON, all visitors see a maintenance message. Admin login still works normally.</p>
 </div>
 <?php if ($settings['maintenance_mode'] ?? false): ?>
 <button type="submit" name="mode" value="off" class="btn btn-accent btn-block">Turn Off Maintenance</button>
 <?php else: ?>
 <button type="submit" name="mode" value="on" class="btn btn-warning btn-block"
 data-confirm="Enable maintenance mode? All visitors will see maintenance page."> Enable Maintenance Mode</button>
 <?php endif; ?>
 </form>

 <!-- Preview -->
 <div style="margin-top:1.5rem;padding:1rem;background:linear-gradient(135deg,#1a1a2e,#0f3460);border-radius:var(--radius);text-align:center;color:#fff;">
 <div style="font-size:1.5rem;margin-bottom:.5rem;"></div>
 <div style="font-weight:700;font-size:.9rem;">We Are Doing Maintenance</div>
 <div style="font-size:.8rem;opacity:.8;margin-top:.25rem;">For Your Experience</div>
 <div style="font-size:.75rem;opacity:.6;margin-top:.25rem;">It Won't Take That Long.</div>
 </div>
 </div>
</div>

<script>
function previewSiteLogo(input) {
 if (!input.files[0]) return;
 const reader = new FileReader();
 reader.onload = e => {
 let el = document.getElementById('logo-cur');
 if (el.tagName === 'IMG') { el.src = e.target.result; }
 else {
 const img = document.createElement('img');
 img.src = e.target.result;
 img.id = 'logo-cur';
 img.style.cssText = 'height:44px;border-radius:8px;object-fit:contain;';
 el.replaceWith(img);
 }
 };
 reader.readAsDataURL(input.files[0]);
}
</script>

<?php require __DIR__ . '/layout_end.php'; ?>
