<?php
$pageTitle = 'Owner Detail — ' . htmlspecialchars($owner['name']);
require __DIR__ . '/layout.php';
?>

<div class="page-header">
 <div class="page-header-row">
 <div>
 <h1><?= htmlspecialchars($owner['name']) ?></h1>
 <p><?= htmlspecialchars($owner['email']) ?></p>
 </div>
 <a href="/admin1/owners" class="btn btn-ghost btn-sm">← Back</a>
 </div>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:1.5rem;max-width:900px;">
 <!-- Owner info card -->
 <div class="card">
 <div class="card-header"><div class="card-title">Account Info</div></div>
 <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.25rem;">
 <?php if ($owner['avatar']): ?>
 <img src="<?= htmlspecialchars($owner['avatar']) ?>" style="width:56px;height:56px;border-radius:50%;object-fit:cover;"/>
 <?php else: ?>
 <div style="width:56px;height:56px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.4rem;font-weight:800;"><?= strtoupper(substr($owner['name'],0,1)) ?></div>
 <?php endif; ?>
 <div>
 <div style="font-weight:700;"><?= htmlspecialchars($owner['name']) ?></div>
 <div style="font-size:.85rem;color:var(--text-3);"><?= htmlspecialchars($owner['email']) ?></div>
 <div style="font-size:.82rem;color:var(--text-3);"><?= htmlspecialchars($owner['phone'] ?? '—') ?></div>
 </div>
 </div>
 <div style="display:flex;flex-direction:column;gap:.5rem;font-size:.875rem;">
 <div style="display:flex;justify-content:space-between;">
 <span style="color:var(--text-3);">Plan</span>
 <span class="badge badge-<?= $owner['plan'] === 'premium' ? 'accent' : ($owner['plan'] === 'basic' ? 'primary' : 'muted') ?>"><?= ucfirst($owner['plan']) ?></span>
 </div>
 <div style="display:flex;justify-content:space-between;">
 <span style="color:var(--text-3);">Plan Expires</span>
 <span><?= $owner['plan_expires_at'] ? date('d M Y', strtotime($owner['plan_expires_at'])) : '—' ?></span>
 </div>
 <div style="display:flex;justify-content:space-between;">
 <span style="color:var(--text-3);">Joined</span>
 <span><?= date('d M Y', strtotime($owner['created_at'])) ?></span>
 </div>
 </div>

 <!-- Quick plan change -->
 <div style="margin-top:1.25rem;border-top:1px solid var(--border);padding-top:1rem;">
 <form method="POST" action="/admin1/owners/assign-plan">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <input type="hidden" name="owner_id" value="<?= $owner['id'] ?>"/>
 <div style="display:flex;gap:.5rem;align-items:flex-end;">
 <div style="flex:1;">
 <label class="form-label">Change Plan</label>
 <select name="plan" class="form-control">
 <option value="free" <?= $owner['plan'] === 'free' ? 'selected' : '' ?>>Free</option>
 <option value="basic" <?= $owner['plan'] === 'basic' ? 'selected' : '' ?>>Basic</option>
 <option value="premium" <?= $owner['plan'] === 'premium' ? 'selected' : '' ?>>Premium</option>
 </select>
 </div>
 <button type="submit" class="btn btn-primary btn-sm">Save</button>
 </div>
 </form>
 </div>
 </div>

 <!-- Restaurants -->
 <div class="card" style="overflow:hidden;">
 <div class="card-header"><div class="card-title">Restaurants (<?= count($restaurants) ?>)</div></div>
 <?php if (empty($restaurants)): ?>
 <p style="color:var(--text-3);padding:.5rem 0;">No restaurants yet.</p>
 <?php else: ?>
 <div style="display:flex;flex-direction:column;gap:.6rem;">
 <?php foreach ($restaurants as $r): ?>
 <div style="display:flex;align-items:center;gap:.75rem;padding:.6rem;background:var(--bg-2);border-radius:var(--radius);">
 <?php if ($r['logo']): ?>
 <img src="<?= UPLOAD_URL ?>logos/<?= htmlspecialchars($r['logo']) ?>" style="width:32px;height:32px;border-radius:50%;object-fit:cover;" loading="lazy"/>
 <?php endif; ?>
 <div style="flex:1;min-width:0;">
 <div style="font-weight:600;font-size:.9rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($r['name']) ?></div>
 <div style="font-size:.78rem;color:var(--text-3);"><?= htmlspecialchars($r['location']) ?></div>
 </div>
 <?php if ($r['is_suspended']): ?>
 <span class="badge badge-error" style="font-size:.7rem;">Suspended</span>
 <?php else: ?>
 <span class="badge badge-accent" style="font-size:.7rem;">Active</span>
 <?php endif; ?>
 <a href="/r/<?= htmlspecialchars($r['slug']) ?>" target="_blank" class="btn btn-sm btn-ghost" style="padding:.25rem .5rem;font-size:.75rem;"></a>
 </div>
 <?php endforeach; ?>
 </div>
 <?php endif; ?>
 </div>
</div>

<?php require __DIR__ . '/layout_end.php'; ?>
