<?php
$pageTitle = 'Review Moderation';
require __DIR__ . '/layout.php';
?>

<div class="page-header">
 <h1>Review Moderation</h1>
 <p>View and delete customer reviews across all restaurants.</p>
</div>

<?php if ($success ?? false): ?><div class="alert alert-success" data-auto-hide="4000"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<!-- Restaurant filter -->
<div class="search-bar" style="margin-bottom:1.5rem;">
 <form method="GET" action="/admin1/reviews" style="display:flex;gap:1rem;flex-wrap:wrap;align-items:flex-end;width:100%;">
 <div class="form-group" style="min-width:220px;flex:1;margin-bottom:0;">
 <label class="form-label">Filter by Restaurant</label>
 <select name="restaurant_id" class="form-control" onchange="this.form.submit()">
 <option value="">All Restaurants</option>
 <?php foreach ($restaurants as $r): ?>
 <option value="<?= $r['id'] ?>" <?= ($restaurantId == $r['id']) ? 'selected' : '' ?>><?= htmlspecialchars($r['name']) ?></option>
 <?php endforeach; ?>
 </select>
 </div>
 </form>
</div>

<div class="reviews-grid">
 <?php if (empty($reviews)): ?>
 <div class="card text-center" style="padding:3rem;">
 <div style="font-size:3rem;margin-bottom:1rem;"></div>
 <h3>No reviews found</h3>
 </div>
 <?php else: ?>
 <?php foreach ($reviews as $rev): ?>
 <div class="review-card" id="review-<?= $rev['id'] ?>">
 <div class="review-header">
 <div>
 <span class="review-author"><?= htmlspecialchars($rev['customer_name']) ?></span>
 <div style="font-size:.8rem;color:var(--text-3);"><?= htmlspecialchars($rev['restaurant_name']) ?></div>
 <div class="star-rating" style="margin-top:.2rem;"><?php echo starHtml((float)$rev['rating']); ?></div>
 </div>
 <div style="display:flex;flex-direction:column;align-items:flex-end;gap:.35rem;">
 <span class="review-date"><?= timeAgo($rev['created_at']) ?></span>
 <button onclick="deleteReview(<?= $rev['id'] ?>)" class="btn btn-sm btn-danger"
 data-confirm="Delete this review?">Delete Edit Delete</button>
 </div>
 </div>
 <?php if ($rev['review_text']): ?>
 <p class="review-text">"<?= htmlspecialchars($rev['review_text']) ?>"</p>
 <?php endif; ?>
 </div>
 <?php endforeach; ?>
 <?php endif; ?>
</div>

<script>
async function deleteReview(id) {
 if (!confirm('Delete this review? This cannot be undone.')) return;
 const fd = new FormData();
 fd.append('review_id', id);
 fd.append('csrf_token', '<?= csrf() ?>');
 const res = await fetch('/admin1/reviews/delete', { method: 'POST', body: fd });
 const data = await res.json();
 if (data.success) {
 document.getElementById(`review-${id}`)?.remove();
 showToast('Review deleted.', 'default');
 } else {
 showToast(data.error || 'Failed to delete review.', 'error');
 }
}
</script>

<?php require __DIR__ . '/layout_end.php'; ?>
