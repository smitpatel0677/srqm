<?php
// Admin layout template
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
$pageTitle = $pageTitle ?? 'Admin Panel';
require __DIR__ . '/../shared/header.php';

// Simple block system
$blocks = [];
function startBlock($name) { global $blocks; ob_start(); $GLOBALS['_current_block'] = $name; }
function endBlock() { global $blocks; $blocks[$GLOBALS['_current_block']] = ob_get_clean(); }
function renderBlock($name) { global $blocks; echo $blocks[$name] ?? ''; }

$currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
function isAdminActive($path) {
 global $currentPath;
 return strpos($currentPath, $path) === 0 ? 'active' : '';
}
?>
<header class="navbar" style="background:#1a1a2e;border-color:#2d3748;">
 <div class="navbar-inner">
 <button class="hamburger" style="filter:invert(1);"><span></span><span></span><span></span></button>
 <a href="/admin1/dashboard" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">A</div><?php endif; ?>
 <div><div class="brand-text" style="color:#fff;"><?= htmlspecialchars($siteName) ?></div><div class="brand-short" style="color:#9ca3af;">Admin Panel</div></div>
 </a>
 <div class="navbar-actions">
 <button class="theme-toggle" aria-label="Toggle theme"><span class="theme-icon">&#9788;</span></button>
 <a href="/admin1/logout" class="btn btn-sm btn-ghost" style="color:#f87171;">Logout</a>
 </div>
 </div>
</header>

<div class="admin-layout">
 <aside class="admin-sidebar" id="admin-sidebar">
 <div class="admin-sidebar-brand">
 <span>SQRM Admin</span>
 </div>
 <nav class="admin-nav" style="display:flex;flex-direction:column;gap:.25rem;">
 <a href="/admin1/dashboard" class="<?= isAdminActive('/admin1/dashboard') ?>">Dashboard</a>
 <a href="/admin1/owners" class="<?= isAdminActive('/admin1/owners') ?>">Owners</a>
 <a href="/admin1/restaurants" class="<?= isAdminActive('/admin1/restaurants') ?>">Restaurants</a>
 <a href="/admin1/reviews" class="<?= isAdminActive('/admin1/reviews') ?>">Reviews</a>
 <a href="/admin1/settings" class="<?= isAdminActive('/admin1/settings') ?>">Settings</a>
 <a href="/admin1/logout" style="margin-top:auto;color:#f87171;">Logout</a>
 </nav>
 </aside>

 <main class="admin-content">
 <?php // Content rendered after layout is included ?>
