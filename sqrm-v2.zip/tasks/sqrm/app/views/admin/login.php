<?php
$pageTitle = 'Admin Login';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
$error = $error ?? '';
require __DIR__ . '/../shared/header.php';
?>
<div class="auth-page" style="background:var(--bg-2);">
 <div class="auth-card">
 <div class="auth-logo" style="justify-content:center;">
 <?php if ($siteLogo): ?>
 <img src="<?= htmlspecialchars($siteLogo) ?>" style="height:44px;border-radius:8px;"/>
 <?php else: ?>
 <div style="width:44px;height:44px;background:#1a1a2e;border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--primary);font-weight:800;font-size:1.1rem;">A</div>
 <?php endif; ?>
 <span class="auth-logo-text" style="color:#1a1a2e;"><?= htmlspecialchars($siteName) ?></span>
 </div>
 <h1 class="auth-title">Admin Login</h1>
 <p class="auth-sub">Super administrator access only</p>

 <?php if ($error): ?>
 <div class="alert alert-error" data-auto-hide="5000"><?= htmlspecialchars($error) ?></div>
 <?php endif; ?>

 <form method="POST" action="/admin1/login">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <div class="form-group">
 <label class="form-label">Email Address</label>
 <input type="email" name="email" class="form-control" placeholder="admin@example.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autocomplete="email"/>
 </div>
 <div class="form-group">
 <label class="form-label">Password</label>
 <input type="password" name="password" class="form-control" placeholder="••••••••" required autocomplete="current-password"/>
 </div>
 <button type="submit" class="btn btn-primary btn-block"> Sign In</button>
 </form>

 <p style="text-align:center;font-size:.78rem;color:var(--text-3);margin-top:1.5rem;">
 Restaurant owner? <a href="/owner/login" style="color:var(--primary);">Owner login →</a>
 </p>
 </div>
</div>
