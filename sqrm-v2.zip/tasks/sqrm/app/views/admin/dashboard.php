<?php
$pageTitle = 'Admin Dashboard';
require __DIR__ . '/layout.php';
?>

<div class="page-header">
 <h1>Admin Dashboard</h1>
 <p>Platform overview and quick actions.</p>
</div>

<div class="stats-row">
 <div class="stat-card"><div class="stat-val"><?= (int)$stats['total_owners'] ?></div><div class="stat-lbl">Total Owners</div></div>
 <div class="stat-card"><div class="stat-val"><?= (int)$stats['total_restaurants'] ?></div><div class="stat-lbl">Restaurants</div></div>
 <div class="stat-card"><div class="stat-val"><?= (int)$stats['total_orders'] ?></div><div class="stat-lbl">Total Orders</div></div>
 <div class="stat-card"><div class="stat-val"><?= (int)$stats['total_reviews'] ?></div><div class="stat-lbl">Reviews</div></div>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:1.25rem;margin-top:1.5rem;">
 <a href="/admin1/owners" class="card" style="text-decoration:none;display:flex;align-items:center;gap:1rem;">
 <div class="feature-icon" style="font-size:1.3rem;width:52px;height:52px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:var(--bg-3);border-radius:var(--radius);">&#9776;</div>
 <div><h3 style="font-size:1rem;">Owner Management</h3><p style="font-size:.85rem;color:var(--text-3);">View owners, assign plans</p></div>
 </a>
 <a href="/admin1/restaurants" class="card" style="text-decoration:none;display:flex;align-items:center;gap:1rem;">
 <div class="feature-icon" style="font-size:1.3rem;width:52px;height:52px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:var(--bg-3);border-radius:var(--radius);">&#8962;</div>
 <div><h3 style="font-size:1rem;">Restaurants</h3><p style="font-size:.85rem;color:var(--text-3);">Suspend, reactivate</p></div>
 </a>
 <a href="/admin1/reviews" class="card" style="text-decoration:none;display:flex;align-items:center;gap:1rem;">
 <div class="feature-icon" style="font-size:1.3rem;width:52px;height:52px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:var(--bg-3);border-radius:var(--radius);">&#9733;</div>
 <div><h3 style="font-size:1rem;">Review Moderation</h3><p style="font-size:.85rem;color:var(--text-3);">View and delete reviews</p></div>
 </a>
 <a href="/admin1/settings" class="card" style="text-decoration:none;display:flex;align-items:center;gap:1rem;">
 <div class="feature-icon" style="font-size:1.3rem;width:52px;height:52px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:var(--bg-3);border-radius:var(--radius);">&#9881;</div>
 <div><h3 style="font-size:1rem;">Site Settings</h3><p style="font-size:.85rem;color:var(--text-3);">Logo, name, maintenance</p></div>
 </a>
</div>

<div style="margin-top:2.5rem;">
 <h2 style="font-size:1.1rem;font-weight:700;margin-bottom:1rem;">Recent Owner Registrations</h2>
 <div class="table-wrap">
 <table>
 <thead><tr><th>Owner</th><th>Email</th><th>Plan</th><th>Restaurants</th><th>Joined</th><th>Actions</th></tr></thead>
 <tbody>
 <?php foreach ($recentOwners as $o): ?>
 <tr>
 <td>
 <div style="display:flex;align-items:center;gap:.6rem;">
 <?php if ($o['avatar']): ?>
 <img src="<?= htmlspecialchars($o['avatar']) ?>" style="width:28px;height:28px;border-radius:50%;object-fit:cover;"/>
 <?php else: ?>
 <div style="width:28px;height:28px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;color:#fff;font-size:.75rem;font-weight:700;"><?= strtoupper(substr($o['name'],0,1)) ?></div>
 <?php endif; ?>
 <span><?= htmlspecialchars($o['name']) ?></span>
 </div>
 </td>
 <td><?= htmlspecialchars($o['email']) ?></td>
 <td><span class="badge badge-<?= $o['plan'] === 'premium' ? 'accent' : ($o['plan'] === 'basic' ? 'primary' : 'muted') ?>"><?= ucfirst($o['plan']) ?></span></td>
 <td><?= (int)$o['restaurant_count'] ?></td>
 <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
 <td><a href="/admin1/owners/<?= $o['id'] ?>" class="btn btn-sm btn-ghost">View</a></td>
 </tr>
 <?php endforeach; ?>
 </tbody>
 </table>
 </div>
</div>

<?php require __DIR__ . '/layout_end.php'; ?>
