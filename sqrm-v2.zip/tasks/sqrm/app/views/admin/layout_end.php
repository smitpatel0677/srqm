<?php
// Admin layout closing
?>
 </main>
</div>
<?php require __DIR__ . '/../shared/footer.php'; ?>
