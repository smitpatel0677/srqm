<?php
$pageTitle = 'Manage Owners';
require __DIR__ . '/layout.php';
?>

<div class="page-header">
 <h1>Owner Management</h1>
 <p>View owners, assign subscription plans, and manage accounts.</p>
</div>

<?php if ($success ?? false): ?><div class="alert alert-success" data-auto-hide="4000"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<?php if ($error ?? false): ?><div class="alert alert-error" data-auto-hide="5000"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="table-wrap">
 <table>
 <thead>
 <tr><th>Owner</th><th>Email</th><th>Phone</th><th>Plan</th><th>Plan Expires</th><th>Restaurants</th><th>Actions</th></tr>
 </thead>
 <tbody>
 <?php foreach ($owners as $o): ?>
 <tr>
 <td>
 <div style="display:flex;align-items:center;gap:.6rem;">
 <?php if ($o['avatar']): ?>
 <img src="<?= htmlspecialchars($o['avatar']) ?>" style="width:30px;height:30px;border-radius:50%;object-fit:cover;"/>
 <?php else: ?>
 <div style="width:30px;height:30px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;color:#fff;font-size:.8rem;font-weight:700;"><?= strtoupper(substr($o['name'],0,1)) ?></div>
 <?php endif; ?>
 <?= htmlspecialchars($o['name']) ?>
 </div>
 </td>
 <td><?= htmlspecialchars($o['email']) ?></td>
 <td><?= htmlspecialchars($o['phone'] ?? '—') ?></td>
 <td>
 <span class="badge badge-<?= $o['plan'] === 'premium' ? 'accent' : ($o['plan'] === 'basic' ? 'primary' : 'muted') ?>"><?= ucfirst($o['plan']) ?></span>
 </td>
 <td><?= $o['plan_expires_at'] ? date('d M Y', strtotime($o['plan_expires_at'])) : '—' ?></td>
 <td><?= (int)$o['restaurant_count'] ?></td>
 <td>
 <div class="td-actions">
 <button onclick="openPlanModal(<?= $o['id'] ?>, '<?= $o['plan'] ?>')" class="btn btn-sm btn-primary"> Plan</button>
 <a href="/admin1/owners/<?= $o['id'] ?>" class="btn btn-sm btn-ghost">View</a>
 </div>
 </td>
 </tr>
 <?php endforeach; ?>
 </tbody>
 </table>
</div>

<!-- Plan Modal -->
<div id="plan-modal" class="modal-overlay hidden">
 <div class="modal">
 <div class="modal-header">
 <h3 class="modal-title"> Assign Plan</h3>
 <button class="modal-close" data-modal-close></button>
 </div>
 <form method="POST" action="/admin1/owners/assign-plan">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <input type="hidden" name="owner_id" id="plan-owner-id"/>
 <div class="form-group">
 <label class="form-label">Plan</label>
 <select name="plan" id="plan-select" class="form-control">
 <option value="free">Free</option>
 <option value="basic">Basic (₹29/month)</option>
 <option value="premium">Premium (₹49/month)</option>
 </select>
 </div>
 <div class="alert alert-info" style="font-size:.82rem;">Plan auto-expires after 30 days. Features activate immediately upon save.</div>
 <button type="submit" class="btn btn-primary btn-block"> Save Plan</button>
 </form>
 </div>
</div>

<script>
function openPlanModal(ownerId, currentPlan) {
 document.getElementById('plan-owner-id').value = ownerId;
 document.getElementById('plan-select').value = currentPlan;
 openModal('plan-modal');
}
</script>

<?php require __DIR__ . '/layout_end.php'; ?>
