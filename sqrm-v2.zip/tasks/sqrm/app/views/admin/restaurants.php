<?php
$pageTitle = 'Manage Restaurants';
require __DIR__ . '/layout.php';
?>

<div class="page-header">
 <h1>Restaurant Management</h1>
 <p>Suspend or reactivate restaurants.</p>
</div>

<?php if ($success ?? false): ?><div class="alert alert-success" data-auto-hide="4000"><?= htmlspecialchars($success) ?></div><?php endif; ?>

<div class="table-wrap">
 <table>
 <thead>
 <tr><th>Restaurant</th><th>Owner</th><th>Location</th><th>Items</th><th>Orders</th><th>Rating</th><th>Status</th><th>Actions</th></tr>
 </thead>
 <tbody>
 <?php foreach ($restaurants as $r): ?>
 <tr>
 <td>
 <div style="display:flex;align-items:center;gap:.6rem;">
 <?php if ($r['logo']): ?>
 <img src="<?= UPLOAD_URL ?>logos/<?= htmlspecialchars($r['logo']) ?>" style="width:30px;height:30px;border-radius:50%;object-fit:cover;" loading="lazy"/>
 <?php endif; ?>
 <strong><?= htmlspecialchars($r['name']) ?></strong>
 </div>
 </td>
 <td><?= htmlspecialchars($r['owner_name']) ?><br/><small style="color:var(--text-3);"><?= htmlspecialchars($r['owner_email']) ?></small></td>
 <td><?= htmlspecialchars($r['location']) ?></td>
 <td><?= (int)$r['item_count'] ?></td>
 <td><?= (int)$r['order_count'] ?></td>
 <td><?= number_format((float)$r['rating'],1) ?></td>
 <td>
 <?php if ($r['is_suspended']): ?>
 <span class="badge badge-error">Suspended</span>
 <?php else: ?>
 <span class="badge badge-accent">Active</span>
 <?php endif; ?>
 </td>
 <td>
 <div class="td-actions">
 <?php if ($r['is_suspended']): ?>
 <form method="POST" action="/admin1/restaurants/<?= $r['id'] ?>/reactivate">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <button class="btn btn-sm btn-accent">Reactivate</button>
 </form>
 <?php else: ?>
 <form method="POST" action="/admin1/restaurants/<?= $r['id'] ?>/suspend">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <button class="btn btn-sm btn-danger"
 data-confirm="Suspend '<?= htmlspecialchars($r['name']) ?>'?"> Suspend</button>
 </form>
 <?php endif; ?>
 <a href="/admin1/restaurants/<?= $r['id'] ?>/reviews" class="btn btn-sm btn-ghost">Reviews</a>
 <a href="/r/<?= htmlspecialchars($r['slug']) ?>" target="_blank" class="btn btn-sm btn-ghost"></a>
 </div>
 </td>
 </tr>
 <?php endforeach; ?>
 </tbody>
 </table>
</div>

<?php require __DIR__ . '/layout_end.php'; ?>
