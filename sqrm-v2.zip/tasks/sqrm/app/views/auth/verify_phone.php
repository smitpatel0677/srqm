<?php
$pageTitle = 'Verify Phone Number';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
?>
<div class="auth-page">
 <div class="auth-card">
 <div class="auth-logo">
 <?php if ($siteLogo): ?>
 <img src="<?= htmlspecialchars($siteLogo) ?>" alt="<?= htmlspecialchars($siteName) ?>" style="height:44px;border-radius:8px;"/>
 <?php else: ?>
 <div style="width:44px;height:44px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div>
 <?php endif; ?>
 <span class="auth-logo-text"><?= htmlspecialchars($siteName) ?></span>
 </div>
 <h1 class="auth-title">Verify Your Phone</h1>
 <p class="auth-sub">Enter your mobile number to complete registration</p>

 <?php if ($error): ?>
 <div class="alert alert-error" data-auto-hide="5000"><?= htmlspecialchars($error) ?></div>
 <?php endif; ?>

 <form method="POST" action="/owner/verify-phone">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <div class="form-group">
 <label class="form-label">Mobile Number</label>
 <input type="tel" name="phone" class="form-control" placeholder="Enter 10-digit mobile number" maxlength="10" pattern="[0-9]{10}" required autocomplete="tel"/>
 <span class="form-hint">Must be a valid Indian mobile number</span>
 </div>
 <button type="submit" class="btn btn-primary btn-block">Verify & Continue</button>
 </form>

 <p style="text-align:center;font-size:.8rem;color:var(--text-3);margin-top:1rem;">
 <a href="/owner/logout" style="color:var(--primary);">← Use a different account</a>
 </p>
 </div>
</div>
