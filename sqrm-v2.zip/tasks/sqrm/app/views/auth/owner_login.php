<?php
$pageTitle = 'Owner Login — Get Started';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
$error = $_GET['error'] ?? '';
require __DIR__ . '/../shared/header.php';
?>
<div class="auth-page">
 <div class="auth-card">
 <div class="auth-logo">
 <?php if ($siteLogo): ?>
 <img src="<?= htmlspecialchars($siteLogo) ?>" alt="<?= htmlspecialchars($siteName) ?>" style="height:44px;border-radius:8px;"/>
 <?php else: ?>
 <div style="width:44px;height:44px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:1.1rem;">S</div>
 <?php endif; ?>
 <span class="auth-logo-text"><?= htmlspecialchars($siteName) ?></span>
 </div>
 <h1 class="auth-title">Owner Login</h1>
 <p class="auth-sub">Sign in with your Google account to manage your restaurants</p>

 <?php if ($error): ?>
 <div class="alert alert-error" data-auto-hide="5000">
 <?php
 echo match($error) {
 'invalid_state' => 'Security check failed. Please try again.',
 'token_failed' => 'Google login failed. Please try again.',
 'userinfo_failed'=> 'Could not fetch your profile. Please try again.',
 'suspended' => ' Your account has been suspended. Contact support.',
 default => 'Login failed. Please try again.',
 };
 ?>
 </div>
 <?php endif; ?>

 <a href="/auth/google" class="btn-google">
 <svg width="20" height="20" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.35-8.16 2.35-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
 Continue with Google
 </a>

 <p style="text-align:center;color:var(--text-3);font-size:.8rem;margin-top:1.5rem;">
 Google login is for restaurant owners only.<br/>
 Looking for a restaurant? <a href="/restaurants" style="color:var(--primary);">Browse Restaurants</a>
 </p>
 </div>
</div>
