<?php
$pageTitle = 'Edit Restaurant — ' . htmlspecialchars($restaurant['name']);
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
$logoUrl = $restaurant['logo'] ? UPLOAD_URL . 'logos/' . $restaurant['logo'] : '';
?>
<header class="navbar">
 <div class="navbar-inner">
 <button class="hamburger"><span></span><span></span><span></span></button>
 <a href="/owner/dashboard" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div></div>
 </a>
 <div class="navbar-actions"><button class="theme-toggle"><span class="theme-icon">&#9788;</span></button></div>
 </div>
</header>

<div class="dashboard-layout">
 <div class="sidebar-overlay"></div>
 <aside class="sidebar">
 <nav class="sidebar-nav">
 <a href="/owner/dashboard">Dashboard</a>
 <a href="/owner/restaurants" class="active">My Restaurants</a>
 <a href="/owner/profile">Profile</a>
 <a href="/owner/logout" style="color:var(--error);padding:.7rem 1rem;display:flex;align-items:center;gap:.75rem;">Logout</a>
 </nav>
 </aside>

 <main class="dashboard-content">
 <div class="page-header">
 <div class="page-header-row">
 <div><h1>EditEdit Restaurant</h1><p>Update your restaurant details.</p></div>
 <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
 <a href="/owner/restaurants/<?= $restaurant['id'] ?>/menu" class="btn btn-sm btn-outline"> Manage Menu</a>
 <a href="/owner/restaurants/<?= $restaurant['id'] ?>/qr" class="btn btn-sm btn-ghost">QR Code</a>
 <a href="/r/<?= htmlspecialchars($restaurant['slug']) ?>" target="_blank" class="btn btn-sm btn-ghost">Public</a>
 </div>
 </div>
 </div>

 <div class="card" style="max-width:640px;">
 <?php if ($error): ?>
 <div class="alert alert-error" data-auto-hide="5000"><?= htmlspecialchars($error) ?></div>
 <?php endif; ?>
 <?php if ($success): ?>
 <div class="alert alert-success" data-auto-hide="4000"><?= htmlspecialchars($success) ?></div>
 <?php endif; ?>

 <form method="POST" enctype="multipart/form-data" action="/owner/restaurants/<?= $restaurant['id'] ?>/edit">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>

 <div class="form-group">
 <label class="form-label">Restaurant Name *</label>
 <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($restaurant['name']) ?>" required/>
 </div>

 <div class="form-group">
 <label class="form-label">Restaurant Logo</label>
 <div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap;">
 <div id="logo-preview-wrap" style="width:80px;height:80px;border-radius:50%;overflow:hidden;border:2px solid var(--primary);flex-shrink:0;">
 <?php if ($logoUrl): ?>
 <img src="<?= htmlspecialchars($logoUrl) ?>" style="width:100%;height:100%;object-fit:cover;" id="logo-preview-img"/>
 <?php else: ?>
 <div style="width:100%;height:100%;background:var(--bg-3);display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:var(--text-3);">&#128247;</div>
 <?php endif; ?>
 </div>
 <div>
 <input type="file" name="logo" accept="image/*" onchange="previewLogo(this)"/>
 <span class="form-hint">Leave empty to keep current logo. Any format → auto WebP.</span>
 </div>
 </div>
 </div>

 <div class="form-group">
 <label class="form-label">Location / Address *</label>
 <input type="text" name="location" class="form-control" value="<?= htmlspecialchars($restaurant['location']) ?>" required/>
 </div>

 <div class="form-group">
 <label class="form-label">Phone Number *</label>
 <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($restaurant['phone']) ?>" required/>
 </div>

 <div class="form-group">
 <label class="form-label">Online Payment Info</label>
 <textarea name="payment_info" class="form-control" rows="2" placeholder="UPI, Google Pay, etc."><?= htmlspecialchars($restaurant['payment_info'] ?? '') ?></textarea>
 </div>

 <?php if (planHas($plan, 'custom_theme')): ?>
 <div class="form-group">
 <label class="form-label">Theme Color</label>
 <input type="color" name="theme_color" class="form-control" value="<?= htmlspecialchars($restaurant['theme_color'] ?? '#D35400') ?>" style="height:48px;padding:.25rem;"/>
 </div>
 <?php endif; ?>

 <div style="display:flex;gap:.75rem;flex-wrap:wrap;">
 <button type="submit" class="btn btn-primary">Save Changes</button>
 <a href="/owner/restaurants" class="btn btn-ghost">Cancel</a>
 </div>
 </form>
 </div>

 <!-- Danger Zone -->
 <div class="card" style="max-width:640px;margin-top:1.5rem;border-color:var(--error);">
 <h3 style="color:var(--error);margin-bottom:.75rem;">Danger Zone</h3>
 <p style="font-size:.875rem;color:var(--text-2);margin-bottom:1rem;">
 Deleting this restaurant is permanent. All menu items, orders, and reviews will be removed.
 <?php if ($plan === 'free'): ?>Your Free Plan slot will be freed up.<?php endif; ?>
 </p>
 <form method="POST" action="/owner/restaurants/<?= $restaurant['id'] ?>/delete">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <button type="submit" class="btn btn-danger btn-sm"
 data-confirm="Are you sure you want to delete '<?= htmlspecialchars($restaurant['name']) ?>'? This cannot be undone.">
 Delete Edit Delete Restaurant
 </button>
 </form>
 </div>

 <!-- Quick links -->
 <div style="display:flex;gap:.75rem;flex-wrap:wrap;margin-top:1.5rem;">
 <a href="/owner/restaurants/<?= $restaurant['id'] ?>/orders" class="btn btn-outline"> View Orders</a>
 <a href="/owner/restaurants/<?= $restaurant['id'] ?>/qr" class="btn btn-ghost">Generate QR</a>
 </div>
 </main>
</div>

<script>
function previewLogo(input) {
 if (!input.files[0]) return;
 const reader = new FileReader();
 reader.onload = e => {
 const wrap = document.getElementById('logo-preview-wrap');
 wrap.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;" id="logo-preview-img"/>`;
 };
 reader.readAsDataURL(input.files[0]);
}
</script>
<?php require __DIR__ . '/../shared/footer.php'; ?>
