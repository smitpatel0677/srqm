<?php
$pageTitle = 'Orders — ' . htmlspecialchars($restaurant['name']);
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
?>
<audio id="ding-audio" src="/assets/sounds/ding.mp3" preload="auto"></audio>
<header class="navbar">
 <div class="navbar-inner">
 <button class="hamburger"><span></span><span></span><span></span></button>
 <a href="/owner/dashboard" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div></div>
 </a>
 <div class="navbar-actions">
 <button class="theme-toggle"><span class="theme-icon">&#9788;</span></button>
 <span id="pending-badge" class="badge badge-error hidden">0 pending</span>
 </div>
 </div>
</header>

<div class="dashboard-layout">
 <div class="sidebar-overlay"></div>
 <aside class="sidebar">
 <nav class="sidebar-nav">
 <a href="/owner/dashboard">Dashboard</a>
 <a href="/owner/restaurants" class="active">My Restaurants</a>
 <a href="/owner/profile">Profile</a>
 <a href="/owner/logout" style="color:var(--error);padding:.7rem 1rem;display:flex;align-items:center;gap:.75rem;">Logout</a>
 </nav>
 </aside>

 <main class="dashboard-content">
 <div class="page-header">
 <div class="page-header-row">
 <div><h1>Orders — <?= htmlspecialchars($restaurant['name']) ?></h1></div>
 <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
 <a href="/owner/restaurants/<?= $restaurant['id'] ?>/menu" class="btn btn-sm btn-ghost">Menu</a>
 <a href="/owner/restaurants/<?= $restaurant['id'] ?>/edit" class="btn btn-sm btn-ghost">EditEdit</a>
 </div>
 </div>
 </div>

 <!-- Filter tabs -->
 <div class="pill-tabs" id="status-filter-tabs">
 <button class="pill-tab active" onclick="filterOrders('all',this)">All</button>
 <button class="pill-tab" onclick="filterOrders('pending',this)">Pending</button>
 <button class="pill-tab" onclick="filterOrders('accepted',this)">Accepted</button>
 <button class="pill-tab" onclick="filterOrders('completed',this)">Completed</button>
 <button class="pill-tab" onclick="filterOrders('rejected',this)">Rejected</button>
 </div>

 <div id="orders-container">
 <?php if (empty($orders)): ?>
 <div class="card text-center" style="padding:3rem;">
 <div style="font-size:3rem;margin-bottom:1rem;"></div>
 <h3>No orders yet</h3>
 <p style="color:var(--text-3);">Share your QR code so customers can start ordering!</p>
 <a href="/owner/restaurants/<?= $restaurant['id'] ?>/qr" class="btn btn-primary" style="margin-top:1.25rem;">Get QR Code</a>
 </div>
 <?php else: ?>
 <div id="orders-list" style="display:flex;flex-direction:column;gap:1rem;">
 <?php foreach ($orders as $o): ?>
 <div class="card order-card" data-order-id="<?= $o['id'] ?>" data-status="<?= $o['status'] ?>">
 <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;flex-wrap:wrap;">
 <div>
 <div style="font-weight:700;font-size:1rem;"><?= htmlspecialchars($o['customer_name']) ?> &nbsp; <?= htmlspecialchars($o['customer_phone']) ?></div>
 <div style="font-size:.82rem;color:var(--text-3);margin-top:.25rem;">
 <?= ucfirst($o['payment_method']) ?> &nbsp;|&nbsp; <?= timeAgo($o['created_at']) ?>
 &nbsp;|&nbsp; Order #<?= substr($o['temp_token'],0,8) ?>
 </div>
 </div>
 <span class="badge badge-<?= $o['status'] === 'pending' ? 'warning' : ($o['status'] === 'accepted' ? 'info' : ($o['status'] === 'completed' ? 'accent' : 'error')) ?>">
 <?= ucfirst($o['status']) ?>
 </span>
 </div>

 <!-- Items -->
 <div style="margin:.85rem 0;border-top:1px solid var(--border);padding-top:.75rem;">
 <?php $items = json_decode($o['items_json'], true) ?: []; ?>
 <?php foreach ($items as $item): ?>
 <div style="display:flex;justify-content:space-between;font-size:.875rem;padding:.2rem 0;">
 <span><?= htmlspecialchars($item['name']) ?> × <?= (int)$item['qty'] ?></span>
 <span>₹<?= number_format($item['price'] * $item['qty'], 2) ?></span>
 </div>
 <?php endforeach; ?>
 <div style="font-weight:800;font-size:.95rem;border-top:1px solid var(--border);margin-top:.5rem;padding-top:.5rem;display:flex;justify-content:space-between;">
 <span>Total</span><span style="color:var(--primary);">₹<?= number_format($o['subtotal'], 2) ?></span>
 </div>
 </div>

 <?php if ($o['rejection_reason']): ?>
 <div class="alert alert-error" style="margin-bottom:.75rem;font-size:.875rem;">Rejection reason: <?= htmlspecialchars($o['rejection_reason']) ?></div>
 <?php endif; ?>

 <!-- Actions -->
 <div style="display:flex;gap:.5rem;flex-wrap:wrap;" id="actions-<?= $o['id'] ?>">
 <?php if ($o['status'] === 'pending'): ?>
 <button onclick="acceptOrder(<?= $o['id'] ?>)" class="btn btn-sm btn-accent">Accept</button>
 <button onclick="openRejectModal(<?= $o['id'] ?>)" class="btn btn-sm btn-danger">Reject</button>
 <?php elseif ($o['status'] === 'accepted'): ?>
 <button onclick="completeOrder(<?= $o['id'] ?>)" class="btn btn-sm btn-primary">Mark as Given</button>
 <?php elseif ($o['status'] === 'completed'): ?>
 <button onclick="downloadBill(<?= $o['id'] ?>)" class="btn btn-sm btn-ghost">Download Bill</button>
 <?php endif; ?>
 <a href="/order/<?= htmlspecialchars($o['temp_token']) ?>" target="_blank" class="btn btn-sm btn-ghost">Track Page</a>
 </div>
 </div>
 <?php endforeach; ?>
 </div>
 <?php endif; ?>
 </div>
 </main>
</div>

<!-- Reject Modal -->
<div id="reject-modal" class="modal-overlay hidden">
 <div class="modal">
 <div class="modal-header">
 <h3 class="modal-title">Reject Order</h3>
 <button class="modal-close" data-modal-close></button>
 </div>
 <input type="hidden" id="reject-order-id"/>
 <div class="form-group">
 <label class="form-label">Reason for rejection *</label>
 <textarea id="reject-reason-input" class="form-control" rows="3" placeholder="e.g. Item out of stock, Restaurant closing soon…" required></textarea>
 </div>
 <div id="reject-error" class="alert alert-error hidden"></div>
 <button onclick="submitReject()" class="btn btn-danger btn-block">Confirm Rejection</button>
 </div>
</div>

<!-- Bill Modal -->
<div id="bill-modal" class="modal-overlay hidden">
 <div class="modal">
 <div class="modal-header">
 <h3 class="modal-title">Order Bill</h3>
 <button class="modal-close" data-modal-close></button>
 </div>
 <div id="bill-modal-content"></div>
 <div style="display:flex;gap:.75rem;margin-top:1rem;flex-wrap:wrap;">
 <button onclick="downloadBillFromModal()" class="btn btn-primary">Download PDF</button>
 <button onclick="window.print()" class="btn btn-ghost">Print</button>
 </div>
 </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js" defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js" defer></script>
<script>
const RESTAURANT_ID = <?= (int)$restaurant['id'] ?>;

// Live polling for pending orders
pollPendingOrders(RESTAURANT_ID, data => {
 const badge = document.getElementById('pending-badge');
 if (badge) {
 if (data.pending_count > 0) {
 badge.textContent = `${data.pending_count} pending`;
 badge.classList.remove('hidden');
 } else {
 badge.classList.add('hidden');
 }
 }
 if (data.reload_needed) window.location.reload();
});

function filterOrders(status, btn) {
 document.querySelectorAll('#status-filter-tabs .pill-tab').forEach(b => b.classList.remove('active'));
 btn.classList.add('active');
 document.querySelectorAll('.order-card').forEach(card => {
 card.style.display = (status === 'all' || card.dataset.status === status) ? '' : 'none';
 });
}

async function acceptOrder(id) {
 const fd = new FormData();
 fd.append('order_id', id);
 fd.append('status', 'accepted');
 const res = await fetch('/api/order/update', { method: 'POST', body: fd });
 const data = await res.json();
 if (data.success) { showToast('Order accepted!', 'success'); setTimeout(() => window.location.reload(), 500); }
 else showToast(data.error || 'Failed', 'error');
}

async function completeOrder(id) {
 if (!confirm('Mark this order as given/completed?')) return;
 const fd = new FormData();
 fd.append('order_id', id);
 fd.append('status', 'completed');
 const res = await fetch('/api/order/update', { method: 'POST', body: fd });
 const data = await res.json();
 if (data.success) { showToast('Order completed!', 'success'); setTimeout(() => window.location.reload(), 500); }
 else showToast(data.error || 'Failed', 'error');
}

function openRejectModal(id) {
 document.getElementById('reject-order-id').value = id;
 document.getElementById('reject-reason-input').value = '';
 document.getElementById('reject-error').classList.add('hidden');
 openModal('reject-modal');
}

async function submitReject() {
 const id = document.getElementById('reject-order-id').value;
 const reason = document.getElementById('reject-reason-input').value.trim();
 const errEl = document.getElementById('reject-error');
 if (!reason) { errEl.textContent = 'Please enter a rejection reason.'; errEl.classList.remove('hidden'); return; }
 const fd = new FormData();
 fd.append('order_id', id);
 fd.append('status', 'rejected');
 fd.append('rejection_reason', reason);
 const res = await fetch('/api/order/update', { method: 'POST', body: fd });
 const data = await res.json();
 if (data.success) { closeModal('reject-modal'); showToast('Order rejected.', 'default'); setTimeout(() => window.location.reload(), 500); }
 else { errEl.textContent = data.error || 'Failed'; errEl.classList.remove('hidden'); }
}

async function downloadBill(orderId) {
 const res = await fetch(`/api/order/bill?order_id=${orderId}`);
 const data = await res.json();
 if (!data.success) { showToast('Failed to load bill.', 'error'); return; }
 document.getElementById('bill-modal-content').innerHTML = data.bill_html;
 openModal('bill-modal');
}

async function downloadBillFromModal() {
 const el = document.getElementById('bill-modal-content');
 if (!el) return;
 try {
 const canvas = await html2canvas(el, { scale: 2, backgroundColor: '#ffffff', useCORS: true });
 const imgData = canvas.toDataURL('image/png');
 const { jsPDF } = window.jspdf;
 const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a6' });
 const w = pdf.internal.pageSize.getWidth();
 const h = (canvas.height * w) / canvas.width;
 pdf.addImage(imgData, 'PNG', 0, 0, w, h);
 pdf.save(`Bill.pdf`);
 } catch(e) {
 showToast('PDF failed. Try printing.', 'error');
 }
}
</script>
<?php require __DIR__ . '/../shared/footer.php'; ?>
