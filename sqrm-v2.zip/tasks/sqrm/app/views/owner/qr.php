<?php
$pageTitle = 'QR Code — ' . htmlspecialchars($restaurant['name']);
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
$menuUrl = APP_URL . '/m/' . $restaurant['slug'];
$logoUrl = $restaurant['logo'] ? UPLOAD_URL . 'logos/' . $restaurant['logo'] : '';
require __DIR__ . '/../shared/header.php';
?>
<header class="navbar">
 <div class="navbar-inner">
 <button class="hamburger"><span></span><span></span><span></span></button>
 <a href="/owner/dashboard" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div></div>
 </a>
 <div class="navbar-actions"><button class="theme-toggle"><span class="theme-icon">&#9788;</span></button></div>
 </div>
</header>

<div class="dashboard-layout">
 <div class="sidebar-overlay"></div>
 <aside class="sidebar">
 <nav class="sidebar-nav">
 <a href="/owner/dashboard">Dashboard</a>
 <a href="/owner/restaurants" class="active">My Restaurants</a>
 <a href="/owner/profile">Profile</a>
 <a href="/owner/logout" style="color:var(--error);padding:.7rem 1rem;display:flex;align-items:center;gap:.75rem;">Logout</a>
 </nav>
 </aside>

 <main class="dashboard-content">
 <div class="page-header">
 <h1>QR Code — <?= htmlspecialchars($restaurant['name']) ?></h1>
 <p>Download and print this QR code for your tables. Customers scan to view your menu and order.</p>
 </div>

 <div style="display:flex;gap:2rem;flex-wrap:wrap;align-items:flex-start;">
 <!-- QR Preview Card -->
 <div>
 <div class="qr-preview-card" id="qr-card" style="min-width:300px;">
 <?php if ($logoUrl): ?>
 <img src="<?= htmlspecialchars($logoUrl) ?>" alt="" class="qr-rest-logo" id="qr-logo" crossorigin="anonymous"/>
 <?php else: ?>
 <div style="width:72px;height:72px;border-radius:50%;background:#f0f0f0;display:flex;align-items:center;justify-content:center;font-size:2rem;margin:0 auto .75rem;">S</div>
 <?php endif; ?>
 <div class="qr-rest-name"><?= htmlspecialchars($restaurant['name']) ?></div>
 <div class="qr-rest-info"><?= htmlspecialchars($restaurant['location']) ?></div>
 <div class="qr-rest-info"><?= htmlspecialchars($restaurant['phone']) ?></div>
 <div id="qr-canvas-wrap" style="margin:1.25rem auto;display:flex;justify-content:center;">
 <!-- QR canvas injected by JS -->
 </div>
 <div style="font-size:.75rem;color:#aaa;margin-top:.35rem;">Scan to view menu & order online</div>
 <div class="qr-branding">Powered by <?= htmlspecialchars($siteName) ?> (SQRM)</div>
 </div>

 <div class="qr-actions" style="margin-top:1.5rem;">
 <button onclick="downloadQRpng()" class="btn btn-primary">Download PNG</button>
 <button onclick="downloadQRpdf()" class="btn btn-outline">Download PDF</button>
 </div>
 </div>

 <!-- Instructions -->
 <div class="card" style="max-width:400px;flex:1;min-width:240px;">
 <h3 style="margin-bottom:1rem;">How to Use</h3>
 <div style="display:flex;flex-direction:column;gap:.85rem;">
 <?php foreach (['Download the QR code as PNG or PDF.','Print it and place on your restaurant tables.','Customers scan with any camera app.','They browse your menu, add items, and place an order.','You get a live notification on your orders page.'] as $i => $step): ?>
 <div style="display:flex;gap:.75rem;align-items:flex-start;">
 <div style="width:28px;height:28px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;flex-shrink:0;"><?= $i+1 ?></div>
 <span style="font-size:.9rem;color:var(--text-2);"><?= $step ?></span>
 </div>
 <?php endforeach; ?>
 </div>
 <div style="margin-top:1.5rem;padding:1rem;background:var(--bg-3);border-radius:var(--radius);">
 <div style="font-size:.8rem;font-weight:600;margin-bottom:.35rem;color:var(--text-3);">Menu URL</div>
 <div style="font-size:.85rem;word-break:break-all;color:var(--primary);"><?= htmlspecialchars($menuUrl) ?></div>
 </div>
 </div>
 </div>
 </main>
</div>

<!-- QRCode.js CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js" defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js" defer></script>
<script>
const MENU_URL = '<?= addslashes($menuUrl) ?>';

// Generate QR
const qrWrap = document.getElementById('qr-canvas-wrap');
new QRCode(qrWrap, {
 text: MENU_URL,
 width: 200,
 height: 200,
 colorDark: '#1a1a2e',
 colorLight: '#ffffff',
 correctLevel: QRCode.CorrectLevel.H,
});

async function downloadQRpng() {
 const card = document.getElementById('qr-card');
 try {
 const canvas = await html2canvas(card, { scale: 3, backgroundColor: '#ffffff', useCORS: true, allowTaint: false });
 const link = document.createElement('a');
 link.download = `QR_<?= urlencode($restaurant['name']) ?>.png`;
 link.href = canvas.toDataURL('image/png');
 link.click();
 } catch(e) {
 showToast('PNG download failed. Try PDF instead.', 'error');
 }
}

async function downloadQRpdf() {
 const card = document.getElementById('qr-card');
 try {
 const canvas = await html2canvas(card, { scale: 3, backgroundColor: '#ffffff', useCORS: true, allowTaint: false });
 const imgData = canvas.toDataURL('image/png');
 const { jsPDF } = window.jspdf;
 const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a5' });
 const w = pdf.internal.pageSize.getWidth();
 const h = (canvas.height * w) / canvas.width;
 const yOffset = (pdf.internal.pageSize.getHeight() - h) / 2;
 pdf.addImage(imgData, 'PNG', 0, yOffset > 0 ? yOffset : 0, w, h);
 pdf.save(`QR_<?= urlencode($restaurant['name']) ?>.pdf`);
 } catch(e) {
 showToast('PDF download failed.', 'error');
 }
}
</script>
<?php require __DIR__ . '/../shared/footer.php'; ?>
