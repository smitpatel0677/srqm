<?php
$pageTitle = 'Owner Dashboard';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
?>
<header class="navbar">
 <div class="navbar-inner">
 <button class="hamburger" aria-label="Menu"><span></span><span></span><span></span></button>
 <a href="/owner/dashboard" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div><div class="brand-short">Owner Panel</div></div>
 </a>
 <div class="navbar-actions">
 <button class="theme-toggle"><span class="theme-icon">&#9788;</span></button>
 <a href="/owner/profile" style="display:flex;align-items:center;gap:.5rem;font-size:.875rem;color:var(--text-2);">
 <?php if ($owner['avatar']): ?><img src="<?= htmlspecialchars($owner['avatar']) ?>" style="width:32px;height:32px;border-radius:50%;object-fit:cover;" alt=""/><?php endif; ?>
 <span><?= htmlspecialchars($owner['name']) ?></span>
 </a>
 </div>
 </div>
</header>

<div class="dashboard-layout">
 <div class="sidebar-overlay"></div>
 <aside class="sidebar">
 <div class="sidebar-section">Navigation</div>
 <nav class="sidebar-nav">
 <a href="/owner/dashboard" class="active">Dashboard</a>
 <a href="/owner/restaurants">My Restaurants</a>
 <a href="/owner/profile">Profile</a>
 </nav>
 <div class="sidebar-section" style="margin-top:auto;padding-top:2rem;">
 <a href="/owner/logout" style="display:flex;align-items:center;gap:.75rem;padding:.7rem 1rem;color:var(--error);font-size:.9375rem;">Logout</a>
 </div>
 </aside>

 <main class="dashboard-content">
 <div class="page-header">
 <div class="page-header-row">
 <div>
 <h1>Welcome back, <?= htmlspecialchars(explode(' ', $owner['name'])[0]) ?>! </h1>
 <p>Here's what's happening across your restaurants.</p>
 </div>
 <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;">
 <span class="badge badge-<?= $plan === 'premium' ? 'accent' : ($plan === 'basic' ? 'primary' : 'muted') ?>">
 <?= ucfirst($plan) ?> Plan
 </span>
 <?php if ($plan === 'free'): ?>
 <a href="https://wa.me/<?= htmlspecialchars(Settings::getWhatsappNumber()) ?>?text=<?= urlencode('I would like to purchase Basic Plan') ?>" target="_blank" class="btn btn-sm btn-primary">Upgrade Plan</a>
 <?php endif; ?>
 </div>
 </div>
 </div>

 <div class="stats-row">
 <div class="stat-card"><div class="stat-val"><?= count($restaurants) ?></div><div class="stat-lbl">Restaurants</div></div>
 <div class="stat-card"><div class="stat-val"><?= $totalOrders ?></div><div class="stat-lbl">Total Orders</div></div>
 <div class="stat-card"><div class="stat-val">₹<?= number_format($todayEarnings, 0) ?></div><div class="stat-lbl">Today's Earnings</div></div>
 <div class="stat-card"><div class="stat-val">₹<?= number_format($totalEarnings, 0) ?></div><div class="stat-lbl">Total Earnings</div></div>
 </div>

 <?php if (empty($restaurants)): ?>
 <div class="card text-center" style="padding:3rem;margin-top:1rem;">
 <div style="font-size:3.5rem;margin-bottom:1.25rem;"></div>
 <h3 style="margin-bottom:.5rem;">No restaurants yet</h3>
 <p style="color:var(--text-3);margin-bottom:1.5rem;">Create your first restaurant and start accepting digital orders.</p>
 <a href="/owner/restaurants/create" class="btn btn-primary btn-lg">Create Your First Restaurant</a>
 </div>
 <?php else: ?>
 <div class="page-header-row" style="margin-bottom:1rem;">
 <h2 style="font-size:1.15rem;font-weight:700;">Your Restaurants</h2>
 <?php $maxRest = planMaxRestaurants($plan); if (count($restaurants) < $maxRest): ?>
 <a href="/owner/restaurants/create" class="btn btn-primary btn-sm">Add Restaurant</a>
 <?php endif; ?>
 </div>
 <div class="rest-grid">
 <?php foreach ($restaurants as $r): ?>
 <div class="card" style="display:flex;flex-direction:column;gap:.75rem;">
 <div style="display:flex;gap:1rem;align-items:center;">
 <?php if ($r['logo']): ?><img src="<?= UPLOAD_URL ?>logos/<?= htmlspecialchars($r['logo']) ?>" style="width:52px;height:52px;border-radius:50%;object-fit:cover;border:2px solid var(--primary);flex-shrink:0;" loading="lazy"/><?php else: ?><div style="width:52px;height:52px;background:var(--bg-3);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1rem;font-weight:700;color:var(--text-2);flex-shrink:0;"><?= strtoupper(substr(htmlspecialchars($r['name']),0,1)) ?></div><?php endif; ?>
 <div style="min-width:0;">
 <div style="font-weight:700;font-size:.95rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($r['name']) ?></div>
 <div style="font-size:.8rem;color:var(--text-3);"><?= htmlspecialchars($r['location']) ?></div>
 </div>
 </div>
 <div style="display:flex;flex-wrap:wrap;gap:.5rem;">
 <a href="/owner/restaurants/<?= $r['id'] ?>/orders" class="btn btn-sm btn-primary">Orders</a>
 <a href="/owner/restaurants/<?= $r['id'] ?>/menu" class="btn btn-sm btn-outline">Menu</a>
 <a href="/owner/restaurants/<?= $r['id'] ?>/qr" class="btn btn-sm btn-ghost">QR</a>
 <a href="/owner/restaurants/<?= $r['id'] ?>/edit" class="btn btn-sm btn-ghost">EditEdit</a>
 </div>
 <div style="display:flex;justify-content:space-between;font-size:.8rem;color:var(--text-3);">
 <span> <?= (int)$r['item_count'] ?> items</span>
 <span><?= number_format((float)$r['rating'],1) ?></span>
 <a href="/r/<?= htmlspecialchars($r['slug']) ?>" target="_blank" style="color:var(--primary);">Public Profile </a>
 </div>
 </div>
 <?php endforeach; ?>
 </div>
 <?php endif; ?>

 <!-- Plan feature showcase -->
 <div style="margin-top:2.5rem;">
 <h2 style="font-size:1.15rem;font-weight:700;margin-bottom:1rem;">Platform Features</h2>
 <div class="features-grid" style="grid-template-columns:repeat(auto-fill,minmax(220px,1fr));">
 <?php
 $allFeatures = [
 ['qr_code', '', 'QR Code Generator', 'Generate branded QR codes'],
 ['digital_ordering', '', 'Digital Ordering', 'Customers order from phone'],
 ['order_tracking', '', 'Live Order Alerts', 'Real-time notifications'],
 ['earnings_view', '', 'Earnings View', 'Daily & monthly earnings'],
 ['ratings_reviews', '', 'Ratings & Reviews', 'Customer feedback'],
 ['pdf_receipt', '', 'PDF Receipts', 'Auto-generate bills'],
 ['monthly_analytics', '', 'Monthly Analytics', 'Dashboard & trends'],
 ['best_selling', '', 'Best Selling Items', 'Top performers report'],
 ['categories', 'Edit', 'Menu Categories', 'Organise your menu'],
 ['order_history', '', 'Order History', 'Full order log & filters'],
 ['lifetime_analytics', '', 'Lifetime Analytics', 'All-time performance'],
 ['popular_categories', '', 'Popular Categories', 'Category insights'],
 ['active_hours', '', 'Most Active Hours', 'Peak time analysis'],
 ['custom_theme', '', 'Custom Theme Color', 'Brand your restaurant'],
 ];
 foreach ($allFeatures as [$feature, $icon, $title, $desc]):
 $has = planHas($plan, $feature);
 ?>
 <div class="feature-card <?= !$has ? 'feature-locked-wrap' : '' ?>" style="padding:1.25rem;">
 <?php if (!$has): ?>
 <div class="feature-lock-overlay">
 <span class="lock-icon"></span>
 <span class="lock-text">Upgrade to unlock</span>
 </div>
 <?php endif; ?>
 <div class="feature-icon" style="width:40px;height:40px;font-size:1.2rem;"><?= $icon ?></div>
 <h3 style="font-size:.875rem;margin-top:.65rem;"><?= $title ?></h3>
 <p style="font-size:.8rem;"><?= $desc ?></p>
 </div>
 <?php endforeach; ?>
 </div>
 </div>
 </main>
</div>
<?php require __DIR__ . '/../shared/footer.php'; ?>
