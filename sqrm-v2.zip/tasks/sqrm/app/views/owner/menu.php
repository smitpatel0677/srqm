<?php
$pageTitle = 'Menu Management — ' . htmlspecialchars($restaurant['name']);
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
$hasCategories = planHas($plan, 'categories');
// Group by category
$grouped = [];
foreach ($items as $item) {
 $cat = $item['category_name'] ?: 'Uncategorised';
 $grouped[$cat][] = $item;
}
$itemCount = count($items);
$maxItems = planMaxItems($plan);
$canAdd = $maxItems === PHP_INT_MAX || $itemCount < $maxItems;
?>
<header class="navbar">
 <div class="navbar-inner">
 <button class="hamburger"><span></span><span></span><span></span></button>
 <a href="/owner/dashboard" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div></div>
 </a>
 <div class="navbar-actions"><button class="theme-toggle"><span class="theme-icon">&#9788;</span></button></div>
 </div>
</header>

<div class="dashboard-layout">
 <div class="sidebar-overlay"></div>
 <aside class="sidebar">
 <nav class="sidebar-nav">
 <a href="/owner/dashboard">Dashboard</a>
 <a href="/owner/restaurants" class="active">My Restaurants</a>
 <a href="/owner/profile">Profile</a>
 <a href="/owner/logout" style="color:var(--error);padding:.7rem 1rem;display:flex;align-items:center;gap:.75rem;">Logout</a>
 </nav>
 </aside>

 <main class="dashboard-content">
 <div class="page-header">
 <div class="page-header-row">
 <div>
 <h1>Menu — <?= htmlspecialchars($restaurant['name']) ?></h1>
 <p><?= $itemCount ?> items<?= $maxItems !== PHP_INT_MAX ? " / $maxItems max" : '' ?> &nbsp;|&nbsp;
 <a href="/m/<?= htmlspecialchars($restaurant['slug']) ?>" target="_blank" style="color:var(--primary);">View Public Menu </a>
 </p>
 </div>
 <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
 <?php if ($canAdd): ?>
 <button onclick="openModal('add-item-modal')" class="btn btn-primary btn-sm">Add Item</button>
 <?php else: ?>
 <span class="badge badge-muted">Item limit reached (<?= $itemCount ?>/<?= $maxItems ?>)</span>
 <?php endif; ?>
 <?php if ($hasCategories): ?>
 <button onclick="openModal('categories-modal')" class="btn btn-outline btn-sm">Categories</button>
 <?php endif; ?>
 </div>
 </div>
 </div>

 <?php if ($success ?? false): ?>
 <div class="alert alert-success" data-auto-hide="4000"><?= htmlspecialchars($success) ?></div>
 <?php endif; ?>
 <?php if ($error ?? false): ?>
 <div class="alert alert-error" data-auto-hide="5000"><?= htmlspecialchars($error) ?></div>
 <?php endif; ?>

 <!-- Search -->
 <div style="max-width:400px;margin-bottom:1.25rem;">
 <input type="text" id="menu-admin-search" class="form-control" placeholder="Search items…" oninput="filterAdminMenu(this.value)"/>
 </div>

 <?php if (empty($items)): ?>
 <div class="card text-center" style="padding:3rem;">
 <div style="font-size:2.5rem;margin-bottom:1rem;color:var(--text-3);">&#9749;</div>
 <h3>No menu items yet</h3>
 <p style="color:var(--text-3);">Add your first item to start accepting orders.</p>
 <button onclick="openModal('add-item-modal')" class="btn btn-primary" style="margin-top:1.25rem;">Add First Item</button>
 </div>
 <?php else: ?>
 <div id="admin-menu-list" style="display:flex;flex-direction:column;gap:.75rem;">
 <?php foreach ($grouped as $catName => $catItems): ?>
 <div class="admin-cat-group" data-cat="<?= htmlspecialchars(strtolower($catName)) ?>">
 <?php if ($hasCategories): ?>
 <div style="font-size:.85rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--text-3);padding:.5rem 0 .4rem;border-bottom:2px solid var(--primary);margin-bottom:.65rem;"><?= htmlspecialchars($catName) ?></div>
 <?php endif; ?>
 <?php foreach ($catItems as $item): ?>
 <div class="menu-list-item admin-item-row" data-name="<?= htmlspecialchars(strtolower($item['name'])) ?>">
 <div class="menu-item-thumb">
 <?php if ($item['image']): ?>
 <img data-src="<?= UPLOAD_URL ?>menu/<?= htmlspecialchars($item['image']) ?>" src="/assets/images/placeholder.webp" loading="lazy" alt=""/>
 <?php else: ?><span style="font-size:.85rem;font-weight:600;color:var(--text-3);"><?= strtoupper(substr(htmlspecialchars($item['name']),0,1)) ?></span><?php endif; ?>
 </div>
 <div class="menu-item-info" style="flex:1;min-width:0;">
 <div class="name"><?= htmlspecialchars($item['name']) ?></div>
 <?php if ($item['description']): ?><div class="desc"><?= htmlspecialchars($item['description']) ?></div><?php endif; ?>
 <div class="price"><?= formatPrice($item['price']) ?></div>
 </div>
 <div style="display:flex;gap:.4rem;flex-shrink:0;">
 <button onclick="openEditItem(<?= htmlspecialchars(json_encode($item)) ?>)" class="btn btn-sm btn-ghost">EditEdit</button>
 <button onclick="deleteItem(<?= $item['id'] ?>, this)" class="btn btn-sm btn-danger"
 data-confirm="Delete '<?= htmlspecialchars($item['name']) ?>'?">Delete Edit</button>
 </div>
 </div>
 <?php endforeach; ?>
 </div>
 <?php endforeach; ?>
 </div>
 <?php endif; ?>
 </main>
</div>

<!-- Add Item Modal -->
<div id="add-item-modal" class="modal-overlay hidden">
 <div class="modal">
 <div class="modal-header">
 <h3 class="modal-title">Add Menu Item</h3>
 <button class="modal-close" data-modal-close></button>
 </div>
 <form method="POST" enctype="multipart/form-data" action="/owner/restaurants/<?= $restaurant['id'] ?>/menu/add">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <div class="form-group">
 <label class="form-label">Item Name *</label>
 <input type="text" name="name" class="form-control" placeholder="e.g. Butter Chicken" required/>
 </div>
 <div class="form-group">
 <label class="form-label">Item Image *</label>
 <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;">
 <div id="add-img-preview" style="width:72px;height:72px;background:var(--bg-3);border-radius:var(--radius);display:flex;align-items:center;justify-content:center;font-size:1.5rem;border:2px dashed var(--border);overflow:hidden;">&#128247;</div>
 <input type="file" name="image" accept="image/*" required onchange="previewItemImg(this,'add-img-preview')"/>
 </div>
 <span class="form-hint">Auto-converted to WebP</span>
 </div>
 <div class="form-group">
 <label class="form-label">Price (₹) *</label>
 <input type="number" name="price" class="form-control" placeholder="0.00" step="0.01" min="0" required/>
 </div>
 <div class="form-group">
 <label class="form-label">Description (optional)</label>
 <input type="text" name="description" class="form-control" placeholder="Short description…"/>
 </div>
 <?php if ($hasCategories && !empty($categories)): ?>
 <div class="form-group">
 <label class="form-label">Category</label>
 <select name="category_id" class="form-control">
 <option value="">No Category</option>
 <?php foreach ($categories as $cat): ?>
 <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
 <?php endforeach; ?>
 </select>
 </div>
 <?php elseif (!$hasCategories): ?>
 <div class="alert alert-info" style="font-size:.82rem;">Upgrade to Basic plan to use menu categories.</div>
 <?php endif; ?>
 <button type="submit" class="btn btn-primary btn-block">Add Item</button>
 </form>
 </div>
</div>

<!-- Edit Item Modal -->
<div id="edit-item-modal" class="modal-overlay hidden">
 <div class="modal">
 <div class="modal-header">
 <h3 class="modal-title">EditEdit Menu Item</h3>
 <button class="modal-close" data-modal-close></button>
 </div>
 <form method="POST" enctype="multipart/form-data" id="edit-item-form" action="">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <input type="hidden" name="_method" value="PUT"/>
 <div class="form-group">
 <label class="form-label">Item Name *</label>
 <input type="text" name="name" id="edit-item-name" class="form-control" required/>
 </div>
 <div class="form-group">
 <label class="form-label">Item Image</label>
 <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;">
 <div id="edit-img-preview" style="width:72px;height:72px;background:var(--bg-3);border-radius:var(--radius);display:flex;align-items:center;justify-content:center;font-size:1.5rem;border:2px dashed var(--border);overflow:hidden;">&#128247;</div>
 <input type="file" name="image" accept="image/*" onchange="previewItemImg(this,'edit-img-preview')"/>
 </div>
 <span class="form-hint">Leave empty to keep current image</span>
 </div>
 <div class="form-group">
 <label class="form-label">Price (₹) *</label>
 <input type="number" name="price" id="edit-item-price" class="form-control" step="0.01" min="0" required/>
 </div>
 <div class="form-group">
 <label class="form-label">Description</label>
 <input type="text" name="description" id="edit-item-desc" class="form-control" placeholder="Short description…"/>
 </div>
 <?php if ($hasCategories && !empty($categories)): ?>
 <div class="form-group">
 <label class="form-label">Category</label>
 <select name="category_id" id="edit-item-cat" class="form-control">
 <option value="">No Category</option>
 <?php foreach ($categories as $cat): ?>
 <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
 <?php endforeach; ?>
 </select>
 </div>
 <?php endif; ?>
 <button type="submit" class="btn btn-primary btn-block">Save Changes</button>
 </form>
 </div>
</div>

<!-- Categories Modal -->
<?php if ($hasCategories): ?>
<div id="categories-modal" class="modal-overlay hidden">
 <div class="modal">
 <div class="modal-header">
 <h3 class="modal-title">Manage Categories</h3>
 <button class="modal-close" data-modal-close></button>
 </div>
 <form method="POST" action="/owner/restaurants/<?= $restaurant['id'] ?>/categories/add" style="display:flex;gap:.5rem;margin-bottom:1rem;">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <input type="text" name="name" class="form-control" placeholder="New category name" required/>
 <button type="submit" class="btn btn-primary btn-sm" style="white-space:nowrap;">Add</button>
 </form>
 <div style="display:flex;flex-direction:column;gap:.5rem;">
 <?php if (empty($categories)): ?>
 <p style="color:var(--text-3);text-align:center;padding:1.5rem;">No categories yet.</p>
 <?php else: ?>
 <?php foreach ($categories as $cat): ?>
 <div style="display:flex;align-items:center;justify-content:space-between;padding:.6rem 1rem;background:var(--bg-2);border-radius:var(--radius);border:1px solid var(--border);">
 <span style="font-weight:500;"><?= htmlspecialchars($cat['name']) ?></span>
 <form method="POST" action="/owner/restaurants/<?= $restaurant['id'] ?>/categories/<?= $cat['id'] ?>/delete" style="margin:0;">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <button type="submit" class="btn btn-sm btn-danger"
 data-confirm="Delete category '<?= htmlspecialchars($cat['name']) ?>'?">Delete Edit</button>
 </form>
 </div>
 <?php endforeach; ?>
 <?php endif; ?>
 </div>
 </div>
</div>
<?php endif; ?>

<script>
function filterAdminMenu(q) {
 q = q.toLowerCase().trim();
 document.querySelectorAll('.admin-item-row').forEach(row => {
 row.style.display = (!q || row.dataset.name.includes(q)) ? '' : 'none';
 });
}

function previewItemImg(input, previewId) {
 if (!input.files[0]) return;
 const reader = new FileReader();
 reader.onload = e => {
 const wrap = document.getElementById(previewId);
 wrap.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;"/>`;
 };
 reader.readAsDataURL(input.files[0]);
}

function openEditItem(item) {
 document.getElementById('edit-item-form').action = `/owner/restaurants/<?= $restaurant['id'] ?>/menu/${item.id}/edit`;
 document.getElementById('edit-item-name').value = item.name;
 document.getElementById('edit-item-price').value = item.price;
 document.getElementById('edit-item-desc').value = item.description || '';
 const catSel = document.getElementById('edit-item-cat');
 if (catSel) catSel.value = item.category_id || '';
 const preview = document.getElementById('edit-img-preview');
 if (item.image) {
 preview.innerHTML = `<img src="<?= UPLOAD_URL ?>menu/${item.image}" style="width:100%;height:100%;object-fit:cover;"/>`;
 } else {
 preview.innerHTML = 'Edit';
 }
 openModal('edit-item-modal');
}

async function deleteItem(id, btn) {
 if (!confirm(`Delete this item?`)) return;
 const fd = new FormData();
 fd.append('item_id', id);
 fd.append('csrf_token', '<?= csrf() ?>');
 const res = await fetch(`/owner/restaurants/<?= $restaurant['id'] ?>/menu/${id}/delete`, { method: 'POST', body: fd });
 const data = await res.json();
 if (data.success) {
 btn.closest('.admin-item-row').remove();
 showToast('Item deleted.', 'default');
 } else {
 showToast(data.error || 'Failed to delete item.', 'error');
 }
}
</script>
<?php require __DIR__ . '/../shared/footer.php'; ?>
