<?php
$pageTitle = 'My Restaurants';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
$canCreate = count($restaurants) < $maxRest;
?>
<header class="navbar">
 <div class="navbar-inner">
 <button class="hamburger"><span></span><span></span><span></span></button>
 <a href="/owner/dashboard" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div><div class="brand-short">Owner Panel</div></div>
 </a>
 <div class="navbar-actions"><button class="theme-toggle"><span class="theme-icon">&#9788;</span></button></div>
 </div>
</header>

<div class="dashboard-layout">
 <div class="sidebar-overlay"></div>
 <aside class="sidebar">
 <nav class="sidebar-nav">
 <a href="/owner/dashboard">Dashboard</a>
 <a href="/owner/restaurants" class="active">My Restaurants</a>
 <a href="/owner/profile">Profile</a>
 <a href="/owner/logout" style="color:var(--error);margin-top:auto;padding:.7rem 1rem;display:flex;align-items:center;gap:.75rem;">Logout</a>
 </nav>
 </aside>

 <main class="dashboard-content">
 <div class="page-header">
 <div class="page-header-row">
 <div><h1>My Restaurants</h1><p>Manage all your restaurants from here.</p></div>
 <?php if ($canCreate): ?>
 <a href="/owner/restaurants/create" class="btn btn-primary">Add Restaurant</a>
 <?php else: ?>
 <div class="badge badge-muted">Plan limit reached (<?= count($restaurants) ?>/<?= $maxRest === PHP_INT_MAX ? '∞' : $maxRest ?>)</div>
 <?php endif; ?>
 </div>
 </div>

 <?php if (!$canCreate): ?>
 <div class="alert alert-warning">
 You've reached your plan's restaurant limit. Delete a restaurant or
 <a href="https://wa.me/<?= htmlspecialchars(Settings::getWhatsappNumber()) ?>?text=<?= urlencode('I would like to upgrade my plan') ?>" style="color:var(--warning);font-weight:600;">upgrade your plan</a> to add more.
 </div>
 <?php endif; ?>

 <?php if (empty($restaurants)): ?>
 <div class="card text-center" style="padding:3rem;">
 <div style="font-size:3rem;margin-bottom:1rem;"></div>
 <h3>No restaurants yet</h3>
 <a href="/owner/restaurants/create" class="btn btn-primary" style="margin-top:1.25rem;"> Create First Restaurant</a>
 </div>
 <?php else: ?>
 <div class="table-wrap">
 <table>
 <thead><tr><th>Restaurant</th><th>Location</th><th>Items</th><th>Rating</th><th>Status</th><th>Actions</th></tr></thead>
 <tbody>
 <?php foreach ($restaurants as $r): ?>
 <tr>
 <td>
 <div style="display:flex;align-items:center;gap:.75rem;">
 <?php if ($r['logo']): ?><img src="<?= UPLOAD_URL ?>logos/<?= htmlspecialchars($r['logo']) ?>" style="width:36px;height:36px;border-radius:50%;object-fit:cover;" loading="lazy"/><?php else: ?><div style="width:36px;height:36px;background:var(--bg-3);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem;font-weight:700;color:var(--text-2);"><?= strtoupper(substr(htmlspecialchars($r['name']),0,1)) ?></div><?php endif; ?>
 <strong><?= htmlspecialchars($r['name']) ?></strong>
 </div>
 </td>
 <td><?= htmlspecialchars($r['location']) ?></td>
 <td><?= (int)$r['item_count'] ?></td>
 <td><?= number_format((float)$r['rating'],1) ?> (<?= (int)$r['total_reviews'] ?>)</td>
 <td><?= $r['is_suspended'] ? '<span class="badge badge-error">Suspended</span>' : '<span class="badge badge-accent">Active</span>' ?></td>
 <td>
 <div class="td-actions">
 <a href="/owner/restaurants/<?= $r['id'] ?>/orders" class="btn btn-sm btn-primary">Orders</a>
 <a href="/owner/restaurants/<?= $r['id'] ?>/menu" class="btn btn-sm btn-outline">Menu</a>
 <a href="/owner/restaurants/<?= $r['id'] ?>/qr" class="btn btn-sm btn-ghost">QR</a>
 <a href="/owner/restaurants/<?= $r['id'] ?>/edit" class="btn btn-sm btn-ghost">Edit</a>
 <a href="/r/<?= htmlspecialchars($r['slug']) ?>" target="_blank" class="btn btn-sm btn-ghost" title="Public Profile"></a>
 </div>
 </td>
 </tr>
 <?php endforeach; ?>
 </tbody>
 </table>
 </div>
 <?php endif; ?>
 </main>
</div>
<?php require __DIR__ . '/../shared/footer.php'; ?>
