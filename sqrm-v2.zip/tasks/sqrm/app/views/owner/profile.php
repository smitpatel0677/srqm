<?php
$pageTitle = 'My Profile';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
?>
<header class="navbar">
 <div class="navbar-inner">
 <button class="hamburger"><span></span><span></span><span></span></button>
 <a href="/owner/dashboard" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div></div>
 </a>
 <div class="navbar-actions"><button class="theme-toggle"><span class="theme-icon">&#9788;</span></button></div>
 </div>
</header>

<div class="dashboard-layout">
 <div class="sidebar-overlay"></div>
 <aside class="sidebar">
 <nav class="sidebar-nav">
 <a href="/owner/dashboard">Dashboard</a>
 <a href="/owner/restaurants">My Restaurants</a>
 <a href="/owner/profile" class="active">Profile</a>
 <a href="/owner/logout" style="color:var(--error);padding:.7rem 1rem;display:flex;align-items:center;gap:.75rem;">Logout</a>
 </nav>
 </aside>

 <main class="dashboard-content">
 <div class="page-header">
 <h1>My Profile</h1>
 </div>

 <!-- Avatar + info -->
 <div class="card" style="max-width:560px;margin-bottom:1.5rem;">
 <div style="display:flex;align-items:center;gap:1.25rem;margin-bottom:1.5rem;flex-wrap:wrap;">
 <?php if ($owner['avatar']): ?>
 <img src="<?= htmlspecialchars($owner['avatar']) ?>" style="width:72px;height:72px;border-radius:50%;object-fit:cover;border:3px solid var(--primary);" alt=""/>
 <?php else: ?>
 <div style="width:72px;height:72px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;font-size:2rem;color:#fff;font-weight:800;"><?= strtoupper(substr($owner['name'],0,1)) ?></div>
 <?php endif; ?>
 <div>
 <div style="font-size:1.1rem;font-weight:700;"><?= htmlspecialchars($owner['name']) ?></div>
 <div style="color:var(--text-3);font-size:.875rem;"> <?= htmlspecialchars($owner['email']) ?></div>
 <span class="badge badge-<?= $owner['plan'] === 'premium' ? 'accent' : ($owner['plan'] === 'basic' ? 'primary' : 'muted') ?>" style="margin-top:.35rem;">
 <?= ucfirst($owner['plan']) ?> Plan
 </span>
 </div>
 </div>

 <?php if ($error): ?>
 <div class="alert alert-error" data-auto-hide="5000"><?= htmlspecialchars($error) ?></div>
 <?php endif; ?>
 <?php if ($success): ?>
 <div class="alert alert-success" data-auto-hide="4000"><?= htmlspecialchars($success) ?></div>
 <?php endif; ?>

 <form method="POST" action="/owner/profile">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <div class="form-group">
 <label class="form-label">Full Name *</label>
 <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($owner['name']) ?>" required/>
 </div>
 <div class="form-group">
 <label class="form-label">Phone Number *</label>
 <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($owner['phone'] ?? '') ?>" placeholder="10-digit mobile" required/>
 </div>
 <div class="form-group">
 <label class="form-label">Email</label>
 <input type="email" class="form-control" value="<?= htmlspecialchars($owner['email']) ?>" disabled style="opacity:.6;cursor:not-allowed;"/>
 <span class="form-hint">Email is linked to your Google account and cannot be changed here.</span>
 </div>
 <button type="submit" class="btn btn-primary"> Save Profile</button>
 </form>
 </div>

 <!-- Plan info -->
 <div class="card" style="max-width:560px;margin-bottom:1.5rem;">
 <h3 style="margin-bottom:1rem;"> Your Plan</h3>
 <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem;">
 <div>
 <div style="font-size:1.2rem;font-weight:800;"><?= ucfirst($owner['plan']) ?> Plan</div>
 <?php if ($owner['plan_expires_at']): ?>
 <div style="font-size:.85rem;color:var(--text-3);">Expires: <?= date('d M Y', strtotime($owner['plan_expires_at'])) ?></div>
 <?php endif; ?>
 </div>
 <?php if ($owner['plan'] !== 'premium'): ?>
 <a href="https://wa.me/<?= htmlspecialchars(Settings::getWhatsappNumber()) ?>?text=<?= urlencode('I would like to upgrade my plan') ?>" target="_blank" class="btn btn-primary btn-sm">Upgrade Plan</a>
 <?php endif; ?>
 </div>
 </div>

 <!-- Danger zone -->
 <div class="card" style="max-width:560px;border-color:var(--error);">
 <h3 style="color:var(--error);margin-bottom:.75rem;">Danger Zone</h3>
 <p style="font-size:.875rem;color:var(--text-2);margin-bottom:1rem;">
 Deleting your account is permanent. All your restaurants, menus, and orders will be permanently removed.
 </p>
 <form method="POST" action="/owner/delete-account">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>
 <button type="submit" class="btn btn-danger btn-sm"
 data-confirm="Are you absolutely sure you want to delete your account? This action cannot be undone.">
 Delete Edit Delete My Account
 </button>
 </form>
 </div>
 </main>
</div>
<?php require __DIR__ . '/../shared/footer.php'; ?>
