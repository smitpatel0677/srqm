<?php
$pageTitle = 'Create Restaurant';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
?>
<header class="navbar">
 <div class="navbar-inner">
 <button class="hamburger"><span></span><span></span><span></span></button>
 <a href="/owner/dashboard" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div></div>
 </a>
 <div class="navbar-actions"><button class="theme-toggle"><span class="theme-icon">&#9788;</span></button></div>
 </div>
</header>

<div class="dashboard-layout">
 <div class="sidebar-overlay"></div>
 <aside class="sidebar">
 <nav class="sidebar-nav">
 <a href="/owner/dashboard">Dashboard</a>
 <a href="/owner/restaurants" class="active">My Restaurants</a>
 <a href="/owner/profile">Profile</a>
 <a href="/owner/logout" style="color:var(--error);padding:.7rem 1rem;display:flex;align-items:center;gap:.75rem;">Logout</a>
 </nav>
 </aside>

 <main class="dashboard-content">
 <div class="page-header">
 <h1> Create Restaurant</h1>
 <p>Fill in your restaurant details to get started with your digital menu.</p>
 </div>

 <div class="card" style="max-width:640px;">
 <?php if ($error): ?>
 <div class="alert alert-error" data-auto-hide="5000"><?= htmlspecialchars($error) ?></div>
 <?php endif; ?>

 <form method="POST" enctype="multipart/form-data" action="/owner/restaurants/create">
 <input type="hidden" name="csrf_token" value="<?= csrf() ?>"/>

 <div class="form-group">
 <label class="form-label">Restaurant Name *</label>
 <input type="text" name="name" class="form-control" placeholder="e.g. Spice Garden" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required/>
 </div>

 <div class="form-group">
 <label class="form-label">Restaurant Logo *</label>
 <div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap;">
 <div id="logo-preview-wrap" style="width:80px;height:80px;border-radius:50%;overflow:hidden;background:var(--bg-3);display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:var(--text-3);border:2px dashed var(--border);">&#128247;</div>
 <div>
 <input type="file" name="logo" accept="image/*" data-preview="logo-preview-img" onchange="previewLogo(this)" required/>
 <span class="form-hint">Any image format — auto-converted to WebP</span>
 </div>
 </div>
 <img id="logo-preview-img" src="" alt="" class="hidden" style="width:80px;height:80px;border-radius:50%;object-fit:cover;margin-top:.5rem;border:2px solid var(--primary);"/>
 </div>

 <div class="form-group">
 <label class="form-label">Location / Address *</label>
 <input type="text" name="location" class="form-control" placeholder="e.g. MG Road, Bangalore" value="<?= htmlspecialchars($_POST['location'] ?? '') ?>" required/>
 </div>

 <div class="form-group">
 <label class="form-label">Phone Number *</label>
 <input type="tel" name="phone" class="form-control" placeholder="10-digit mobile number" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required/>
 </div>

 <div class="form-group">
 <label class="form-label">Online Payment Info</label>
 <textarea name="payment_info" class="form-control" rows="2" placeholder="e.g. UPI: owner@upi | Google Pay: 9876543210"><?= htmlspecialchars($_POST['payment_info'] ?? '') ?></textarea>
 <span class="form-hint">Shown to customers who choose online payment</span>
 </div>

 <?php if (planHas($plan, 'custom_theme')): ?>
 <div class="form-group">
 <label class="form-label">Theme Color</label>
 <input type="color" name="theme_color" class="form-control" value="#D35400" style="height:48px;padding:.25rem;"/>
 </div>
 <?php endif; ?>

 <div style="display:flex;gap:.75rem;flex-wrap:wrap;">
 <button type="submit" class="btn btn-primary">Create Restaurant</button>
 <a href="/owner/restaurants" class="btn btn-ghost">Cancel</a>
 </div>
 </form>
 </div>
 </main>
</div>

<script>
function previewLogo(input) {
 if (!input.files[0]) return;
 const reader = new FileReader();
 reader.onload = e => {
 const wrap = document.getElementById('logo-preview-wrap');
 const img = document.getElementById('logo-preview-img');
 wrap.innerHTML = '';
 wrap.style.border = '2px solid var(--primary)';
 const i = document.createElement('img');
 i.src = e.target.result;
 i.style.cssText = 'width:100%;height:100%;object-fit:cover;';
 wrap.appendChild(i);
 img.src = e.target.result;
 };
 reader.readAsDataURL(input.files[0]);
}
</script>
<?php require __DIR__ . '/../shared/footer.php'; ?>
