<?php
// Sitemap XML view — output by HomeController::sitemap()
// Header already sent: Content-Type: application/xml
echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
 <!-- Static pages -->
 <url>
 <loc><?= APP_URL ?>/</loc>
 <changefreq>weekly</changefreq>
 <priority>1.0</priority>
 <lastmod><?= date('Y-m-d') ?></lastmod>
 </url>
 <url>
 <loc><?= APP_URL ?>/restaurants</loc>
 <changefreq>daily</changefreq>
 <priority>0.9</priority>
 <lastmod><?= date('Y-m-d') ?></lastmod>
 </url>
 <url>
 <loc><?= APP_URL ?>/privacy-policy</loc>
 <changefreq>yearly</changefreq>
 <priority>0.3</priority>
 </url>
 <url>
 <loc><?= APP_URL ?>/cookie-policy</loc>
 <changefreq>yearly</changefreq>
 <priority>0.3</priority>
 </url>
 <!-- Dynamic restaurant pages -->
 <?php foreach ($restaurants as $r): ?>
 <url>
 <loc><?= APP_URL ?>/r/<?= htmlspecialchars($r['slug']) ?></loc>
 <changefreq>weekly</changefreq>
 <priority>0.8</priority>
 <?php if ($r['updated_at']): ?>
 <lastmod><?= date('Y-m-d', strtotime($r['updated_at'])) ?></lastmod>
 <?php endif; ?>
 </url>
 <url>
 <loc><?= APP_URL ?>/m/<?= htmlspecialchars($r['slug']) ?></loc>
 <changefreq>daily</changefreq>
 <priority>0.7</priority>
 <?php if ($r['updated_at']): ?>
 <lastmod><?= date('Y-m-d', strtotime($r['updated_at'])) ?></lastmod>
 <?php endif; ?>
 </url>
 <?php endforeach; ?>
</urlset>
