<?php
$pageTitle = 'Privacy Policy';
$pageDesc = 'Privacy Policy for Saksham Digital Menu (SQRM).';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
?>
<header class="navbar">
 <div class="navbar-inner">
 <a href="/" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div></div>
 </a>
 <div class="navbar-actions"><button class="theme-toggle"><span class="theme-icon">&#9788;</span></button></div>
 </div>
</header>
<main class="container" style="padding:3rem 1.25rem;max-width:800px;">
 <h1 style="font-size:2rem;font-weight:800;margin-bottom:.5rem;">Privacy Policy</h1>
 <p style="color:var(--text-3);margin-bottom:2.5rem;">Last updated: <?= date('d F Y') ?></p>

 <?php
 $sections = [
 ['Information We Collect', 'We collect information you provide directly, including your name, email address (via Google OAuth for restaurant owners), phone number, and restaurant details. We also collect information about your use of the platform, including orders placed, menu items added, and reviews submitted.'],
 ['How We Use Your Information', 'We use collected information to: provide and operate the Saksham Digital Menu platform, process restaurant orders and generate receipts, enable restaurant owners to manage menus and track performance, display customer reviews, and improve our services.'],
 ['Google OAuth', 'Restaurant owners log in using Google OAuth. We receive your name, email, and profile picture from Google. We do not store your Google password. Your Google account settings govern how your data is shared with us.'],
 ['Order Data', 'Customer names and phone numbers are collected at order time. This information is shared with the relevant restaurant owner to fulfill the order. We store this data to enable order tracking, receipt generation, and review submissions.'],
 ['Data Storage', 'All data is stored securely on our servers. Restaurant logos and menu item images are stored locally on our platform. We take reasonable measures to protect your data from unauthorised access.'],
 ['Sharing of Information', 'We do not sell your personal information to third parties. Customer order details are shared with the restaurant owner. We may disclose information if required by law.'],
 ['Cookies', 'We use cookies to maintain session state for logged-in restaurant owners and administrators. See our Cookie Policy for details.'],
 ['Data Retention', 'We retain your data as long as your account is active. If you delete your restaurant owner account, your data is permanently removed. Customers may contact us to request deletion of their order data.'],
 ['Your Rights', 'You have the right to access, correct, or delete your personal data. Restaurant owners can update profile information in their dashboard. To request data deletion, contact us at the email below.'],
 ['Contact Us', 'For privacy-related questions, email us at: ' . htmlspecialchars(Settings::getSupportEmail())],
 ];
 foreach ($sections as [$title, $body]):
 ?>
 <section style="margin-bottom:2rem;">
 <h2 style="font-size:1.15rem;font-weight:700;margin-bottom:.65rem;color:var(--primary);"><?= $title ?></h2>
 <p style="color:var(--text-2);line-height:1.75;"><?= htmlspecialchars($body) ?></p>
 </section>
 <?php endforeach; ?>
</main>
<?php require __DIR__ . '/../shared/footer.php'; ?>
