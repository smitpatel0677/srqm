<?php
$pageTitle = 'Digital QR Menu Platform for Restaurants';
$pageDesc = 'Saksham Digital Menu (SQRM) — Create a digital QR menu for your restaurant in minutes. Customers scan, order and pay. No app required.';
require_once __DIR__ . '/../../../includes/Settings.php';
require __DIR__ . '/../shared/header.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
$supportNumber = Settings::getSupportNumber();
$whatsapp = Settings::getWhatsappNumber();
?>

<!-- ── Navbar ─────────────────────────────────────────────── -->
<header class="navbar">
 <div class="navbar-inner">
 <a href="/" class="navbar-brand">
 <?php if ($siteLogo): ?>
 <img src="<?= htmlspecialchars($siteLogo) ?>" alt="<?= htmlspecialchars($siteName) ?>" loading="lazy"/>
 <?php else: ?>
 <div style="width:40px;height:40px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:1rem;">S</div>
 <?php endif; ?>
 <div>
 <div class="brand-text"><?= htmlspecialchars($siteName) ?></div>
 <div class="brand-short">SQRM</div>
 </div>
 </a>
 <div class="navbar-actions">
 <button class="theme-toggle" aria-label="Toggle theme"><span class="theme-icon">&#9788;</span></button>
 <a href="/restaurants" class="btn btn-ghost btn-sm">Browse Restaurants</a>
 <a href="/owner/login" class="btn btn-primary btn-sm">Get Started</a>
 </div>
 </div>
</header>

<!-- ── Hero ──────────────────────────────────────────────── -->
<section class="hero">
 <div class="container">
 <div class="hero-inner">
 <div class="hero-badge">India's Smartest Digital Menu Platform</div>
 <h1>Transform Your Restaurant With <span>Digital QR Menus</span></h1>
 <p>Create stunning digital menus, accept orders, track revenue, and delight customers — all in one platform. No app required for customers.</p>
 <div class="hero-actions">
 <a href="/owner/login" class="btn btn-primary btn-lg">Get Started Free</a>
 <a href="/restaurants" class="btn btn-outline btn-lg" style="color:#fff;border-color:rgba(255,255,255,.5);">Browse Restaurants</a>
 </div>

 <div class="hero-search">
 <h3>Find a Restaurant Near You</h3>
 <form class="hero-search-form" action="/restaurants" method="GET">
 <input type="text" name="q" placeholder="Search restaurant name…" autocomplete="off"/>
 <button type="submit" class="btn btn-primary">Search</button>
 </form>
 </div>

 <div class="hero-stats">
 <div class="hero-stat"><div class="num">Free</div><div class="lbl">To Start</div></div>
 <div class="hero-stat"><div class="num">QR</div><div class="lbl">Instant Codes</div></div>
 <div class="hero-stat"><div class="num">Live</div><div class="lbl">Order Alerts</div></div>
 <div class="hero-stat"><div class="num">PDF</div><div class="lbl">Auto Receipts</div></div>
 </div>
 </div>
 </div>
</section>

<!-- ── Featured Restaurants ──────────────────────────────── -->
<?php if (!empty($featuredRestaurants)): ?>
<section class="section section-alt">
 <div class="container">
 <div class="section-header">
 <span class="eyebrow">Explore</span>
 <h2>Popular Restaurants</h2>
 <p>Discover restaurants near you with digital menus. Scan QR code, browse menu and order instantly.</p>
 </div>
 <div class="rest-grid">
 <?php foreach ($featuredRestaurants as $r): ?>
 <a href="/r/<?= htmlspecialchars($r['slug']) ?>" class="rest-card">
 <div class="rest-card-img">
 <?php if ($r['logo']): ?>
 <img data-src="<?= UPLOAD_URL ?>logos/<?= htmlspecialchars($r['logo']) ?>" src="/assets/images/placeholder.webp" alt="<?= htmlspecialchars($r['name']) ?>" loading="lazy"/>
 <?php else: ?>
 <span><?= strtoupper(substr(htmlspecialchars($r['name']),0,1)) ?></span>
 <?php endif; ?>
 </div>
 <div class="rest-card-body">
 <div class="rest-card-name"><?= htmlspecialchars($r['name']) ?></div>
 <div class="rest-card-loc"><?= htmlspecialchars($r['location']) ?></div>
 <div class="rest-card-rating">
 <?php echo starHtml((float)$r['rating']); ?>
 <span style="color:var(--text-3);font-size:.8rem;">(<?= (int)$r['total_reviews'] ?> reviews)</span>
 </div>
 </div>
 </a>
 <?php endforeach; ?>
 </div>
 <div class="text-center" style="margin-top:2rem;">
 <a href="/restaurants" class="btn btn-outline">View All Restaurants →</a>
 </div>
 </div>
</section>
<?php endif; ?>

<!-- ── Pricing Plans ──────────────────────────────────────── -->
<section class="section" id="pricing">
 <div class="container">
 <div class="section-header">
 <span class="eyebrow">Pricing</span>
 <h2>Simple, Transparent Pricing</h2>
 <p>Start free and grow at your own pace. No hidden charges, no setup fees.</p>
 </div>
 <div class="plans-grid">
 <!-- Free -->
 <div class="plan-card">
 <div class="plan-name">Free Plan</div>
 <div class="plan-price">₹0 <span>/month</span></div>
 <div class="plan-desc">Perfect to get started</div>
 <ul class="plan-features">
 <?php foreach(['1 Restaurant','20 Menu Items','QR Code Generation & Download','Customer Digital Ordering','Live Order Tracking','Daily & Monthly Earnings View','Customer Ratings & Reviews','PDF Receipt per Order'] as $f): ?>
 <li class="plan-feature"><span class="check"> </span> <?= $f ?></li>
 <?php endforeach; ?>
 </ul>
 <a href="/owner/login" class="btn btn-outline btn-block">Get Started Free</a>
 </div>

 <!-- Basic -->
 <div class="plan-card popular">
 <div class="plan-badge">Most Popular</div>
 <div class="plan-name">Basic Plan</div>
 <div class="plan-price">₹29 <span>/month</span></div>
 <div class="plan-desc">For growing restaurants</div>
 <ul class="plan-features">
 <?php foreach(['Up to 5 Restaurants','Unlimited Menu Items','Monthly Analytics Dashboard','Best Selling Items Report','Menu Categories Management','Order History & Filters'] as $f): ?>
 <li class="plan-feature"><span class="check"> </span> <?= $f ?></li>
 <?php endforeach; ?>
 </ul>
 <a href="https://wa.me/<?= htmlspecialchars($whatsapp) ?>?text=<?= urlencode('I would like to purchase Basic Plan') ?>" target="_blank" rel="noopener" class="btn btn-primary btn-block">Get Basic Plan →</a>
 </div>

 <!-- Premium -->
 <div class="plan-card">
 <div class="plan-name">Premium Plan</div>
 <div class="plan-price">₹49 <span>/month</span></div>
 <div class="plan-desc">For serious restaurant chains</div>
 <ul class="plan-features">
 <?php foreach(['Unlimited Restaurants','Unlimited Menu Items','Lifetime Analytics','Popular Categories Insights','Most Active Hours Report','Custom Restaurant Theme Color'] as $f): ?>
 <li class="plan-feature"><span class="check"> </span> <?= $f ?></li>
 <?php endforeach; ?>
 </ul>
 <a href="https://wa.me/<?= htmlspecialchars($whatsapp) ?>?text=<?= urlencode('I would like to purchase Premium Plan') ?>" target="_blank" rel="noopener" class="btn btn-outline btn-block">Get Premium Plan →</a>
 </div>
 </div>
 </div>
</section>

<!-- ── Features ───────────────────────────────────────────── -->
<section class="section section-alt" id="features">
 <div class="container">
 <div class="section-header">
 <span class="eyebrow">Features</span>
 <h2>Everything You Need to Digitise Your Restaurant</h2>
 <p>One platform that handles menus, orders, payments, analytics and customer experience.</p>
 </div>
 <div class="features-grid">
 <?php
 $features = [
 ['','QR Menu Generator','Instant QR codes for your tables. Customers scan & order — no app required.'],
 ['','Digital Ordering','Customers add items to cart and place orders directly from their phone.'],
 ['','Live Order Alerts','Real-time notifications with sound when new orders arrive at your dashboard.'],
 ['','Revenue Analytics','Track daily, monthly, and lifetime earnings. See your best-selling items.'],
 ['','Ratings & Reviews','Collect customer feedback. Build your online reputation effortlessly.'],
 ['','PDF Receipts','Auto-generate and print order receipts in one click. Professional & styled.'],
 ['Edit','QR Download','Download your QR code as PNG or PDF. Print and place on tables instantly.'],
 ['','Multi-Restaurant','Manage multiple restaurant branches from a single owner account.'],
 ['','Dark Mode','Full dark/light theme support. Looks great on any device, any time.'],
 ];
 foreach ($features as [$icon, $title, $desc]):
 ?>
 <div class="feature-card">
 <div class="feature-icon"><?= $icon ?></div>
 <h3><?= $title ?></h3>
 <p><?= $desc ?></p>
 </div>
 <?php endforeach; ?>
 </div>
 </div>
</section>

<!-- ── How it Works ───────────────────────────────────────── -->
<section class="section">
 <div class="container">
 <div class="section-header">
 <span class="eyebrow">How It Works</span>
 <h2>Up and Running in 3 Simple Steps</h2>
 </div>
 <div class="features-grid" style="max-width:900px;margin:0 auto;">
 <div class="feature-card text-center">
 <div class="feature-icon" style="margin:0 auto 1rem;">1.</div>
 <h3>Create Your Restaurant</h3>
 <p>Sign in with Google, add your restaurant details, upload logo and set your menu categories.</p>
 </div>
 <div class="feature-card text-center">
 <div class="feature-icon" style="margin:0 auto 1rem;">2.</div>
 <h3>Add Menu & Generate QR</h3>
 <p>Add dishes with photos and prices. Generate branded QR codes for each table in seconds.</p>
 </div>
 <div class="feature-card text-center">
 <div class="feature-icon" style="margin:0 auto 1rem;">3.</div>
 <h3>Receive Orders Live</h3>
 <p>Customers scan and order. You get instant alerts with sound. Accept, track and complete orders.</p>
 </div>
 </div>
 </div>
</section>

<!-- ── CTA ────────────────────────────────────────────────── -->
<section class="section section-alt">
 <div class="container text-center">
 <div class="section-header">
 <h2>Ready to Go Digital?</h2>
 <p>Join hundreds of restaurants already using Saksham Digital Menu. Start for free today.</p>
 </div>
 <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;">
 <a href="/owner/login" class="btn btn-primary btn-lg">Start Free — No Credit Card</a>
 <a href="/restaurants" class="btn btn-ghost btn-lg">Browse Restaurants</a>
 </div>
 <p style="margin-top:1.5rem;color:var(--text-3);font-size:.875rem;">Need help? <a href="mailto:<?= htmlspecialchars(Settings::getSupportEmail()) ?>" style="color:var(--primary);">Contact Support</a> or call <a href="tel:<?= htmlspecialchars(Settings::getSupportNumber()) ?>" style="color:var(--primary);"><?= htmlspecialchars(Settings::getSupportNumber()) ?></a></p>
 </div>
</section>

<?php require __DIR__ . '/../shared/footer.php'; ?>
