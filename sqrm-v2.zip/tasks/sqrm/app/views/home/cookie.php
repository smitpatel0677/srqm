<?php
$pageTitle = 'Cookie Policy';
$pageDesc = 'Cookie Policy for Saksham Digital Menu (SQRM).';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
?>
<header class="navbar">
 <div class="navbar-inner">
 <a href="/" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="" style="height:36px;"/><?php else: ?><div style="width:36px;height:36px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div></div>
 </a>
 <div class="navbar-actions"><button class="theme-toggle"><span class="theme-icon">&#9788;</span></button></div>
 </div>
</header>
<main class="container" style="padding:3rem 1.25rem;max-width:800px;">
 <h1 style="font-size:2rem;font-weight:800;margin-bottom:.5rem;">Cookie Policy</h1>
 <p style="color:var(--text-3);margin-bottom:2.5rem;">Last updated: <?= date('d F Y') ?></p>

 <?php
 $sections = [
 ['What Are Cookies?', 'Cookies are small text files stored on your device by your browser when you visit a website. They help websites remember your preferences and session state.'],
 ['Cookies We Use', "We use the following cookies:\n\n• sqrm_session — Session cookie for logged-in restaurant owners and admins. Required for authentication. Deleted when you close your browser.\n• sqrm_theme — Stores your dark/light mode preference. Persists across sessions.\n• pwa_dismissed — Remembers if you have dismissed the app install prompt.\n• sqrm_cart_{id} — Stores your cart items for a specific restaurant in localStorage (not a traditional cookie). Cleared when you complete or abandon an order."],
 ['Third-Party Cookies', 'We use Google OAuth for owner login. Google may set its own cookies during the authentication flow. Please refer to Google\'s Privacy Policy for details.'],
 ['Essential vs Non-Essential', 'Session cookies are essential for platform functionality. Theme and PWA preference cookies are non-essential but improve your experience. We do not use advertising or tracking cookies.'],
 ['Managing Cookies', 'You can control and delete cookies through your browser settings. Disabling essential cookies (session) will prevent you from logging in as a restaurant owner or admin. Non-essential cookies can be cleared without affecting core functionality.'],
 ['Contact', 'For cookie-related questions, contact us at: ' . htmlspecialchars(Settings::getSupportEmail())],
 ];
 foreach ($sections as [$title, $body]):
 ?>
 <section style="margin-bottom:2rem;">
 <h2 style="font-size:1.15rem;font-weight:700;margin-bottom:.65rem;color:var(--primary);"><?= $title ?></h2>
 <p style="color:var(--text-2);line-height:1.75;white-space:pre-line;"><?= htmlspecialchars($body) ?></p>
 </section>
 <?php endforeach; ?>
</main>
<?php require __DIR__ . '/../shared/footer.php'; ?>
