<?php
$pageTitle = 'Your Cart — ' . htmlspecialchars($restaurant['name']);
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$logoUrl = $restaurant['logo'] ? UPLOAD_URL . 'logos/' . $restaurant['logo'] : '';
require __DIR__ . '/../shared/header.php';
?>
<style>
body { background: var(--bg-2); }
.cart-page { max-width: 540px; margin: 2rem auto; padding: 0 1rem 4rem; }
.cart-page h1 { font-size: 1.5rem; font-weight: 800; margin-bottom: 1.5rem; }
.cart-item { display: flex; gap: 1rem; align-items: center; background: var(--card-bg); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: .85rem 1rem; margin-bottom: .65rem; }
.cart-item-thumb { width: 56px; height: 56px; border-radius: var(--radius); overflow: hidden; background: var(--bg-3); display: flex; align-items: center; justify-content: center; font-size: 1.4rem; flex-shrink: 0; }
.cart-item-thumb img { width: 100%; height: 100%; object-fit: cover; }
.cart-item-info { flex: 1; min-width: 0; }
.cart-item-info .name { font-weight: 700; font-size: .9rem; }
.cart-item-info .price { font-size: .9rem; color: var(--primary); font-weight: 700; }
.cart-empty { text-align: center; padding: 4rem 1rem; }
.cart-total { background: var(--card-bg); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 1.25rem; margin: 1.5rem 0; }
.cart-total-row { display: flex; justify-content: space-between; align-items: center; padding: .35rem 0; font-size: .9375rem; }
.cart-total-row.total { font-weight: 800; font-size: 1.1rem; border-top: 1px solid var(--border); margin-top: .5rem; padding-top: .65rem; }
</style>

<div class="cart-page">
 <!-- Restaurant header -->
 <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;padding:1rem;background:var(--card-bg);border:1px solid var(--border);border-radius:var(--radius-lg);">
 <?php if ($logoUrl): ?>
 <img src="<?= htmlspecialchars($logoUrl) ?>" style="width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid var(--primary);" alt=""/>
 <?php else: ?>
 <div style="width:48px;height:48px;background:var(--bg-3);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.9rem;font-weight:700;color:var(--text-2);"><?= strtoupper(substr(htmlspecialchars($restaurant['name']),0,1)) ?></div>
 <?php endif; ?>
 <div>
 <div style="font-weight:700;"><?= htmlspecialchars($restaurant['name']) ?></div>
 <div style="font-size:.8rem;color:var(--text-3);"><?= htmlspecialchars($restaurant['location']) ?></div>
 </div>
 <a href="/m/<?= htmlspecialchars($restaurant['slug']) ?>" style="margin-left:auto;color:var(--primary);font-size:.85rem;">← Back to Menu</a>
 </div>

 <h1>Your Cart</h1>

 <div id="cart-items-container"></div>

 <div id="cart-empty" class="cart-empty hidden">
 <div style="font-size:3rem;margin-bottom:1rem;"></div>
 <h3>Your cart is empty</h3>
 <a href="/m/<?= htmlspecialchars($restaurant['slug']) ?>" class="btn btn-primary" style="margin-top:1rem;">Browse Menu</a>
 </div>

 <div id="cart-total-wrap" class="cart-total">
 <div class="cart-total-row total"><span>Total</span><span id="cart-grand-total">₹0.00</span></div>
 </div>

 <!-- Order form -->
 <div id="order-form-wrap" class="card">
 <h3 style="margin-bottom:1.25rem;font-weight:700;"> Your Details</h3>
 <div id="order-error" class="alert alert-error hidden"></div>
 <div class="form-group">
 <label class="form-label">Your Name *</label>
 <input type="text" id="customer-name" class="form-control" placeholder="Enter your name" required/>
 </div>
 <div class="form-group">
 <label class="form-label">Phone Number *</label>
 <input type="tel" id="customer-phone" class="form-control" placeholder="10-digit mobile number" maxlength="10" required/>
 </div>
 <div class="form-group">
 <label class="form-label">Payment Method *</label>
 <div style="display:flex;gap:1rem;flex-wrap:wrap;margin-top:.35rem;">
 <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;min-height:48px;">
 <input type="radio" name="payment" value="cash" checked/> <span> Cash on Delivery</span>
 </label>
 <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;min-height:48px;">
 <input type="radio" name="payment" value="online"/> <span>Online Payment</span>
 </label>
 </div>
 </div>
 <?php if ($restaurant['payment_info']): ?>
 <div id="online-payment-info" class="alert alert-info hidden">
 <strong>Online Payment Details:</strong><br/>
 <?= nl2br(htmlspecialchars($restaurant['payment_info'])) ?>
 </div>
 <?php endif; ?>
 <button id="place-order-btn" class="btn btn-primary btn-block btn-lg">Place Order</button>
 </div>
</div>

<script>
SQRM.init(<?= (int)$restaurant['id'] ?>, '<?= addslashes($restaurant['slug']) ?>');

// Show cart items
function renderCartPage() {
 const container = document.getElementById('cart-items-container');
 const emptyEl = document.getElementById('cart-empty');
 const totalEl = document.getElementById('cart-grand-total');
 const totalWrap = document.getElementById('cart-total-wrap');
 const formWrap = document.getElementById('order-form-wrap');
 const items = Object.values(SQRM.cart);

 container.innerHTML = '';
 if (items.length === 0) {
 emptyEl.classList.remove('hidden');
 totalWrap.classList.add('hidden');
 formWrap.classList.add('hidden');
 return;
 }
 emptyEl.classList.add('hidden');
 totalWrap.classList.remove('hidden');
 formWrap.classList.remove('hidden');

 items.forEach(item => {
 const div = document.createElement('div');
 div.className = 'cart-item';
 div.innerHTML = `
 <div class="cart-item-thumb">${item.image ? `<img src="${item.image}" alt=""/>` : 'Edit'}</div>
 <div class="cart-item-info">
 <div class="name">${item.name}</div>
 <div class="price">₹${item.price.toFixed(2)} × ${item.qty} = <strong>₹${(item.price * item.qty).toFixed(2)}</strong></div>
 </div>
 <div class="qty-control">
 <button class="qty-btn" onclick="SQRM.removeOne('${item.id}');renderCartPage();">−</button>
 <span class="qty-num">${item.qty}</span>
 <button class="qty-btn" onclick="SQRM.addItem('${item.id}','${item.name}','${item.price}','${item.image}');renderCartPage();">+</button>
 </div>`;
 container.appendChild(div);
 });
 totalEl.textContent = `₹${SQRM.getTotal().toFixed(2)}`;
}
renderCartPage();

// Payment method toggle
document.querySelectorAll('input[name="payment"]').forEach(r => {
 r.addEventListener('change', () => {
 const info = document.getElementById('online-payment-info');
 if (info) info.classList.toggle('hidden', r.value !== 'online' || !r.checked);
 });
});

// Place order
document.getElementById('place-order-btn')?.addEventListener('click', async () => {
 const name = document.getElementById('customer-name').value.trim();
 const phone = document.getElementById('customer-phone').value.trim();
 const payment = document.querySelector('input[name="payment"]:checked')?.value || 'cash';
 const errEl = document.getElementById('order-error');

 if (!name) { errEl.textContent = 'Please enter your name.'; errEl.classList.remove('hidden'); return; }
 if (!/^\d{10}$/.test(phone)) { errEl.textContent = 'Please enter a valid 10-digit phone number.'; errEl.classList.remove('hidden'); return; }
 if (SQRM.getCount() === 0) { errEl.textContent = 'Your cart is empty.'; errEl.classList.remove('hidden'); return; }
 errEl.classList.add('hidden');

 const btn = document.getElementById('place-order-btn');
 btn.disabled = true; btn.textContent = 'Placing order…';

 const formData = new FormData();
 formData.append('restaurant_id', '<?= $restaurant['id'] ?>');
 formData.append('customer_name', name);
 formData.append('customer_phone', phone);
 formData.append('payment_method', payment);
 formData.append('items_json', JSON.stringify(SQRM.getCartForOrder()));

 try {
 const res = await fetch('/api/order/place', { method: 'POST', body: formData });
 const data = await res.json();
 if (data.success) {
 SQRM.clearCart();
 window.location.href = `/order/${data.token}`;
 } else {
 errEl.textContent = data.error || 'Failed to place order. Please try again.';
 errEl.classList.remove('hidden');
 btn.disabled = false; btn.textContent = 'Place Order';
 }
 } catch(e) {
 errEl.textContent = 'Network error. Please try again.';
 errEl.classList.remove('hidden');
 btn.disabled = false; btn.textContent = 'Place Order';
 }
});
</script>
