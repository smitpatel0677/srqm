<?php
$pageTitle = htmlspecialchars($restaurant['name']) . ' — Menu & Profile';
$pageDesc = 'View ' . htmlspecialchars($restaurant['name']) . ' menu, location, reviews and ratings on Saksham Digital Menu.';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
$logoUrl = $restaurant['logo'] ? UPLOAD_URL . 'logos/' . $restaurant['logo'] : '';
require __DIR__ . '/../shared/header.php';
?>
<script type="application/ld+json">
{
 "@context": "https://schema.org",
 "@type": "Restaurant",
 "name": "<?= htmlspecialchars($restaurant['name']) ?>",
 "address": "<?= htmlspecialchars($restaurant['location']) ?>",
 "telephone": "<?= htmlspecialchars($restaurant['phone']) ?>",
 "aggregateRating": {
 "@type": "AggregateRating",
 "ratingValue": "<?= number_format((float)$restaurant['rating'], 1) ?>",
 "reviewCount": "<?= (int)$restaurant['total_reviews'] ?>"
 }
}
</script>

<header class="navbar">
 <div class="navbar-inner">
 <a href="/" class="navbar-brand">
 <?php if ($siteLogo): ?><img src="<?= htmlspecialchars($siteLogo) ?>" alt="<?= htmlspecialchars($siteName) ?>" loading="lazy"/><?php else: ?><div style="width:40px;height:40px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div><?php endif; ?>
 <div><div class="brand-text"><?= htmlspecialchars($siteName) ?></div><div class="brand-short">SQRM</div></div>
 </a>
 <div class="navbar-actions">
 <button class="theme-toggle"><span class="theme-icon">&#9788;</span></button>
 <a href="/m/<?= htmlspecialchars($restaurant['slug']) ?>" class="btn btn-primary btn-sm">View Menu</a>
 </div>
 </div>
</header>

<main style="min-height:80vh;background:var(--bg);">
 <div style="background:linear-gradient(135deg,#1a1a2e,#0f3460);padding:3rem 0 2rem;color:#fff;">
 <div class="container">
 <div class="rest-profile-header" style="color:#fff;">
 <?php if ($logoUrl): ?>
 <img src="<?= htmlspecialchars($logoUrl) ?>" alt="<?= htmlspecialchars($restaurant['name']) ?>" class="rest-profile-logo" loading="lazy"/>
 <?php else: ?>
 <div style="width:100px;height:100px;background:rgba(255,255,255,.1);border-radius:var(--radius-lg);display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-weight:800;color:var(--primary);border:3px solid var(--primary);"><?= strtoupper(substr(htmlspecialchars($restaurant['name']),0,1)) ?></div>
 <?php endif; ?>
 <div class="rest-profile-info">
 <h1 style="color:#fff;"><?= htmlspecialchars($restaurant['name']) ?></h1>
 <div class="rest-profile-meta">
 <span><?= htmlspecialchars($restaurant['location']) ?></span>
 <a href="tel:<?= htmlspecialchars($restaurant['phone']) ?>" style="color:rgba(255,255,255,.85);"><?= htmlspecialchars($restaurant['phone']) ?></a>
 </div>
 <div style="margin-top:.75rem;display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;">
 <span class="star-rating"><?php echo starHtml((float)$restaurant['rating']); ?></span>
 <span style="color:rgba(255,255,255,.8);font-size:.9rem;"><?= number_format((float)$restaurant['rating'], 1) ?> / 5 (<?= (int)$restaurant['total_reviews'] ?> reviews)</span>
 </div>
 </div>
 </div>
 </div>
 </div>

 <div class="container" style="padding-top:2.5rem;padding-bottom:4rem;">
 <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem;margin-bottom:2rem;">
 <div>
 <h2 style="font-size:1.35rem;font-weight:800;">Customer Reviews</h2>
 <p style="color:var(--text-3);font-size:.875rem;"><?= (int)$restaurant['total_reviews'] ?> total review<?= $restaurant['total_reviews'] !== 1 ? 's' : '' ?></p>
 </div>
 <a href="/m/<?= htmlspecialchars($restaurant['slug']) ?>" class="btn btn-primary">View Menu & Order</a>
 </div>

 <!-- Star filter pills -->
 <div class="review-filters">
 <a href="/r/<?= htmlspecialchars($restaurant['slug']) ?>" class="pill-tab <?= $starFilter === 0 ? 'active' : '' ?>">All</a>
 <?php for ($i = 5; $i >= 1; $i--): ?>
 <a href="/r/<?= htmlspecialchars($restaurant['slug']) ?>?stars=<?= $i ?>" class="pill-tab <?= $starFilter === $i ? 'active' : '' ?>">
 <?= $i ?> <span style="font-size:.75rem;opacity:.8;">(<?= $ratingCounts[$i] ?>)</span>
 </a>
 <?php endfor; ?>
 </div>

 <?php if (empty($reviews)): ?>
 <div class="card text-center" style="padding:3rem;">
 <div style="font-size:3rem;margin-bottom:1rem;"></div>
 <h3>No reviews yet</h3>
 <p style="color:var(--text-3);">Be the first to leave a review after ordering!</p>
 </div>
 <?php else: ?>
 <div class="reviews-grid">
 <?php foreach ($reviews as $rev): ?>
 <div class="review-card">
 <div class="review-header">
 <div>
 <span class="review-author"><?= htmlspecialchars($rev['customer_name']) ?></span>
 <div class="star-rating" style="margin-top:.2rem;"><?php echo starHtml((float)$rev['rating']); ?></div>
 </div>
 <span class="review-date"><?= timeAgo($rev['created_at']) ?></span>
 </div>
 <?php if ($rev['review_text']): ?>
 <p class="review-text">"<?= htmlspecialchars($rev['review_text']) ?>"</p>
 <?php endif; ?>
 </div>
 <?php endforeach; ?>
 </div>
 <?php endif; ?>
 </div>
</main>

<?php require __DIR__ . '/../shared/footer.php'; ?>
