<?php
$pageTitle = htmlspecialchars($restaurant['name']) . ' — Digital Menu';
$pageDesc = 'Browse the menu of ' . htmlspecialchars($restaurant['name']) . '. Scan, select and order digitally.';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$logoUrl = $restaurant['logo'] ? UPLOAD_URL . 'logos/' . $restaurant['logo'] : '';
require __DIR__ . '/../shared/header.php';
// Group items by category
$grouped = [];
foreach ($items as $item) {
 $cat = $item['category_name'] ?: 'Menu';
 $grouped[$cat][] = $item;
}
?>

<style>
 body { padding-bottom: 80px; }
 .menu-header {
 background: linear-gradient(135deg, #1a1a2e, #0f3460);
 color: #fff; padding: 1.5rem;
 display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;
 position: sticky; top: 0; z-index: 99;
 box-shadow: 0 2px 12px rgba(0,0,0,.3);
 }
 .menu-logo { width: 52px; height: 52px; border-radius: 50%; object-fit: cover; border: 2px solid var(--primary); flex-shrink: 0; }
 .menu-header-info h1 { font-size: 1.05rem; font-weight: 800; }
 .menu-header-info p { font-size: .8rem; color: rgba(255,255,255,.7); }
 .menu-search-wrap { padding: 1rem 1rem .5rem; background: var(--bg-2); border-bottom: 1px solid var(--border); }
 .menu-search { display: flex; gap: .75rem; flex-wrap: wrap; align-items: center; max-width: 760px; margin: 0 auto; }
 .menu-search input { flex: 1; min-width: 180px; padding: .65rem 1rem; border: 1.5px solid var(--border); border-radius: var(--radius-full); background: var(--bg); color: var(--text); font-size: .9375rem; }
 .menu-search input:focus { outline: none; border-color: var(--primary); }
 .category-section { padding: 1.5rem 1rem 0; max-width: 960px; margin: 0 auto; }
 .category-title { font-size: 1.05rem; font-weight: 800; color: var(--text); margin-bottom: 1rem; padding-bottom: .5rem; border-bottom: 2px solid var(--primary); display: flex; align-items: center; gap: .5rem; }
 .menu-list { display: flex; flex-direction: column; gap: .75rem; }
 .menu-list-item {
 display: flex; gap: 1rem; align-items: center;
 background: var(--card-bg); border: 1px solid var(--border);
 border-radius: var(--radius-lg); padding: .85rem 1rem;
 transition: box-shadow .2s;
 }
 .menu-list-item:hover { box-shadow: var(--shadow); }
 .menu-item-thumb { width: 72px; height: 72px; border-radius: var(--radius); overflow: hidden; flex-shrink: 0; background: var(--bg-3); display: flex; align-items: center; justify-content: center; font-size: 1.75rem; }
 .menu-item-thumb img { width: 100%; height: 100%; object-fit: cover; }
 .menu-item-info { flex: 1; min-width: 0; }
 .menu-item-info .name { font-weight: 700; font-size: .9375rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
 .menu-item-info .desc { font-size: .8rem; color: var(--text-3); }
 .menu-item-info .price { font-size: 1rem; font-weight: 800; color: var(--primary); margin-top: .25rem; }
 .menu-item-action { flex-shrink: 0; }
 .add-item-btn { background: var(--primary); color: #fff; border: none; padding: .45rem 1.1rem; border-radius: var(--radius-full); font-size: .875rem; font-weight: 700; cursor: pointer; transition: background .15s; white-space: nowrap; }
 .add-item-btn:hover { background: var(--primary-dark); }
 .cat-filter { display: flex; gap: .5rem; flex-wrap: wrap; padding: .75rem 1rem 0; max-width: 960px; margin: 0 auto; }
 .no-items { text-align: center; padding: 4rem 1rem; color: var(--text-3); }
</style>

<div class="menu-header">
 <?php if ($logoUrl): ?>
 <img src="<?= htmlspecialchars($logoUrl) ?>" alt="<?= htmlspecialchars($restaurant['name']) ?>" class="menu-logo"/>
 <?php else: ?>
 <div style="width:52px;height:52px;background:rgba(255,255,255,.1);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1rem;font-weight:800;color:#fff;"><?= strtoupper(substr(htmlspecialchars($restaurant['name']),0,1)) ?></div>
 <?php endif; ?>
 <div class="menu-header-info" style="flex:1;min-width:0;">
 <h1><?= htmlspecialchars($restaurant['name']) ?></h1>
 <p><?= htmlspecialchars($restaurant['location']) ?> &nbsp;|&nbsp; <a href="tel:<?= htmlspecialchars($restaurant['phone']) ?>" style="color:rgba(255,255,255,.8);"><?= htmlspecialchars($restaurant['phone']) ?></a></p>
 </div>
 <div>
 <a href="/r/<?= htmlspecialchars($restaurant['slug']) ?>" style="font-size:.82rem;color:rgba(255,255,255,.7);">Reviews</a>
 </div>
</div>

<div class="menu-search-wrap">
 <div class="menu-search">
 <input type="text" id="menu-search" placeholder="Search menu items…" autocomplete="off"/>
 <?php if (!empty($categories)): ?>
 <div class="cat-filter" style="padding:0;max-width:none;">
 <button class="pill-tab active" data-cat="all" onclick="filterCat('all',this)">All</button>
 <?php foreach ($categories as $cat): ?>
 <button class="pill-tab" data-cat="<?= htmlspecialchars($cat['name']) ?>" onclick="filterCat(this.dataset.cat,this)"><?= htmlspecialchars($cat['name']) ?></button>
 <?php endforeach; ?>
 </div>
 <?php endif; ?>
 </div>
</div>

<main id="menu-main" style="background:var(--bg-2);min-height:60vh;padding-bottom:2rem;">
 <?php if (empty($items)): ?>
 <div class="no-items"><div style="font-size:2.5rem;margin-bottom:1rem;color:var(--text-3);">&#9749;</div><h3>Menu coming soon</h3><p>The owner is setting up the menu.</p></div>
 <?php else: ?>
 <?php foreach ($grouped as $catName => $catItems): ?>
 <div class="category-section cat-group" data-cat="<?= htmlspecialchars($catName) ?>">
 <div class="category-title"> <?= htmlspecialchars($catName) ?></div>
 <div class="menu-list">
 <?php foreach ($catItems as $item): ?>
 <div class="menu-list-item menu-item-row"
 data-item-id="<?= $item['id'] ?>"
 data-name="<?= htmlspecialchars(strtolower($item['name'])) ?>"
 data-cat="<?= htmlspecialchars($catName) ?>">
 <div class="menu-item-thumb">
 <?php if ($item['image']): ?>
 <img data-src="<?= UPLOAD_URL ?>menu/<?= htmlspecialchars($item['image']) ?>" src="/assets/images/placeholder.webp" alt="<?= htmlspecialchars($item['name']) ?>" loading="lazy"/>
 <?php else: ?><span style="font-size:.85rem;font-weight:600;color:var(--text-3);"><?= strtoupper(substr(htmlspecialchars($item['name']),0,1)) ?></span><?php endif; ?>
 </div>
 <div class="menu-item-info">
 <div class="name"><?= htmlspecialchars($item['name']) ?></div>
 <?php if ($item['description']): ?><div class="desc"><?= htmlspecialchars($item['description']) ?></div><?php endif; ?>
 <div class="price"><?= formatPrice($item['price']) ?></div>
 </div>
 <div class="menu-item-action">
 <button class="add-item-btn" onclick="SQRM.addItem('<?= $item['id'] ?>','<?= addslashes($item['name']) ?>','<?= $item['price'] ?>','<?= $item['image'] ? addslashes(UPLOAD_URL.'menu/'.$item['image']) : '' ?>')">Add Item</button>
 <div class="qty-control hidden" style="margin-top:.35rem;">
 <button class="qty-btn" onclick="SQRM.removeOne('<?= $item['id'] ?>')">−</button>
 <span class="qty-num">1</span>
 <button class="qty-btn" onclick="SQRM.addItem('<?= $item['id'] ?>','<?= addslashes($item['name']) ?>','<?= $item['price'] ?>','<?= $item['image'] ? addslashes(UPLOAD_URL.'menu/'.$item['image']) : '' ?>')">+</button>
 </div>
 </div>
 </div>
 <?php endforeach; ?>
 </div>
 </div>
 <?php endforeach; ?>
 <div id="no-results" class="no-items hidden"><div style="font-size:2.5rem;margin-bottom:1rem;"></div><p>No items found for your search.</p></div>
 <?php endif; ?>
</main>

<!-- Cart Bar -->
<div id="cart-bar" class="cart-bar">
 <div class="cart-bar-left">
 <span class="cart-bar-icon"></span>
 <div class="cart-bar-info">
 <div class="count">0 items</div>
 <div class="total">₹0.00</div>
 </div>
 </div>
 <button onclick="SQRM.goToCart()" class="btn" style="background:rgba(255,255,255,.2);color:#fff;border:1.5px solid rgba(255,255,255,.4);">View Cart →</button>
</div>

<script>
SQRM.init(<?= (int)$restaurant['id'] ?>, '<?= addslashes($restaurant['slug']) ?>');

// Search filter
document.getElementById('menu-search')?.addEventListener('input', function() {
 const q = this.value.toLowerCase().trim();
 let found = 0;
 document.querySelectorAll('.menu-item-row').forEach(row => {
 const name = row.dataset.name || '';
 const show = !q || name.includes(q);
 row.style.display = show ? '' : 'none';
 if (show) found++;
 });
 document.getElementById('no-results')?.classList.toggle('hidden', found > 0);
 hiddenEmptyCats();
});

function filterCat(cat, btn) {
 document.querySelectorAll('.cat-filter .pill-tab').forEach(b => b.classList.remove('active'));
 btn?.classList.add('active');
 document.querySelectorAll('.cat-group').forEach(g => {
 g.style.display = (cat === 'all' || g.dataset.cat === cat) ? '' : 'none';
 });
}

function hiddenEmptyCats() {
 document.querySelectorAll('.cat-group').forEach(g => {
 const visible = g.querySelectorAll('.menu-item-row:not([style*="display: none"])').length;
 g.style.display = visible > 0 ? '' : 'none';
 });
}
</script>
