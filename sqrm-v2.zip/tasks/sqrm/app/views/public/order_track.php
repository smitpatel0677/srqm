<?php
$pageTitle = 'Order Status — ' . htmlspecialchars($order['restaurant_name']);
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$logoUrl = $order['restaurant_logo'] ? UPLOAD_URL . 'logos/' . $order['restaurant_logo'] : '';
$token = htmlspecialchars($order['temp_token']);
require __DIR__ . '/../shared/header.php';
?>
<style>
body { background: var(--bg-2); }
.track-page { max-width: 560px; margin: 2rem auto; padding: 0 1rem 4rem; }
.track-header { background: var(--card-bg); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 1.25rem; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 1rem; }
.track-logo { width: 52px; height: 52px; border-radius: 50%; object-fit: cover; border: 2px solid var(--primary); flex-shrink: 0; }
#status-badge { font-size: 1rem; font-weight: 700; }
</style>

<div class="track-page">
 <div class="track-header">
 <?php if ($logoUrl): ?>
 <img src="<?= htmlspecialchars($logoUrl) ?>" class="track-logo" alt=""/>
 <?php else: ?>
 <div style="width:52px;height:52px;background:var(--bg-3);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.9rem;font-weight:700;color:var(--text-2);"><?= strtoupper(substr(htmlspecialchars($restaurant['name']),0,1)) ?></div>
 <?php endif; ?>
 <div>
 <div style="font-weight:700;"><?= htmlspecialchars($order['restaurant_name']) ?></div>
 <div style="font-size:.82rem;color:var(--text-3);"><?= htmlspecialchars($order['restaurant_phone']) ?></div>
 </div>
 </div>

 <h2 style="margin-bottom:1.25rem;font-size:1.35rem;font-weight:800;">Your Order</h2>

 <!-- Items summary -->
 <div class="card" style="margin-bottom:1.5rem;">
 <div style="display:flex;flex-direction:column;gap:.5rem;">
 <?php foreach ($order['items_decoded'] as $item): ?>
 <div style="display:flex;justify-content:space-between;font-size:.9rem;padding:.35rem 0;border-bottom:1px solid var(--border);">
 <span><?= htmlspecialchars($item['name']) ?> × <?= (int)$item['qty'] ?></span>
 <span style="font-weight:600;">₹<?= number_format($item['price'] * $item['qty'], 2) ?></span>
 </div>
 <?php endforeach; ?>
 <div style="display:flex;justify-content:space-between;font-weight:800;font-size:1rem;padding-top:.5rem;">
 <span>Total</span>
 <span style="color:var(--primary);">₹<?= number_format($order['subtotal'], 2) ?></span>
 </div>
 </div>
 <div style="margin-top:.75rem;font-size:.82rem;color:var(--text-3);">
 Payment: <?= ucfirst($order['payment_method']) ?>
 <?php if ($order['payment_method'] === 'online' && $order['payment_info']): ?>
 | <span style="color:var(--info);">Payment info: <?= htmlspecialchars($order['payment_info']) ?></span>
 <?php endif; ?>
 </div>
 </div>

 <!-- Live status tracking -->
 <h3 style="margin-bottom:1rem;font-weight:700;"> Order Status</h3>
 <div class="order-status-track" id="status-track">
 <div class="status-step" id="step-pending" data-status="pending">
 <span class="step-icon">⏳</span>
 <div><div class="step-label">Order Placed</div><div class="step-sub">Waiting for restaurant to confirm</div></div>
 </div>
 <div class="status-step" id="step-accepted" data-status="accepted">
 <span class="step-icon"></span>
 <div><div class="step-label">Order Accepted</div><div class="step-sub">Your order is being prepared</div></div>
 </div>
 <div class="status-step" id="step-completed" data-status="completed">
 <span class="step-icon"></span>
 <div><div class="step-label">Order Completed</div><div class="step-sub">Enjoy your meal!</div></div>
 </div>
 </div>

 <!-- Rejected state -->
 <div id="rejected-info" class="alert alert-error hidden" style="margin-top:1rem;">
 <strong>Order Rejected</strong><br/>
 <span id="reject-reason"></span><br/>
 <a href="tel:<?= htmlspecialchars($order['restaurant_phone']) ?>" style="color:var(--error);font-weight:600;">Call <?= htmlspecialchars($order['restaurant_phone']) ?></a>
 </div>

 <!-- Bill download (shown when completed) -->
 <div id="bill-section" class="hidden" style="margin-top:1.5rem;">
 <div class="card" id="bill-preview-card">
 <div class="bill-preview" id="bill-content">
 <div class="bill-header">
 <?php if ($logoUrl): ?>
 <img src="<?= htmlspecialchars($logoUrl) ?>" class="bill-logo" alt=""/>
 <?php endif; ?>
 <div class="bill-rest"><?= htmlspecialchars($order['restaurant_name']) ?></div>
 <div class="bill-meta"><?= htmlspecialchars($order['restaurant_phone']) ?></div>
 <div class="bill-meta">(see restaurant for address)</div>
 <div class="bill-meta" style="margin-top:.35rem;font-size:.7rem;">Bill #<?= substr($order['temp_token'],0,8) ?> | <?= date('d M Y, h:i A', strtotime($order['updated_at'])) ?></div>
 </div>
 <table class="bill-items">
 <thead><tr><th>Item</th><th>Qty</th><th class="price-col">Price</th></tr></thead>
 <tbody>
 <?php foreach ($order['items_decoded'] as $item): ?>
 <tr>
 <td><?= htmlspecialchars($item['name']) ?></td>
 <td><?= (int)$item['qty'] ?></td>
 <td class="price-col">₹<?= number_format($item['price'] * $item['qty'], 2) ?></td>
 </tr>
 <?php endforeach; ?>
 </tbody>
 </table>
 <div class="bill-total">
 <span>Grand Total</span>
 <span>₹<?= number_format($order['subtotal'], 2) ?></span>
 </div>
 <div class="bill-footer">
 Customer: <?= htmlspecialchars($order['customer_name']) ?> | <?= htmlspecialchars($order['customer_phone']) ?><br/>
 Payment: <?= ucfirst($order['payment_method']) ?><br/><br/>
 <em>This bill is Generated by Saksham Digital Menu and is not an official receipt.<br/>
 Please ask for the original bill from the owner.</em>
 </div>
 </div>
 </div>
 <div style="display:flex;gap:.75rem;margin-top:1rem;flex-wrap:wrap;">
 <button onclick="downloadBillPDF()" class="btn btn-primary">Download PDF Bill</button>
 <button onclick="window.print()" class="btn btn-ghost">Print</button>
 </div>
 </div>
</div>

<!-- Review Modal -->
<div id="review-modal" class="modal-overlay hidden">
 <div class="modal">
 <div class="modal-header">
 <h3 class="modal-title">Rate Your Experience</h3>
 <button class="modal-close" onclick="closeModal('review-modal')"></button>
 </div>
 <form id="review-form">
 <div class="form-group">
 <label class="form-label">Your Rating</label>
 <div class="stars-input" id="review-stars">
 <span data-val="1"></span><span data-val="2"></span><span data-val="3"></span><span data-val="4"></span><span data-val="5"></span>
 </div>
 <input type="hidden" id="review-rating" value="0"/>
 </div>
 <div class="form-group">
 <label class="form-label">Your Review (optional)</label>
 <textarea id="review-text" class="form-control" rows="3" placeholder="Tell us about your experience…"></textarea>
 </div>
 <div id="review-error" class="alert alert-error hidden"></div>
 <button type="button" onclick="submitReview()" class="btn btn-primary btn-block">Submit Review</button>
 <button type="button" onclick="closeModal('review-modal')" class="btn btn-ghost btn-block" style="margin-top:.5rem;">Skip</button>
 </form>
 </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js" defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js" defer></script>
<script>
const ORDER_TOKEN = '<?= $token ?>';
let currentStatus = '<?= htmlspecialchars($order['status']) ?>';

// Star rating for review
const reviewStars = document.querySelectorAll('#review-stars span');
reviewStars.forEach((s, i) => {
 s.addEventListener('click', () => {
 document.getElementById('review-rating').value = i + 1;
 reviewStars.forEach((x, j) => x.classList.toggle('active', j <= i));
 reviewStars.forEach((x, j) => x.style.color = j <= i ? '#F39C12' : 'var(--border-2)');
 });
});

function updateUI(status, rejectionReason) {
 const steps = { pending: 0, accepted: 1, completed: 2 };
 const stepEls = ['step-pending','step-accepted','step-completed'];

 stepEls.forEach((id, idx) => {
 const el = document.getElementById(id);
 if (!el) return;
 el.className = 'status-step';
 if (status === 'rejected') { el.className = 'status-step'; return; }
 if (status === 'completed') { el.className = 'status-step done'; return; }
 const ord = steps[status] ?? 0;
 if (idx < ord) el.className = 'status-step done';
 else if (idx === ord) el.className = 'status-step active';
 });

 const rejInfo = document.getElementById('rejected-info');
 if (status === 'rejected') {
 rejInfo.classList.remove('hidden');
 document.getElementById('reject-reason').textContent = rejectionReason ? 'Reason: ' + rejectionReason : '';
 } else {
 rejInfo.classList.add('hidden');
 }

 if (status === 'completed') {
 document.getElementById('bill-section').classList.remove('hidden');
 }
}

updateUI(currentStatus, '<?= addslashes($order['rejection_reason'] ?? '') ?>');

// Poll for status changes
if (!['completed','rejected'].includes(currentStatus)) {
 pollOrderStatus(ORDER_TOKEN, data => {
 if (data.status && data.status !== currentStatus) {
 currentStatus = data.status;
 updateUI(data.status, data.rejection_reason);
 if (data.status === 'completed' && !<?= $order['review_submitted'] ? 'true' : 'false' ?>) {
 setTimeout(() => openModal('review-modal'), 1200);
 }
 showToast('Order status: ' + data.status, data.status === 'rejected' ? 'error' : 'success');
 }
 });
}

// Show review modal on page load if completed and no review yet
<?php if ($order['status'] === 'completed' && !$order['review_submitted']): ?>
setTimeout(() => openModal('review-modal'), 800);
<?php endif; ?>

async function submitReview() {
 const rating = parseInt(document.getElementById('review-rating').value);
 const text = document.getElementById('review-text').value.trim();
 const errEl = document.getElementById('review-error');
 if (rating < 1) { errEl.textContent = 'Please select a star rating.'; errEl.classList.remove('hidden'); return; }
 errEl.classList.add('hidden');

 const fd = new FormData();
 fd.append('order_token', ORDER_TOKEN);
 fd.append('rating', rating);
 fd.append('review_text', text);
 const res = await fetch('/api/review/submit', { method: 'POST', body: fd });
 const data = await res.json();
 if (data.success) {
 closeModal('review-modal');
 showToast('Thank you for your review! ', 'success');
 } else {
 errEl.textContent = data.error || 'Failed to submit review.';
 errEl.classList.remove('hidden');
 }
}

async function downloadBillPDF() {
 const el = document.getElementById('bill-content');
 if (!el) return;
 try {
 const canvas = await html2canvas(el, { scale: 2, backgroundColor: '#ffffff', useCORS: true });
 const imgData = canvas.toDataURL('image/png');
 const { jsPDF } = window.jspdf;
 const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a6' });
 const w = pdf.internal.pageSize.getWidth();
 const h = (canvas.height * w) / canvas.width;
 pdf.addImage(imgData, 'PNG', 0, 0, w, h);
 pdf.save(`Bill_<?= substr($order['temp_token'],0,8) ?>.pdf`);
 } catch(e) {
 showToast('PDF generation failed. Try printing instead.', 'error');
 }
}
</script>
