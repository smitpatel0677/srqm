<?php
$pageTitle = 'Find Restaurants — Browse by Location & Rating';
$pageDesc = 'Find restaurants near you on Saksham Digital Menu. Filter by location, rating, and browse digital menus instantly.';
require_once __DIR__ . '/../../../includes/Settings.php';
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
require __DIR__ . '/../shared/header.php';
?>

<header class="navbar">
 <div class="navbar-inner">
 <a href="/" class="navbar-brand">
 <?php if ($siteLogo): ?>
 <img src="<?= htmlspecialchars($siteLogo) ?>" alt="<?= htmlspecialchars($siteName) ?>" loading="lazy"/>
 <?php else: ?>
 <div style="width:40px;height:40px;background:var(--primary);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;">S</div>
 <?php endif; ?>
 <div>
 <div class="brand-text"><?= htmlspecialchars($siteName) ?></div>
 <div class="brand-short">SQRM</div>
 </div>
 </a>
 <div class="navbar-actions">
 <button class="theme-toggle"><span class="theme-icon">&#9788;</span></button>
 <a href="/owner/login" class="btn btn-primary btn-sm">Get Started</a>
 </div>
 </div>
</header>

<main style="padding:2.5rem 0 4rem;background:var(--bg-2);min-height:80vh;">
 <div class="container">
 <div class="page-header">
 <h1>Find Restaurants</h1>
 <p>Discover restaurants with digital menus near you. Scan QR and order instantly.</p>
 </div>

 <!-- Search Filters -->
 <form method="GET" action="/restaurants" class="search-bar">
 <div class="form-group">
 <label class="form-label">Restaurant Name</label>
 <input type="text" name="q" class="form-control" placeholder="Search by name…" value="<?= htmlspecialchars($search) ?>"/>
 </div>
 <div class="form-group">
 <label class="form-label">Location</label>
 <select name="location" class="form-control">
 <option value="">All Locations</option>
 <?php foreach ($locations as $loc): ?>
 <option value="<?= htmlspecialchars($loc['location']) ?>" <?= ($location === $loc['location']) ? 'selected' : '' ?>>
 <?= htmlspecialchars($loc['location']) ?>
 </option>
 <?php endforeach; ?>
 </select>
 </div>
 <div class="form-group">
 <label class="form-label">Min Rating</label>
 <select name="rating" class="form-control">
 <option value="">Any Rating</option>
 <?php for ($i = 5; $i >= 1; $i--): ?>
 <option value="<?= $i ?>" <?= ($rating === $i) ? 'selected' : '' ?>><?= $i ?> Star<?= $i > 1 ? 's' : '' ?>+</option>
 <?php endfor; ?>
 </select>
 </div>
 <div class="form-group" style="justify-content:flex-end;">
 <button type="submit" class="btn btn-primary">Search</button>
 <a href="/restaurants" class="btn btn-ghost btn-sm" style="margin-top:.35rem;">Clear</a>
 </div>
 </form>

 <!-- Results -->
 <?php if (empty($restaurants)): ?>
 <div class="card text-center" style="padding:3rem;">
 <div style="font-size:2.5rem;margin-bottom:1rem;color:var(--text-3);">&#127829;</div>
 <h3 style="margin-bottom:.5rem;">No restaurants found</h3>
 <p style="color:var(--text-3);">Try adjusting your search or clear filters.</p>
 <a href="/restaurants" class="btn btn-outline" style="margin-top:1.5rem;">View All Restaurants</a>
 </div>
 <?php else: ?>
 <div style="margin-bottom:1rem;color:var(--text-3);font-size:.875rem;"><?= count($restaurants) ?> restaurant<?= count($restaurants) !== 1 ? 's' : '' ?> found</div>
 <div class="rest-grid">
 <?php foreach ($restaurants as $r): ?>
 <a href="/r/<?= htmlspecialchars($r['slug']) ?>" class="rest-card">
 <div class="rest-card-img">
 <?php if ($r['logo']): ?>
 <img data-src="<?= UPLOAD_URL ?>logos/<?= htmlspecialchars($r['logo']) ?>" src="/assets/images/placeholder.webp" alt="<?= htmlspecialchars($r['name']) ?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;"/>
 <?php else: ?>
 <span><?= strtoupper(substr(htmlspecialchars($r[\'name\']),0,1)) ?></span>
 <?php endif; ?>
 </div>
 <div class="rest-card-body">
 <div class="rest-card-name"><?= htmlspecialchars($r['name']) ?></div>
 <div class="rest-card-loc"><?= htmlspecialchars($r['location']) ?></div>
 <?php if ($r['phone']): ?>
 <div style="font-size:.82rem;color:var(--text-3);"><?= htmlspecialchars($r['phone']) ?></div>
 <?php endif; ?>
 <div class="rest-card-rating">
 <span class="star-rating"><?php echo starHtml((float)$r['rating']); ?></span>
 <span style="color:var(--text-3);font-size:.8rem;"><?= number_format((float)$r['rating'], 1) ?> (<?= (int)$r['total_reviews'] ?>)</span>
 </div>
 </div>
 </a>
 <?php endforeach; ?>
 </div>
 <?php endif; ?>
 </div>
</main>

<?php require __DIR__ . '/../shared/footer.php'; ?>
