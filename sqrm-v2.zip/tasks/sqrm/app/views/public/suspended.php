<?php
$pageTitle = 'Restaurant Unavailable';
require_once __DIR__ . '/../../../includes/Settings.php';
require __DIR__ . '/../shared/header.php';
?>
<div class="error-page container">
 <div class="error-content">
 <div style="font-size:4rem;margin-bottom:1rem;"></div>
 <h2>Restaurant Unavailable</h2>
 <p style="color:var(--text-2);margin:1rem 0;">This restaurant is currently unavailable or suspended.</p>
 <a href="/restaurants" class="btn btn-primary">Browse Other Restaurants</a>
 </div>
</div>
<?php require __DIR__ . '/../shared/footer.php'; ?>
