<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Maintenance | Saksham Digital Menu</title>
<link rel="stylesheet" href="/assets/css/style.css"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet"/>
</head>
<body>
<div class="maintenance-page">
 <div class="maintenance-content">
 <div class="maintenance-icon"></div>
 <h1>We Are Doing Maintenance</h1>
 <p>For Your Experience</p>
 <p class="maint-sub">It won't take that much longer. Please check back soon.</p>
 <div class="maint-dots">
 <span></span><span></span><span></span>
 </div>
 </div>
</div>
</body>
</html>
