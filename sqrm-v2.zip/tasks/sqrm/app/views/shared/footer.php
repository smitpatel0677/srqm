
<footer class="site-footer">
 <div class="footer-inner container">
 <div class="footer-brand">
 <?php $siteLogo = Settings::getSiteLogo(); ?>
 <?php if ($siteLogo): ?>
 <img src="<?= htmlspecialchars($siteLogo) ?>" alt="<?= htmlspecialchars(Settings::getSiteName()) ?>" class="footer-logo" loading="lazy"/>
 <?php endif; ?>
 <span class="footer-name"><?= htmlspecialchars(Settings::getSiteName()) ?></span>
 </div>
 <nav class="footer-links">
 <a href="/">Home</a>
 <a href="/restaurants">Restaurants</a>
 <a href="/privacy-policy">Privacy Policy</a>
 <a href="/cookie-policy">Cookie Policy</a>
 <a href="mailto:<?= htmlspecialchars(Settings::getSupportEmail()) ?>">Contact</a>
 </nav>
 <p class="footer-copy">&copy; <?= date('Y') ?> <?= htmlspecialchars(Settings::getSiteName()) ?> (SQRM). All rights reserved.</p>
 </div>
</footer>

<!-- Install PWA -->
<div id="pwa-install-banner" class="pwa-banner hidden">
 <div class="pwa-banner-inner">
 <span>Add Saksham Digital Menu to your home screen for the best experience!</span>
 <button id="pwa-install-btn" class="btn btn-sm btn-primary">Install App</button>
 <button id="pwa-dismiss-btn" class="btn btn-sm btn-ghost"></button>
 </div>
</div>

<script src="/assets/js/app.js"></script>
</body>
</html>
