<?php
// Shared header partial
// Variables expected: $pageTitle, $pageDesc, $pageSlug (optional), $restaurant (optional)
$siteName = Settings::getSiteName();
$siteLogo = Settings::getSiteLogo();
$pageTitle = $pageTitle ?? $siteName;
$pageDesc = $pageDesc ?? 'Saksham Digital Menu (SQRM) — The smartest way to manage your restaurant menu digitally. QR codes, digital ordering, real-time tracking and more.';
$canonicalUrl = APP_URL . ($_SERVER['REQUEST_URI'] ?? '/');
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<meta name="theme-color" content="#D35400"/>
<title><?= htmlspecialchars($pageTitle) ?> | <?= htmlspecialchars($siteName) ?></title>
<meta name="description" content="<?= htmlspecialchars($pageDesc) ?>"/>
<meta name="keywords" content="digital menu, QR menu, restaurant ordering, online menu India, SQRM"/>
<link rel="canonical" href="<?= htmlspecialchars($canonicalUrl) ?>"/>
<!-- Open Graph -->
<meta property="og:title" content="<?= htmlspecialchars($pageTitle) ?>"/>
<meta property="og:description" content="<?= htmlspecialchars($pageDesc) ?>"/>
<meta property="og:url" content="<?= htmlspecialchars($canonicalUrl) ?>"/>
<meta property="og:type" content="website"/>
<meta property="og:image" content="<?= htmlspecialchars(APP_URL . '/assets/images/og-banner.png') ?>"/>
<!-- Twitter -->
<meta name="twitter:card" content="summary_large_image"/>
<meta name="twitter:title" content="<?= htmlspecialchars($pageTitle) ?>"/>
<meta name="twitter:description" content="<?= htmlspecialchars($pageDesc) ?>"/>
<!-- PWA -->
<link rel="manifest" href="/manifest.json"/>
<link rel="apple-touch-icon" href="/assets/images/icon-192.png"/>
<!-- Styles -->
<link rel="stylesheet" href="/assets/css/style.css"/>
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
<!-- JSON-LD -->
<script type="application/ld+json">
{
 "@context": "https://schema.org",
 "@type": "WebSite",
 "name": "<?= htmlspecialchars($siteName) ?>",
 "url": "<?= APP_URL ?>",
 "description": "<?= htmlspecialchars($pageDesc) ?>",
 "potentialAction": {
 "@type": "SearchAction",
 "target": "<?= APP_URL ?>/restaurants?q={search_term_string}",
 "query-input": "required name=search_term_string"
 }
}
</script>
</head>
<body>
<div id="offline-banner" class="offline-banner hidden">
 <span>You are offline. Showing cached data.</span>
</div>
