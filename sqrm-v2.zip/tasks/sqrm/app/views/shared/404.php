<?php
$pageTitle = 'Page Not Found';
$pageDesc = 'The page you are looking for does not exist.';
require_once __DIR__ . '/../../../includes/Settings.php';
require __DIR__ . '/header.php';
?>
<main class="error-page container">
 <div class="error-content">
 <h1 class="error-code">404</h1>
 <p class="error-msg">Oops! This page doesn't exist.</p>
 <a href="/" class="btn btn-primary">Back to Home</a>
 </div>
</main>
<?php require __DIR__ . '/footer.php'; ?>
