<?php
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/Settings.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/ImageUpload.php';

class RestaurantController {

 public static function index(): void {
 $owner = Auth::requireOwner();
 Auth::requirePhoneVerified();
 $restaurants = Database::fetchAll(
 'SELECT r.*, (SELECT COUNT(*) FROM menu_items mi WHERE mi.restaurant_id = r.id) as item_count
 FROM restaurants r WHERE r.owner_id = ? AND r.is_deleted = 0 ORDER BY r.created_at DESC',
 [$owner['id']]
 );
 $plan = Auth::getOwnerPlan();
 $maxRest = planMaxRestaurants($plan);
 require __DIR__ . '/../views/owner/restaurants.php';
 }

 public static function create(): void {
 $owner = Auth::requireOwner();
 Auth::requirePhoneVerified();
 $plan = Auth::getOwnerPlan();
 $maxRest = planMaxRestaurants($plan);
 $current = (int)Database::fetch(
 'SELECT COUNT(*) as c FROM restaurants WHERE owner_id = ? AND is_deleted = 0',
 [$owner['id']]
 )['c'];

 $error = '';
 if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 if (!verifyCsrf()) { $error = 'Invalid request.'; }
 elseif ($current >= $maxRest) {
 $error = 'You have reached the restaurant limit for your plan. Please upgrade.';
 } else {
 $name = sanitize($_POST['name'] ?? '');
 $location = sanitize($_POST['location'] ?? '');
 $phone = sanitize($_POST['phone'] ?? '');
 $paymentInfo = sanitize($_POST['payment_info'] ?? '');
 $themeColor = sanitize($_POST['theme_color'] ?? '#D35400');

 if (!$name || !$location || !$phone) {
 $error = 'Name, location, and phone are required.';
 } else {
 $logo = null;
 if (!empty($_FILES['logo']['tmp_name'])) {
 $logo = ImageUpload::uploadAndConvertToWebP($_FILES['logo'], LOGO_UPLOAD_PATH);
 if (!$logo) $error = 'Failed to process logo image.';
 }
 if (!$error) {
 $slug = uniqueSlug('restaurants', $name);
 $id = Database::insert(
 'INSERT INTO restaurants (owner_id, name, slug, logo, location, phone, payment_info, theme_color) VALUES (?,?,?,?,?,?,?,?)',
 [$owner['id'], $name, $slug, $logo, $location, $phone, $paymentInfo, $themeColor]
 );
 redirect('/owner/restaurants/' . $id . '/menu');
 }
 }
 }
 }
 require __DIR__ . '/../views/owner/restaurant_create.php';
 }

 public static function edit(int $id): void {
 $owner = Auth::requireOwner();
 Auth::requirePhoneVerified();
 $restaurant = self::ownedRestaurant($id, $owner['id']);

 $error = $success = '';
 if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 if (!verifyCsrf()) { $error = 'Invalid request.'; }
 else {
 $name = sanitize($_POST['name'] ?? '');
 $location = sanitize($_POST['location'] ?? '');
 $phone = sanitize($_POST['phone'] ?? '');
 $paymentInfo = sanitize($_POST['payment_info'] ?? '');
 $themeColor = sanitize($_POST['theme_color'] ?? '#D35400');
 $plan = Auth::getOwnerPlan();

 if (!$name || !$location || !$phone) {
 $error = 'Name, location, and phone are required.';
 } else {
 $logo = $restaurant['logo'];
 if (!empty($_FILES['logo']['tmp_name'])) {
 $newLogo = ImageUpload::uploadAndConvertToWebP($_FILES['logo'], LOGO_UPLOAD_PATH);
 if ($newLogo) {
 if ($logo) ImageUpload::deleteFile(LOGO_UPLOAD_PATH . $logo);
 $logo = $newLogo;
 }
 }
 $finalTheme = planHas($plan, 'custom_theme') ? $themeColor : $restaurant['theme_color'];
 Database::execute(
 'UPDATE restaurants SET name=?, location=?, phone=?, payment_info=?, theme_color=?, logo=?, updated_at=NOW() WHERE id=?',
 [$name, $location, $phone, $paymentInfo, $finalTheme, $logo, $id]
 );
 $restaurant = self::ownedRestaurant($id, $owner['id']);
 $success = 'Restaurant updated successfully.';
 }
 }
 }
 require __DIR__ . '/../views/owner/restaurant_edit.php';
 }

 public static function delete(int $id): void {
 $owner = Auth::requireOwner();
 Auth::requirePhoneVerified();
 if (!verifyCsrf()) redirect('/owner/restaurants');
 self::ownedRestaurant($id, $owner['id']);
 Database::execute('UPDATE restaurants SET is_deleted = 1 WHERE id = ? AND owner_id = ?', [$id, $owner['id']]);
 redirect('/owner/restaurants');
 }

 private static function ownedRestaurant(int $id, int $ownerId): array {
 $r = Database::fetch('SELECT * FROM restaurants WHERE id = ? AND owner_id = ? AND is_deleted = 0', [$id, $ownerId]);
 if (!$r) { http_response_code(403); die('Not found.'); }
 return $r;
 }
}
