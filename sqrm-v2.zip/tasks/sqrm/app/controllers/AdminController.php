<?php
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Settings.php';
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/ImageUpload.php';
require_once __DIR__ . '/../../includes/helpers.php';

class AdminController
{
 /* ── Auth Guard ─────────────────────────────────────── */
 private static function requireAdmin(): void {
 if (!isset($_SESSION['admin_id'])) {
 redirect('/admin1');
 }
 }

 /* ── Login ──────────────────────────────────────────── */
 public static function login(): void {
 if (isset($_SESSION['admin_id'])) redirect('/admin1/dashboard');
 $error = '';
 if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 if (!verifyCsrf()) { $error = 'Invalid request.'; }
 else {
 $email = trim($_POST['email'] ?? '');
 $password = $_POST['password'] ?? '';
 $admin = Database::fetch('SELECT * FROM admins WHERE email = ? LIMIT 1', [$email]);
 if (!$admin || !password_verify($password, $admin['password'])) {
 $error = 'Invalid email or password.';
 } else {
 $_SESSION['admin_id'] = $admin['id'];
 $_SESSION['admin_name'] = $admin['name'];
 redirect('/admin1/dashboard');
 }
 }
 }
 require __DIR__ . '/../views/admin/login.php';
 }

 public static function logout(): void {
 unset($_SESSION['admin_id'], $_SESSION['admin_name']);
 redirect('/admin1');
 }

 /* ── Dashboard ──────────────────────────────────────── */
 public static function dashboard(): void {
 self::requireAdmin();
 $stats = Database::fetch('SELECT
 (SELECT COUNT(*) FROM owners) AS total_owners,
 (SELECT COUNT(*) FROM restaurants) AS total_restaurants,
 (SELECT COUNT(*) FROM orders) AS total_orders,
 (SELECT COUNT(*) FROM reviews) AS total_reviews
 ', []);

 $recentOwners = Database::fetchAll(
 'SELECT o.*, (SELECT COUNT(*) FROM restaurants r WHERE r.owner_id = o.id) AS restaurant_count
 FROM owners o ORDER BY o.created_at DESC LIMIT 10'
 , []);

 require __DIR__ . '/../views/admin/dashboard.php';
 }

 /* ── Owners ─────────────────────────────────────────── */
 public static function owners(): void {
 self::requireAdmin();
 $success = '';
 $owners = Database::fetchAll(
 'SELECT o.*, (SELECT COUNT(*) FROM restaurants r WHERE r.owner_id = o.id) AS restaurant_count
 FROM owners o ORDER BY o.created_at DESC'
 , []);
 require __DIR__ . '/../views/admin/owners.php';
 }

 public static function assignPlan(): void {
 self::requireAdmin();
 if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('/admin1/owners');
 $ownerId = (int)($_POST['owner_id'] ?? 0);
 $plan = in_array($_POST['plan'] ?? '', ['free','basic','premium']) ? $_POST['plan'] : 'free';
 $expires = $plan !== 'free' ? date('Y-m-d H:i:s', strtotime('+30 days')) : null;
 Database::execute('UPDATE owners SET plan = ?, plan_expires_at = ? WHERE id = ?', [$plan, $expires, $ownerId]);
 $success = 'Plan updated successfully.';
 $owners = Database::fetchAll(
 'SELECT o.*, (SELECT COUNT(*) FROM restaurants r WHERE r.owner_id = o.id) AS restaurant_count
 FROM owners o ORDER BY o.created_at DESC'
 , []);
 require __DIR__ . '/../views/admin/owners.php';
 }

 public static function ownerDetail(int $id): void {
 self::requireAdmin();
 $owner = Database::fetch('SELECT * FROM owners WHERE id = ?', [$id]);
 if (!$owner) { http_response_code(404); require __DIR__ . '/../views/shared/404.php'; return; }
 $restaurants = Database::fetchAll('SELECT * FROM restaurants WHERE owner_id = ? AND is_deleted = 0', [$id]);
 require __DIR__ . '/../views/admin/owner_detail.php';
 }

 /* ── Restaurants ────────────────────────────────────── */
 public static function restaurants(): void {
 self::requireAdmin();
 $success = '';
 $restaurants = Database::fetchAll(
 'SELECT r.*,
 o.name AS owner_name, o.email AS owner_email,
 (SELECT COUNT(*) FROM menu_items mi WHERE mi.restaurant_id = r.id) AS item_count,
 (SELECT COUNT(*) FROM orders ord WHERE ord.restaurant_id = r.id) AS order_count,
 COALESCE((SELECT AVG(rv.rating) FROM reviews rv WHERE rv.restaurant_id = r.id),0) AS rating
 FROM restaurants r
 JOIN owners o ON o.id = r.owner_id
 WHERE r.is_deleted = 0
 ORDER BY r.created_at DESC'
 , []);
 require __DIR__ . '/../views/admin/restaurants.php';
 }

 public static function suspendRestaurant(int $id): void {
 self::requireAdmin();
 if (!verifyCsrf()) redirect('/admin1/restaurants');
 Database::execute('UPDATE restaurants SET is_suspended = 1 WHERE id = ?', [$id]);
 redirect('/admin1/restaurants');
 }

 public static function reactivateRestaurant(int $id): void {
 self::requireAdmin();
 if (!verifyCsrf()) redirect('/admin1/restaurants');
 Database::execute('UPDATE restaurants SET is_suspended = 0 WHERE id = ?', [$id]);
 redirect('/admin1/restaurants');
 }

 public static function restaurantReviews(int $restaurantId): void {
 self::requireAdmin();
 $restaurants = Database::fetchAll('SELECT id, name FROM restaurants WHERE is_deleted = 0 ORDER BY name', []);
 $success = '';
 $sql = 'SELECT rv.*, r.name AS restaurant_name
 FROM reviews rv JOIN restaurants r ON r.id = rv.restaurant_id
 WHERE rv.restaurant_id = ?
 ORDER BY rv.created_at DESC';
 $reviews = Database::fetchAll($sql, [$restaurantId]);
 require __DIR__ . '/../views/admin/reviews.php';
 }

 /* ── Reviews ────────────────────────────────────────── */
 public static function reviews(): void {
 self::requireAdmin();
 $restaurantId = (int)($_GET['restaurant_id'] ?? 0);
 $restaurants = Database::fetchAll('SELECT id, name FROM restaurants WHERE is_deleted = 0 ORDER BY name', []);
 $sql = 'SELECT rv.*, r.name AS restaurant_name FROM reviews rv
 JOIN restaurants r ON r.id = rv.restaurant_id';
 $params = [];
 if ($restaurantId) {
 $sql .= ' WHERE rv.restaurant_id = ?';
 $params = [$restaurantId];
 }
 $sql .= ' ORDER BY rv.created_at DESC';
 $reviews = Database::fetchAll($sql, $params);
 require __DIR__ . '/../views/admin/reviews.php';
 }

 public static function deleteReview(): void {
 self::requireAdmin();
 $reviewId = (int)($_POST['review_id'] ?? 0);
 // Get restaurant_id before deleting
 $review = Database::fetch('SELECT restaurant_id FROM reviews WHERE id = ?', [$reviewId]);
 if (!$review) { jsonResponse(['error' => 'Review not found'], 404); }
 Database::execute('DELETE FROM reviews WHERE id = ?', [$reviewId]);
 // Recalculate restaurant avg rating
 Database::execute(
 'UPDATE restaurants SET rating = (
 SELECT COALESCE(AVG(rv2.rating), 0) FROM reviews rv2 WHERE rv2.restaurant_id = ?
 ) WHERE id = ?',
 [$review['restaurant_id'], $review['restaurant_id']]
 );
 jsonResponse(['success' => true]);
 }

 /* ── Settings ───────────────────────────────────────── */
 public static function settings(): void {
 self::requireAdmin();
 $success = $error = '';
 if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 $section = $_POST['section'] ?? 'general';
 if ($section === 'general') {
 Settings::set('site_name', trim($_POST['site_name'] ?? 'Saksham Digital Menu'));
 Settings::set('support_number', trim($_POST['support_number'] ?? ''));
 Settings::set('whatsapp_number', trim($_POST['whatsapp_number'] ?? ''));
 Settings::set('support_email', trim($_POST['support_email'] ?? ''));
 if (!empty($_FILES['site_logo']['tmp_name'])) {
 $logoPath = ImageUpload::uploadSiteLogo($_FILES['site_logo']);
 if ($logoPath) Settings::set('site_logo', $logoPath);
 }
 $success = 'Settings saved successfully.';
 }
 }
 $settings = Settings::getAll();
 require __DIR__ . '/../views/admin/settings.php';
 }

 public static function maintenancePost(): void {
 self::requireAdmin();
 if (!verifyCsrf()) redirect('/admin1/settings');
 $mode = ($_POST['mode'] ?? 'off') === 'on' ? '1' : '0';
 Settings::set('maintenance_mode', $mode);
 redirect('/admin1/settings');
 }
}
