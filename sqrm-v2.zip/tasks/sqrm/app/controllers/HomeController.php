<?php
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/Settings.php';
require_once __DIR__ . '/../../includes/helpers.php';

class HomeController {
 public static function index(): void {
 $siteName = Settings::getSiteName();
 $siteLogo = Settings::getSiteLogo();
 $featuredRestaurants = Database::fetchAll(
 'SELECT r.*, (SELECT COUNT(*) FROM menu_items mi WHERE mi.restaurant_id = r.id) as item_count
 FROM restaurants r WHERE r.is_deleted = 0 AND r.is_suspended = 0
 ORDER BY r.rating DESC, r.total_reviews DESC LIMIT 6'
 );
 require __DIR__ . '/../views/home/index.php';
 }

 public static function sitemap(): void {
 $restaurants = Database::fetchAll('SELECT slug, updated_at FROM restaurants WHERE is_deleted = 0 AND is_suspended = 0');
 header('Content-Type: application/xml; charset=utf-8');
 require __DIR__ . '/../views/home/sitemap.php';
 }
}
