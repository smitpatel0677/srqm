<?php
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/helpers.php';

class QRController {
 public static function show(int $restaurantId): void {
 $owner = Auth::requireOwner();
 Auth::requirePhoneVerified();
 $restaurant = Database::fetch(
 'SELECT * FROM restaurants WHERE id = ? AND owner_id = ? AND is_deleted = 0',
 [$restaurantId, $owner['id']]
 );
 if (!$restaurant) { http_response_code(403); die('Not found.'); }
 $menuUrl = APP_URL . '/m/' . $restaurant['slug'];
 require __DIR__ . '/../views/owner/qr.php';
 }
}
