<?php
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/helpers.php';

class OwnerController {

 public static function dashboard(): void {
 $owner = Auth::requireOwner();
 Auth::requirePhoneVerified();
 $plan = Auth::getOwnerPlan();
 $restaurants = Database::fetchAll('SELECT * FROM restaurants WHERE owner_id = ? AND is_deleted = 0', [$owner['id']]);
 $totalOrders = 0;
 $totalEarnings = 0;
 $todayEarnings = 0;
 foreach ($restaurants as $r) {
 $t = Database::fetch("SELECT COUNT(*) as c, COALESCE(SUM(subtotal),0) as s FROM orders WHERE restaurant_id = ? AND status='completed'", [$r['id']]);
 $today = Database::fetch("SELECT COALESCE(SUM(subtotal),0) as s FROM orders WHERE restaurant_id = ? AND status='completed' AND DATE(created_at) = CURDATE()", [$r['id']]);
 $totalOrders += (int)$t['c'];
 $totalEarnings += (float)$t['s'];
 $todayEarnings += (float)$today['s'];
 }
 require __DIR__ . '/../views/owner/dashboard.php';
 }

 public static function profile(): void {
 $owner = Auth::requireOwner();
 $plan = Auth::getOwnerPlan();
 $freshOwner = Database::fetch('SELECT * FROM owners WHERE id = ?', [$owner['id']]);
 $error = $success = '';

 if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 if (!verifyCsrf()) { $error = 'Invalid request.'; }
 else {
 $name = sanitize($_POST['name'] ?? '');
 $phone = preg_replace('/\D/', '', $_POST['phone'] ?? '');
 if (!$name) { $error = 'Name is required.'; }
 elseif ($phone && in_array($phone, FAKE_PHONES)) { $error = 'Invalid phone number.'; }
 else {
 Database::execute('UPDATE owners SET name = ?, phone = ? WHERE id = ?', [$name, $phone ?: $freshOwner['phone'], $owner['id']]);
 $freshOwner = Database::fetch('SELECT * FROM owners WHERE id = ?', [$owner['id']]);
 Auth::loginOwner($freshOwner);
 $success = 'Profile updated.';
 }
 }
 }
 require __DIR__ . '/../views/owner/profile.php';
 }

 public static function deleteAccount(): void {
 $owner = Auth::requireOwner();
 if (!verifyCsrf()) redirect('/owner/profile');
 // Soft-delete restaurants
 Database::execute('UPDATE restaurants SET is_deleted = 1 WHERE owner_id = ?', [$owner['id']]);
 Database::execute('DELETE FROM owners WHERE id = ?', [$owner['id']]);
 Auth::logout();
 redirect('/?account_deleted=1');
 }
}
