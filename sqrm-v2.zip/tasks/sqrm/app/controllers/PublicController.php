<?php
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/Settings.php';
require_once __DIR__ . '/../../includes/helpers.php';

class PublicController {

 public static function restaurants(): void {
 $search = sanitize($_GET['q'] ?? '');
 $location = sanitize($_GET['location'] ?? '');
 $rating = (int)($_GET['rating'] ?? 0);

 $sql = 'SELECT * FROM restaurants WHERE is_deleted = 0 AND is_suspended = 0';
 $params = [];

 if ($search) {
 $sql .= ' AND name LIKE ?';
 $params[] = '%' . $search . '%';
 }
 if ($location) {
 $sql .= ' AND location LIKE ?';
 $params[] = '%' . $location . '%';
 }
 if ($rating >= 1 && $rating <= 5) {
 $sql .= ' AND FLOOR(rating) >= ?';
 $params[] = $rating;
 }
 $sql .= ' ORDER BY rating DESC, total_reviews DESC';

 $restaurants = Database::fetchAll($sql, $params);

 // Distinct locations for filter dropdown
 $locations = Database::fetchAll(
 'SELECT DISTINCT location FROM restaurants WHERE is_deleted = 0 AND is_suspended = 0 ORDER BY location'
 );

 require __DIR__ . '/../views/public/restaurants.php';
 }

 public static function restaurantProfile(string $slug): void {
 $restaurant = Database::fetch(
 'SELECT r.*, o.name as owner_name FROM restaurants r
 JOIN owners o ON r.owner_id = o.id
 WHERE r.slug = ? AND r.is_deleted = 0',
 [$slug]
 );
 if (!$restaurant) { http_response_code(404); require __DIR__ . '/../views/shared/404.php'; return; }

 if ($restaurant['is_suspended']) {
 require __DIR__ . '/../views/public/suspended.php';
 return;
 }

 $starFilter = (int)($_GET['stars'] ?? 0);
 $reviewSql = 'SELECT * FROM reviews WHERE restaurant_id = ?';
 $reviewParams = [$restaurant['id']];
 if ($starFilter >= 1 && $starFilter <= 5) {
 $reviewSql .= ' AND rating = ?';
 $reviewParams[] = $starFilter;
 }
 $reviewSql .= ' ORDER BY created_at DESC';
 $reviews = Database::fetchAll($reviewSql, $reviewParams);

 // Rating counts per star
 $ratingCounts = [];
 for ($i = 1; $i <= 5; $i++) {
 $ratingCounts[$i] = Database::fetch(
 'SELECT COUNT(*) as c FROM reviews WHERE restaurant_id = ? AND rating = ?',
 [$restaurant['id'], $i]
 )['c'];
 }

 require __DIR__ . '/../views/public/restaurant_profile.php';
 }

 public static function apiSubmitReview(): void {
 if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => 'Method not allowed'], 405);

 $token = sanitize($_POST['order_token'] ?? '');
 $rating = (int)($_POST['rating'] ?? 0);
 $text = sanitize($_POST['review_text'] ?? '');

 if (!$token || $rating < 1 || $rating > 5) jsonResponse(['error' => 'Invalid data'], 400);

 $order = Database::fetch('SELECT * FROM orders WHERE temp_token = ? AND status = "completed"', [$token]);
 if (!$order) jsonResponse(['error' => 'Order not found or not completed'], 404);
 if ($order['review_submitted']) jsonResponse(['error' => 'Review already submitted'], 409);

 Database::insert(
 'INSERT INTO reviews (restaurant_id, order_id, customer_name, rating, review_text) VALUES (?, ?, ?, ?, ?)',
 [$order['restaurant_id'], $order['id'], $order['customer_name'], $rating, $text]
 );

 Database::execute('UPDATE orders SET review_submitted = 1 WHERE id = ?', [$order['id']]);

 // Update restaurant rating
 $stats = Database::fetch(
 'SELECT AVG(rating) as avg_r, COUNT(*) as cnt FROM reviews WHERE restaurant_id = ?',
 [$order['restaurant_id']]
 );
 Database::execute(
 'UPDATE restaurants SET rating = ?, total_reviews = ? WHERE id = ?',
 [round((float)$stats['avg_r'], 2), (int)$stats['cnt'], $order['restaurant_id']]
 );

 jsonResponse(['success' => true]);
 }
}
