<?php
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/helpers.php';
require_once __DIR__ . '/../../includes/ImageUpload.php';

class MenuController {

 // Owner management view
 public static function manage(int $restaurantId): void {
 $owner = Auth::requireOwner();
 Auth::requirePhoneVerified();
 $restaurant = self::ownedRestaurant($restaurantId, $owner['id']);
 $plan = Auth::getOwnerPlan();
 $categories = Database::fetchAll('SELECT * FROM menu_categories WHERE restaurant_id = ? ORDER BY sort_order, name', [$restaurantId]);
 $items = Database::fetchAll(
 'SELECT mi.*, mc.name as category_name FROM menu_items mi
 LEFT JOIN menu_categories mc ON mi.category_id = mc.id
 WHERE mi.restaurant_id = ? ORDER BY mc.sort_order, mi.name',
 [$restaurantId]
 );
 $itemCount = count($items);
 $maxItems = planMaxMenuItems($plan);
 require __DIR__ . '/../views/owner/menu.php';
 }

 // Public menu page
 public static function publicMenu(string $slug): void {
 $restaurant = Database::fetch(
 'SELECT * FROM restaurants WHERE slug = ? AND is_deleted = 0', [$slug]
 );
 if (!$restaurant) { http_response_code(404); require __DIR__ . '/../views/shared/404.php'; return; }
 if ($restaurant['is_suspended']) { require __DIR__ . '/../views/public/suspended.php'; return; }

 $categories = Database::fetchAll(
 'SELECT * FROM menu_categories WHERE restaurant_id = ? ORDER BY sort_order, name', [$restaurant['id']]
 );
 $items = Database::fetchAll(
 'SELECT mi.*, mc.name as category_name FROM menu_items mi
 LEFT JOIN menu_categories mc ON mi.category_id = mc.id
 WHERE mi.restaurant_id = ? AND mi.is_available = 1
 ORDER BY mc.sort_order, mi.name',
 [$restaurant['id']]
 );
 require __DIR__ . '/../views/public/menu.php';
 }

 // Form-based add item (POST from owner menu view)
 public static function addItem(int $restaurantId): void {
 $owner = Auth::requireOwner();
 Auth::requirePhoneVerified();
 $restaurant = self::ownedRestaurant($restaurantId, $owner['id']);
 $plan = Auth::getOwnerPlan();
 $maxItems = planMaxMenuItems($plan);
 $current = (int)Database::fetch('SELECT COUNT(*) as c FROM menu_items WHERE restaurant_id = ?', [$restaurantId])['c'];
 $error = '';

 if (!verifyCsrf()) { $error = 'Invalid request.'; }
 elseif ($current >= $maxItems) {
 $error = 'Menu item limit reached for your plan. Upgrade to add more.';
 } else {
 $name = sanitize($_POST['name'] ?? '');
 $price = (float)($_POST['price'] ?? 0);
 $desc = sanitize($_POST['description'] ?? '');
 $categoryId = (int)($_POST['category_id'] ?? 0) ?: null;
 if (!$name || $price <= 0) { $error = 'Name and price are required.'; }
 else {
 $image = null;
 if (!empty($_FILES['image']['tmp_name'])) {
 $image = ImageUpload::uploadAndConvertToWebP($_FILES['image'], MENU_UPLOAD_PATH);
 }
 Database::insert(
 'INSERT INTO menu_items (restaurant_id, category_id, name, image, price, description) VALUES (?,?,?,?,?,?)',
 [$restaurantId, $categoryId, $name, $image, $price, $desc]
 );
 }
 }
 redirect('/owner/restaurants/' . $restaurantId . '/menu' . ($error ? '?error=' . urlencode($error) : '?success=1'));
 }

 // Form-based edit item
 public static function editItem(int $restaurantId, int $itemId): void {
 $owner = Auth::requireOwner();
 Auth::requirePhoneVerified();
 $restaurant = self::ownedRestaurant($restaurantId, $owner['id']);
 $item = Database::fetch('SELECT * FROM menu_items WHERE id = ? AND restaurant_id = ?', [$itemId, $restaurantId]);
 if (!$item) redirect('/owner/restaurants/' . $restaurantId . '/menu');

 if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf()) {
 $name = sanitize($_POST['name'] ?? $item['name']);
 $price = (float)($_POST['price'] ?? $item['price']);
 $desc = sanitize($_POST['description'] ?? '');
 $categoryId = (int)($_POST['category_id'] ?? 0) ?: null;
 $image = $item['image'];
 if (!empty($_FILES['image']['tmp_name'])) {
 $newImg = ImageUpload::uploadAndConvertToWebP($_FILES['image'], MENU_UPLOAD_PATH);
 if ($newImg) {
 if ($image) ImageUpload::deleteFile(MENU_UPLOAD_PATH . $image);
 $image = $newImg;
 }
 }
 Database::execute(
 'UPDATE menu_items SET name=?, price=?, description=?, category_id=?, image=?, updated_at=NOW() WHERE id=?',
 [$name, $price, $desc, $categoryId, $image, $itemId]
 );
 }
 redirect('/owner/restaurants/' . $restaurantId . '/menu');
 }

 // Form-based delete item (AJAX-friendly JSON response)
 public static function deleteItem(int $restaurantId, int $itemId): void {
 $owner = Auth::requireOwner();
 self::ownedRestaurant($restaurantId, $owner['id']);
 if (!verifyCsrf()) jsonResponse(['error' => 'Invalid request'], 403);
 $item = Database::fetch('SELECT * FROM menu_items WHERE id = ? AND restaurant_id = ?', [$itemId, $restaurantId]);
 if (!$item) jsonResponse(['error' => 'Not found'], 404);
 if ($item['image']) ImageUpload::deleteFile(MENU_UPLOAD_PATH . $item['image']);
 Database::execute('DELETE FROM menu_items WHERE id = ?', [$itemId]);
 jsonResponse(['success' => true]);
 }

 // Form-based add category
 public static function addCategory(int $restaurantId): void {
 $owner = Auth::requireOwner();
 self::ownedRestaurant($restaurantId, $owner['id']);
 $plan = Auth::getOwnerPlan();
 if (!planHas($plan, 'categories')) redirect('/owner/restaurants/' . $restaurantId . '/menu');
 if (verifyCsrf()) {
 $name = sanitize($_POST['name'] ?? '');
 if ($name) {
 Database::insert('INSERT INTO menu_categories (restaurant_id, name) VALUES (?, ?)', [$restaurantId, $name]);
 }
 }
 redirect('/owner/restaurants/' . $restaurantId . '/menu');
 }

 // Form-based delete category
 public static function deleteCategory(int $restaurantId, int $catId): void {
 $owner = Auth::requireOwner();
 self::ownedRestaurant($restaurantId, $owner['id']);
 if (!verifyCsrf()) redirect('/owner/restaurants/' . $restaurantId . '/menu');
 Database::execute('UPDATE menu_items SET category_id = NULL WHERE category_id = ? AND restaurant_id = ?', [$catId, $restaurantId]);
 Database::execute('DELETE FROM menu_categories WHERE id = ? AND restaurant_id = ?', [$catId, $restaurantId]);
 redirect('/owner/restaurants/' . $restaurantId . '/menu');
 }

 public static function apiItems(): void {
 $owner = Auth::requireOwner();
 $restaurantId = (int)($_GET['restaurant_id'] ?? 0);
 self::ownedRestaurant($restaurantId, $owner['id']);
 $items = Database::fetchAll(
 'SELECT mi.*, mc.name as category_name FROM menu_items mi
 LEFT JOIN menu_categories mc ON mi.category_id = mc.id
 WHERE mi.restaurant_id = ? ORDER BY mc.sort_order, mi.name',
 [$restaurantId]
 );
 jsonResponse(['items' => $items]);
 }

 public static function apiAddCategory(): void {
 $owner = Auth::requireOwner();
 if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => 'Method not allowed'], 405);
 $restaurantId = (int)($_POST['restaurant_id'] ?? 0);
 $restaurant = self::ownedRestaurant($restaurantId, $owner['id']);
 $plan = Auth::getOwnerPlan();
 if (!planHas($plan, 'categories')) jsonResponse(['error' => 'Categories require Basic or Premium plan'], 403);
 $name = sanitize($_POST['name'] ?? '');
 if (!$name) jsonResponse(['error' => 'Name required'], 400);
 $id = Database::insert('INSERT INTO menu_categories (restaurant_id, name) VALUES (?, ?)', [$restaurantId, $name]);
 jsonResponse(['success' => true, 'id' => $id, 'name' => $name]);
 }

 public static function apiDeleteCategory(): void {
 $owner = Auth::requireOwner();
 if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => 'Method not allowed'], 405);
 $catId = (int)($_POST['category_id'] ?? 0);
 $restaurantId = (int)($_POST['restaurant_id'] ?? 0);
 self::ownedRestaurant($restaurantId, $owner['id']);
 Database::execute('UPDATE menu_items SET category_id = NULL WHERE category_id = ?', [$catId]);
 Database::execute('DELETE FROM menu_categories WHERE id = ? AND restaurant_id = ?', [$catId, $restaurantId]);
 jsonResponse(['success' => true]);
 }

 public static function apiAddItem(): void {
 $owner = Auth::requireOwner();
 if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => 'Method not allowed'], 405);
 $restaurantId = (int)($_POST['restaurant_id'] ?? 0);
 self::ownedRestaurant($restaurantId, $owner['id']);
 $plan = Auth::getOwnerPlan();
 $maxItems = planMaxMenuItems($plan);
 $current = (int)Database::fetch('SELECT COUNT(*) as c FROM menu_items WHERE restaurant_id = ?', [$restaurantId])['c'];
 if ($current >= $maxItems) jsonResponse(['error' => 'Menu item limit reached for your plan. Upgrade to add more.'], 403);

 $name = sanitize($_POST['name'] ?? '');
 $price = (float)($_POST['price'] ?? 0);
 $desc = sanitize($_POST['description'] ?? '');
 $categoryId = (int)($_POST['category_id'] ?? 0) ?: null;

 if (!$name || $price <= 0) jsonResponse(['error' => 'Name and price required'], 400);

 $image = null;
 if (!empty($_FILES['image']['tmp_name'])) {
 $image = ImageUpload::uploadAndConvertToWebP($_FILES['image'], MENU_UPLOAD_PATH);
 }

 $id = Database::insert(
 'INSERT INTO menu_items (restaurant_id, category_id, name, image, price, description) VALUES (?,?,?,?,?,?)',
 [$restaurantId, $categoryId, $name, $image, $price, $desc]
 );

 $item = Database::fetch(
 'SELECT mi.*, mc.name as category_name FROM menu_items mi
 LEFT JOIN menu_categories mc ON mi.category_id = mc.id WHERE mi.id = ?', [$id]
 );
 jsonResponse(['success' => true, 'item' => $item, 'image_url' => $image ? UPLOAD_URL . 'menu/' . $image : '']);
 }

 public static function apiEditItem(): void {
 $owner = Auth::requireOwner();
 if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => 'Method not allowed'], 405);
 $itemId = (int)($_POST['item_id'] ?? 0);
 $restaurantId = (int)($_POST['restaurant_id'] ?? 0);
 self::ownedRestaurant($restaurantId, $owner['id']);
 $item = Database::fetch('SELECT * FROM menu_items WHERE id = ? AND restaurant_id = ?', [$itemId, $restaurantId]);
 if (!$item) jsonResponse(['error' => 'Item not found'], 404);

 $name = sanitize($_POST['name'] ?? $item['name']);
 $price = (float)($_POST['price'] ?? $item['price']);
 $desc = sanitize($_POST['description'] ?? $item['description'] ?? '');
 $categoryId = (int)($_POST['category_id'] ?? 0) ?: null;

 $image = $item['image'];
 if (!empty($_FILES['image']['tmp_name'])) {
 $newImg = ImageUpload::uploadAndConvertToWebP($_FILES['image'], MENU_UPLOAD_PATH);
 if ($newImg) {
 if ($image) ImageUpload::deleteFile(MENU_UPLOAD_PATH . $image);
 $image = $newImg;
 }
 }
 Database::execute(
 'UPDATE menu_items SET name=?, price=?, description=?, category_id=?, image=?, updated_at=NOW() WHERE id=?',
 [$name, $price, $desc, $categoryId, $image, $itemId]
 );
 jsonResponse(['success' => true, 'image_url' => $image ? UPLOAD_URL . 'menu/' . $image : '']);
 }

 public static function apiDeleteItem(): void {
 $owner = Auth::requireOwner();
 if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => 'Method not allowed'], 405);
 $itemId = (int)($_POST['item_id'] ?? 0);
 $restaurantId = (int)($_POST['restaurant_id'] ?? 0);
 self::ownedRestaurant($restaurantId, $owner['id']);
 $item = Database::fetch('SELECT * FROM menu_items WHERE id = ? AND restaurant_id = ?', [$itemId, $restaurantId]);
 if (!$item) jsonResponse(['error' => 'Item not found'], 404);
 if ($item['image']) ImageUpload::deleteFile(MENU_UPLOAD_PATH . $item['image']);
 Database::execute('DELETE FROM menu_items WHERE id = ?', [$itemId]);
 jsonResponse(['success' => true]);
 }

 private static function ownedRestaurant(int $id, int $ownerId): array {
 $r = Database::fetch('SELECT * FROM restaurants WHERE id = ? AND owner_id = ? AND is_deleted = 0', [$id, $ownerId]);
 if (!$r) jsonResponse(['error' => 'Restaurant not found'], 404);
 return $r;
 }
}
