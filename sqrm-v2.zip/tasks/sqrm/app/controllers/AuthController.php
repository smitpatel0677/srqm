<?php
require_once __DIR__ . '/../../config/app.php';
require_once __DIR__ . '/../../config/google.php';
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/helpers.php';

class AuthController {

 public static function ownerLogin(): void {
 if (Auth::isOwnerLoggedIn()) redirect('/owner/dashboard');
 require __DIR__ . '/../views/auth/owner_login.php';
 }

 public static function googleRedirect(): void {
 $state = bin2hex(random_bytes(16));
 $_SESSION['oauth_state'] = $state;
 $params = http_build_query([
 'client_id' => GOOGLE_CLIENT_ID,
 'redirect_uri' => GOOGLE_REDIRECT_URI,
 'response_type' => 'code',
 'scope' => 'openid email profile',
 'state' => $state,
 'access_type' => 'online',
 ]);
 redirect(GOOGLE_AUTH_URL . '?' . $params);
 }

 public static function googleCallback(): void {
 $code = $_GET['code'] ?? '';
 $state = $_GET['state'] ?? '';

 if (!$code || !hash_equals($_SESSION['oauth_state'] ?? '', $state)) {
 redirect('/owner/login?error=invalid_state');
 }
 unset($_SESSION['oauth_state']);

 // Exchange code for token
 $tokenRes = self::httpPost(GOOGLE_TOKEN_URL, [
 'code' => $code,
 'client_id' => GOOGLE_CLIENT_ID,
 'client_secret' => GOOGLE_CLIENT_SECRET,
 'redirect_uri' => GOOGLE_REDIRECT_URI,
 'grant_type' => 'authorization_code',
 ]);
 $token = json_decode($tokenRes, true);
 if (empty($token['access_token'])) redirect('/owner/login?error=token_failed');

 // Get user info
 $userRes = self::httpGet(GOOGLE_USERINFO_URL, $token['access_token']);
 $userInfo = json_decode($userRes, true);
 if (empty($userInfo['sub'])) redirect('/owner/login?error=userinfo_failed');

 $googleId = $userInfo['sub'];
 $email = $userInfo['email'];
 $name = $userInfo['name'];
 $avatar = $userInfo['picture'] ?? '';

 // Upsert owner
 $owner = Database::fetch('SELECT * FROM owners WHERE google_id = ?', [$googleId]);
 if (!$owner) {
 $id = Database::insert(
 'INSERT INTO owners (google_id, name, email, avatar) VALUES (?, ?, ?, ?)',
 [$googleId, $name, $email, $avatar]
 );
 $owner = Database::fetch('SELECT * FROM owners WHERE id = ?', [$id]);
 } else {
 Database::execute('UPDATE owners SET name = ?, avatar = ? WHERE id = ?', [$name, $avatar, $owner['id']]);
 $owner = Database::fetch('SELECT * FROM owners WHERE id = ?', [$owner['id']]);
 }

 if ($owner['is_suspended']) {
 redirect('/owner/login?error=suspended');
 }

 Auth::loginOwner($owner);

 if (!$owner['phone_verified']) {
 redirect('/owner/verify-phone');
 }
 redirect('/owner/dashboard');
 }

 public static function verifyPhone(): void {
 $owner = Auth::requireOwner();
 if ($owner['phone_verified']) redirect('/owner/dashboard');

 $error = '';
 $success = '';

 if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 if (!verifyCsrf()) { $error = 'Invalid request.'; }
 else {
 $phone = preg_replace('/\D/', '', trim($_POST['phone'] ?? ''));
 if (strlen($phone) < 10) {
 $error = 'Please enter a valid 10-digit phone number.';
 } elseif (in_array($phone, FAKE_PHONES)) {
 $error = 'This phone number is not accepted. Please use a real number.';
 } else {
 Database::execute('UPDATE owners SET phone = ?, phone_verified = 1 WHERE id = ?', [$phone, $owner['id']]);
 // Refresh session
 $fresh = Database::fetch('SELECT * FROM owners WHERE id = ?', [$owner['id']]);
 Auth::loginOwner($fresh);
 redirect('/owner/dashboard');
 }
 }
 }
 require __DIR__ . '/../views/auth/verify_phone.php';
 }

 public static function ownerLogout(): void {
 Auth::logout();
 redirect('/');
 }

 // ── HTTP helpers ──────────────────────────────────────

 private static function httpPost(string $url, array $data): string {
 $ch = curl_init($url);
 curl_setopt_array($ch, [
 CURLOPT_RETURNTRANSFER => true,
 CURLOPT_POST => true,
 CURLOPT_POSTFIELDS => http_build_query($data),
 CURLOPT_SSL_VERIFYPEER => true,
 CURLOPT_TIMEOUT => 15,
 ]);
 $res = curl_exec($ch);
 curl_close($ch);
 return $res ?: '';
 }

 private static function httpGet(string $url, string $bearerToken): string {
 $ch = curl_init($url);
 curl_setopt_array($ch, [
 CURLOPT_RETURNTRANSFER => true,
 CURLOPT_HTTPHEADER => ["Authorization: Bearer $bearerToken"],
 CURLOPT_SSL_VERIFYPEER => true,
 CURLOPT_TIMEOUT => 15,
 ]);
 $res = curl_exec($ch);
 curl_close($ch);
 return $res ?: '';
 }
}
