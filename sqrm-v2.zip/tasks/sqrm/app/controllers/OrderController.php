<?php
require_once __DIR__ . '/../../includes/Database.php';
require_once __DIR__ . '/../../includes/Auth.php';
require_once __DIR__ . '/../../includes/helpers.php';

class OrderController {

 public static function cart(): void {
 // Cart is rendered client-side; this page just bootstraps
 $restaurantSlug = sanitize($_GET['restaurant'] ?? '');
 if (!$restaurantSlug) redirect('/');
 $restaurant = Database::fetch('SELECT * FROM restaurants WHERE slug = ? AND is_deleted = 0 AND is_suspended = 0', [$restaurantSlug]);
 if (!$restaurant) redirect('/');
 require __DIR__ . '/../views/public/cart.php';
 }

 public static function trackOrder(string $token): void {
 $order = Database::fetch(
 'SELECT o.*, r.name as restaurant_name, r.phone as restaurant_phone, r.logo as restaurant_logo,
 r.slug as restaurant_slug, r.payment_info
 FROM orders o JOIN restaurants r ON o.restaurant_id = r.id
 WHERE o.temp_token = ?',
 [$token]
 );
 if (!$order) { http_response_code(404); require __DIR__ . '/../views/shared/404.php'; return; }
 $order['items_decoded'] = json_decode($order['items_json'], true);
 require __DIR__ . '/../views/public/order_track.php';
 }

 public static function ownerOrders(int $restaurantId): void {
 $owner = Auth::requireOwner();
 Auth::requirePhoneVerified();
 $restaurant = Database::fetch('SELECT * FROM restaurants WHERE id = ? AND owner_id = ? AND is_deleted = 0', [$restaurantId, $owner['id']]);
 if (!$restaurant) { http_response_code(403); die('Not found.'); }
 $plan = Auth::getOwnerPlan();
 $statusFilter = sanitize($_GET['status'] ?? '');
 $sql = 'SELECT * FROM orders WHERE restaurant_id = ?';
 $params = [$restaurantId];
 if ($statusFilter && in_array($statusFilter, ['pending','accepted','rejected','completed'])) {
 $sql .= ' AND status = ?';
 $params[] = $statusFilter;
 }
 $sql .= ' ORDER BY created_at DESC';
 if (!planHas($plan, 'order_history')) $sql .= ' LIMIT 20';
 $orders = Database::fetchAll($sql, $params);
 foreach ($orders as &$order) {
 $order['items_decoded'] = json_decode($order['items_json'], true);
 }
 require __DIR__ . '/../views/owner/orders.php';
 }

 // ── API ───────────────────────────────────────────────

 public static function apiPlace(): void {
 if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => 'Method not allowed'], 405);

 $restaurantId = (int)($_POST['restaurant_id'] ?? 0);
 $customerName = sanitize($_POST['customer_name'] ?? '');
 $customerPhone = sanitize($_POST['customer_phone'] ?? '');
 $paymentMethod = in_array($_POST['payment_method'] ?? '', ['online','cash']) ? $_POST['payment_method'] : 'cash';
 $itemsJson = $_POST['items_json'] ?? '';

 if (!$restaurantId || !$customerName || !$customerPhone || !$itemsJson) {
 jsonResponse(['error' => 'Missing required fields'], 400);
 }

 $items = json_decode($itemsJson, true);
 if (!$items || !is_array($items)) jsonResponse(['error' => 'Invalid items'], 400);

 // Verify restaurant
 $restaurant = Database::fetch('SELECT * FROM restaurants WHERE id = ? AND is_deleted = 0 AND is_suspended = 0', [$restaurantId]);
 if (!$restaurant) jsonResponse(['error' => 'Restaurant not found'], 404);

 // Calculate total
 $subtotal = 0;
 foreach ($items as $item) {
 $subtotal += (float)($item['price'] ?? 0) * (int)($item['qty'] ?? 1);
 }

 $token = generateToken(32);
 $id = Database::insert(
 'INSERT INTO orders (restaurant_id, temp_token, customer_name, customer_phone, payment_method, items_json, subtotal) VALUES (?,?,?,?,?,?,?)',
 [$restaurantId, $token, $customerName, $customerPhone, $paymentMethod, json_encode($items), $subtotal]
 );

 jsonResponse(['success' => true, 'token' => $token, 'order_id' => $id]);
 }

 public static function apiStatus(): void {
 $token = sanitize($_GET['token'] ?? '');
 if (!$token) jsonResponse(['error' => 'Token required'], 400);
 $order = Database::fetch(
 'SELECT o.status, o.rejection_reason, o.review_submitted, o.subtotal, o.items_json,
 r.phone as restaurant_phone, r.name as restaurant_name, r.payment_info
 FROM orders o JOIN restaurants r ON o.restaurant_id = r.id
 WHERE o.temp_token = ?',
 [$token]
 );
 if (!$order) jsonResponse(['error' => 'Order not found'], 404);
 jsonResponse($order);
 }

 public static function apiUpdate(): void {
 $owner = Auth::requireOwner();
 if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonResponse(['error' => 'Method not allowed'], 405);

 $orderId = (int)($_POST['order_id'] ?? 0);
 // Accept both 'status' (from views) and 'action' (legacy) params
 $status = sanitize($_POST['status'] ?? $_POST['action'] ?? '');
 $reason = sanitize($_POST['rejection_reason'] ?? $_POST['reason'] ?? '');

 $order = Database::fetch('SELECT * FROM orders WHERE id = ?', [$orderId]);
 if (!$order) jsonResponse(['error' => 'Order not found'], 404);

 // Verify ownership
 $restaurant = Database::fetch('SELECT * FROM restaurants WHERE id = ? AND owner_id = ?', [$order['restaurant_id'], $owner['id']]);
 if (!$restaurant) jsonResponse(['error' => 'Unauthorized'], 403);

 // Normalise: accept 'accept'/'complete' action words too
 $newStatus = match($status) {
 'accepted', 'accept' => 'accepted',
 'rejected', 'reject' => 'rejected',
 'completed', 'complete', 'given' => 'completed',
 default => null,
 };
 if (!$newStatus) jsonResponse(['error' => 'Invalid status'], 400);
 if ($newStatus === 'rejected' && !$reason) jsonResponse(['error' => 'Rejection reason required'], 400);

 Database::execute(
 'UPDATE orders SET status = ?, rejection_reason = ?, updated_at = NOW() WHERE id = ?',
 [$newStatus, $reason, $orderId]
 );

 jsonResponse(['success' => true, 'status' => $newStatus]);
 }

 public static function apiBill(): void {
 $owner = Auth::requireOwner();
 $orderId = (int)($_GET['order_id'] ?? 0);
 $order = Database::fetch(
 'SELECT o.*, r.name AS restaurant_name, r.phone AS restaurant_phone,
 r.logo AS restaurant_logo, r.location AS restaurant_location
 FROM orders o JOIN restaurants r ON o.restaurant_id = r.id
 WHERE o.id = ? AND r.owner_id = ?',
 [$orderId, $owner['id']]
 );
 if (!$order) jsonResponse(['error' => 'Order not found'], 404);

 $items = json_decode($order['items_json'], true) ?: [];
 $logoUrl = $order['restaurant_logo']
 ? APP_URL . '/uploads/logos/' . $order['restaurant_logo']
 : '';

 ob_start();
 ?>
 <div style="font-family:Arial,sans-serif;max-width:380px;margin:0 auto;padding:1.5rem;background:#fff;color:#1a1a2e;">
 <div style="text-align:center;margin-bottom:1rem;">
 <?php if ($logoUrl): ?>
 <img src="<?= htmlspecialchars($logoUrl) ?>" style="height:56px;border-radius:50%;object-fit:cover;margin-bottom:.5rem;" crossorigin="anonymous"/>
 <?php endif; ?>
 <h2 style="margin:0;font-size:1.1rem;font-weight:800;"><?= htmlspecialchars($order['restaurant_name']) ?></h2>
 <p style="margin:.25rem 0 0;font-size:.82rem;color:#555;"><?= htmlspecialchars($order['restaurant_location']) ?></p>
 <p style="margin:.1rem 0 0;font-size:.82rem;color:#555;"><?= htmlspecialchars($order['restaurant_phone']) ?></p>
 </div>
 <hr style="border:none;border-top:2px dashed #ddd;margin:.75rem 0;"/>
 <div style="font-size:.78rem;color:#888;margin-bottom:.5rem;">
 Order: #<?= substr($order['temp_token'], 0, 8) ?> &nbsp;|&nbsp; <?= date('d M Y H:i', strtotime($order['created_at'])) ?>
 </div>
 <div style="font-size:.85rem;margin-bottom:.5rem;">
 Customer: <strong><?= htmlspecialchars($order['customer_name']) ?></strong> &nbsp; <?= htmlspecialchars($order['customer_phone']) ?>
 </div>
 <div style="font-size:.82rem;color:#555;margin-bottom:.75rem;">Payment: <?= ucfirst($order['payment_method']) ?></div>
 <hr style="border:none;border-top:1px solid #ddd;margin:.75rem 0;"/>
 <table style="width:100%;font-size:.875rem;border-collapse:collapse;">
 <thead>
 <tr style="border-bottom:1px solid #eee;">
 <th style="text-align:left;padding:.3rem 0;font-weight:600;">Item</th>
 <th style="text-align:center;padding:.3rem 0;font-weight:600;">Qty</th>
 <th style="text-align:right;padding:.3rem 0;font-weight:600;">Amount</th>
 </tr>
 </thead>
 <tbody>
 <?php foreach ($items as $item): ?>
 <tr>
 <td style="padding:.3rem 0;"><?= htmlspecialchars($item['name']) ?></td>
 <td style="text-align:center;padding:.3rem 0;">×<?= (int)$item['qty'] ?></td>
 <td style="text-align:right;padding:.3rem 0;">₹<?= number_format($item['price'] * $item['qty'], 2) ?></td>
 </tr>
 <?php endforeach; ?>
 </tbody>
 </table>
 <hr style="border:none;border-top:2px solid #1a1a2e;margin:.75rem 0;"/>
 <div style="display:flex;justify-content:space-between;font-weight:800;font-size:1rem;">
 <span>Total</span><span>₹<?= number_format($order['subtotal'], 2) ?></span>
 </div>
 <hr style="border:none;border-top:2px dashed #ddd;margin:1rem 0;"/>
 <p style="font-size:.72rem;color:#aaa;text-align:center;line-height:1.5;">
 This bill is Generated by Saksham Digital Menu.<br/>
 This is not an official receipt. Ask original bill from owner.
 </p>
 <p style="font-size:.7rem;color:#ccc;text-align:center;margin-top:.35rem;">Powered by SQRM</p>
 </div>
 <?php
 $html = ob_get_clean();
 jsonResponse(['success' => true, 'bill_html' => $html]);
 }
 $owner = Auth::requireOwner();
 $restaurantId = (int)($_GET['restaurant_id'] ?? 0);
 $restaurant = Database::fetch('SELECT id FROM restaurants WHERE id = ? AND owner_id = ?', [$restaurantId, $owner['id']]);
 if (!$restaurant) jsonResponse(['error' => 'Unauthorized'], 403);

 $count = Database::fetch('SELECT COUNT(*) as c FROM orders WHERE restaurant_id = ? AND status = "pending"', [$restaurantId])['c'];
 $orders = Database::fetchAll(
 'SELECT id, customer_name, customer_phone, subtotal, payment_method, items_json, created_at FROM orders WHERE restaurant_id = ? AND status = "pending" ORDER BY created_at ASC',
 [$restaurantId]
 );
 jsonResponse(['pending_count' => (int)$count, 'orders' => $orders]);
 }
}
