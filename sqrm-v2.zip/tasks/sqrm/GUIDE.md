# SQRM — Saksham Digital Menu
## Complete Setup & Developer Guide

> **Version:** 1.0.0  
> **Domain:** sqrm.srpdigitalstudios.qzz.io  
> **Stack:** PHP 8+, MySQL 5.7+, Vanilla JS, CSS3, PWA

---

## Table of Contents

1. [Overview](#1-overview)
2. [System Requirements](#2-system-requirements)
3. [Project Structure](#3-project-structure)
4. [Installation](#4-installation)
5. [Configuration](#5-configuration)
6. [Database Setup](#6-database-setup)
7. [Google OAuth Setup](#7-google-oauth-setup)
8. [Web Server Configuration](#8-web-server-configuration)
9. [First-Time Admin Setup](#9-first-time-admin-setup)
10. [Feature Reference](#10-feature-reference)
11. [URL / Route Reference](#11-url--route-reference)
12. [API Endpoints](#12-api-endpoints)
13. [Subscription Plans](#13-subscription-plans)
14. [File Uploads & WebP Conversion](#14-file-uploads--webp-conversion)
15. [PWA & Offline Support](#15-pwa--offline-support)
16. [Order Flow](#16-order-flow)
17. [QR Code System](#17-qr-code-system)
18. [Dark Mode](#18-dark-mode)
19. [Deployment Checklist](#19-deployment-checklist)
20. [Security Notes](#20-security-notes)
21. [Troubleshooting](#21-troubleshooting)

---

## 1. Overview

**Saksham Digital Menu (SQRM)** is a complete digital QR-menu platform for restaurant owners.

### For Restaurant Owners
- Login with Google, create restaurants, upload menus with images
- Generate branded QR codes for tables
- Receive and manage customer orders in real time (with sound notifications)
- Download PDF bills per order
- View revenue analytics (daily/monthly/lifetime based on plan)

### For Customers
- Scan QR code → browse menu → add to cart → place order
- Real-time order status tracking (Pending → Accepted/Rejected → Completed)
- Receive PDF bill after order completion
- Leave star ratings and written reviews

### For Super Admin
- Manage all owners, assign subscription plans
- Suspend/reactivate restaurants
- Moderate reviews
- Configure site settings (name, logo, support contact)
- Enable maintenance mode

---

## 2. System Requirements

| Requirement | Minimum |
|-------------|---------|
| PHP | 8.0+ |
| MySQL | 5.7+ (or MariaDB 10.4+) |
| PHP Extensions | `pdo_mysql`, `gd` (for WebP), `curl`, `json`, `session`, `mbstring` |
| Web Server | Apache (mod_rewrite) or Nginx |
| SSL Certificate | Required for Google OAuth & PWA |
| Disk Space | 512 MB minimum (for uploads) |

---

## 3. Project Structure

```
sqrm/
├── index.php                   # Front controller / router (ALL requests)
├── config/
│   ├── app.php                 # App constants (URL, upload paths, plan limits)
│   ├── database.php            # DB credentials
│   └── google.php              # Google OAuth credentials
├── includes/
│   ├── Database.php            # PDO singleton wrapper
│   ├── Auth.php                # Session, owner/admin auth helpers
│   ├── Settings.php            # Site settings read/write
│   ├── ImageUpload.php         # WebP image conversion & upload
│   └── helpers.php             # csrf(), view(), starHtml(), timeAgo(), planMaxItems()
├── app/
│   ├── controllers/
│   │   ├── AdminController.php     # Admin panel (login, owners, restaurants, reviews, settings)
│   │   ├── AuthController.php      # Google OAuth, phone verification, logout
│   │   ├── HomeController.php      # Home page, sitemap
│   │   ├── MenuController.php      # Owner menu management + public menu API
│   │   ├── OrderController.php     # Cart, order placement, tracking, PDF bill
│   │   ├── OwnerController.php     # Owner dashboard, profile, account deletion
│   │   ├── PublicController.php    # Public restaurant list & profile, review submission
│   │   ├── QRController.php        # QR code page
│   │   └── RestaurantController.php # Owner restaurant CRUD
│   └── views/
│       ├── admin/
│       │   ├── layout.php          # Admin sidebar layout (dark navy sidebar)
│       │   ├── layout_end.php      # Closes admin layout
│       │   ├── login.php
│       │   ├── dashboard.php
│       │   ├── owners.php
│       │   ├── owner_detail.php
│       │   ├── restaurants.php
│       │   ├── reviews.php
│       │   └── settings.php
│       ├── auth/
│       │   ├── owner_login.php     # Google OAuth button
│       │   └── verify_phone.php    # Phone verification form
│       ├── home/
│       │   ├── index.php           # Landing page (hero, plans, features)
│       │   ├── privacy.php
│       │   ├── cookie.php
│       │   └── sitemap.php         # XML sitemap output
│       ├── owner/
│       │   ├── dashboard.php
│       │   ├── restaurants.php
│       │   ├── restaurant_create.php
│       │   ├── restaurant_edit.php
│       │   ├── menu.php
│       │   ├── orders.php
│       │   ├── profile.php
│       │   └── qr.php
│       ├── public/
│       │   ├── restaurants.php     # /restaurants search page
│       │   ├── restaurant_profile.php  # /r/{slug}
│       │   ├── menu.php            # /m/{slug}
│       │   ├── cart.php
│       │   ├── order_track.php
│       │   └── suspended.php
│       └── shared/
│           ├── header.php          # HTML head + offline banner
│           ├── footer.php          # Footer + PWA install banner
│           ├── 404.php
│           └── maintenance.php
├── public/
│   ├── assets/
│   │   ├── css/style.css           # Main stylesheet (dark mode, responsive)
│   │   ├── js/app.js               # Vanilla JS (theme, cart, polling, toasts, modals)
│   │   ├── images/                 # icon-192.png, icon-512.png, og-banner.png, placeholder.webp
│   │   └── sounds/ding.mp3         # New order notification sound
│   ├── uploads/
│   │   ├── logos/                  # Restaurant logos (WebP)
│   │   ├── menu/                   # Menu item images (WebP)
│   │   └── site/                   # Site logo (uploaded by admin)
│   ├── manifest.json               # PWA manifest
│   ├── sw.js                       # Service worker (cache-first, offline fallback)
│   └── offline.html                # Offline fallback page
└── sql/
    └── schema.sql                  # Full database schema (run once on new install)
```

---

## 4. Installation

### Step 1: Upload Files
Upload the entire `sqrm/` directory to your web server root (e.g., `/var/www/html/sqrm` or the domain's `public_html`).

### Step 2: Set Permissions
```bash
chmod -R 755 sqrm/
chmod -R 777 sqrm/public/uploads/
```

### Step 3: Create Upload Directories
```bash
mkdir -p sqrm/public/uploads/logos
mkdir -p sqrm/public/uploads/menu
mkdir -p sqrm/public/uploads/site
chmod 777 sqrm/public/uploads/logos
chmod 777 sqrm/public/uploads/menu
chmod 777 sqrm/public/uploads/site
```

### Step 4: Configure (see Section 5)

### Step 5: Run Database Schema (see Section 6)

### Step 6: Create Admin Account (see Section 9)

---

## 5. Configuration

### `config/database.php`
```php
define('DB_HOST', 'localhost');     // Database host
define('DB_NAME', 'sqrm_db');       // Database name
define('DB_USER', 'root');          // Database username
define('DB_PASS', '');              // Database password
define('DB_CHARSET', 'utf8mb4');
```

### `config/app.php`
```php
define('APP_URL', 'https://sqrm.srpdigitalstudios.qzz.io');  // Change to your domain
define('APP_NAME', 'Saksham Digital Menu');
```
> **Important:** `APP_URL` must be HTTPS for Google OAuth and PWA to work. No trailing slash.

### `config/google.php`
```php
define('GOOGLE_CLIENT_ID',     'YOUR_GOOGLE_CLIENT_ID');
define('GOOGLE_CLIENT_SECRET', 'YOUR_GOOGLE_CLIENT_SECRET');
// GOOGLE_REDIRECT_URI is auto-set to APP_URL . '/auth/google/callback'
```
> See Section 7 for how to get these values.

---

## 6. Database Setup

### Create the database and run the schema:
```bash
mysql -u root -p
```
```sql
CREATE DATABASE IF NOT EXISTS sqrm_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
exit;
```
```bash
mysql -u root -p sqrm_db < sqrm/sql/schema.sql
```

### Tables Created
| Table | Purpose |
|-------|---------|
| `site_settings` | Key-value store for site configuration |
| `admins` | Admin panel users (email + bcrypt password) |
| `owners` | Restaurant owners (Google OAuth) |
| `restaurants` | Restaurant profiles |
| `menu_categories` | Menu categories per restaurant |
| `menu_items` | Menu items with images and prices |
| `orders` | Customer orders with status tracking |
| `order_items` | Line items per order |
| `reviews` | Customer star ratings and written reviews |

---

## 7. Google OAuth Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project (or use existing)
3. Navigate to **APIs & Services → Credentials**
4. Click **Create Credentials → OAuth 2.0 Client ID**
5. Application type: **Web application**
6. Add Authorized redirect URIs:
   ```
   https://sqrm.srpdigitalstudios.qzz.io/auth/google/callback
   ```
7. Copy the **Client ID** and **Client Secret**
8. Paste them into `config/google.php`

> **Note:** The OAuth consent screen must be configured. Add your domain to "Authorized domains". For production, verify the domain and publish the app.

---

## 8. Web Server Configuration

### Apache (recommended)

Create or update `.htaccess` in the `sqrm/` root directory:

```apache
Options -Indexes
RewriteEngine On

# Serve static files directly
RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

# Route everything else through index.php
RewriteRule ^ index.php [L]
```

Also ensure `mod_rewrite` is enabled:
```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

Your Apache VirtualHost should have `AllowOverride All`:
```apache
<Directory /var/www/html/sqrm>
    AllowOverride All
    Require all granted
</Directory>
```

### Nginx

```nginx
server {
    listen 443 ssl;
    server_name sqrm.srpdigitalstudios.qzz.io;
    root /var/www/html/sqrm;
    index index.php;

    # Static files
    location /public/ {
        try_files $uri $uri/ =404;
    }

    # Route all requests through front controller
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/run/php/php8.1-fpm.sock;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    # Security: block direct access to config/includes
    location ~ ^/(config|includes|app|sql)/ {
        deny all;
        return 404;
    }
}
```

> **Note:** If your web root is set directly to the `sqrm/` folder (not a subfolder), static assets in `public/assets/` are served directly by the web server. The PHP router only handles non-file requests.

---

## 9. First-Time Admin Setup

After running the schema, create the first admin account:

```bash
php -r "
require 'sqrm/config/database.php';
require 'sqrm/includes/Database.php';
\$hash = password_hash('your_secure_password', PASSWORD_DEFAULT);
Database::insert(
  'INSERT INTO admins (email, password) VALUES (?, ?)',
  ['admin@yourdomain.com', \$hash]
);
echo 'Admin created.';
"
```

Or run directly in MySQL:
```sql
INSERT INTO admins (email, password)
VALUES ('admin@yourdomain.com', '$2y$10$REPLACE_WITH_BCRYPT_HASH');
```

Then login at: `https://sqrm.srpdigitalstudios.qzz.io/admin1`

> **URL note:** `/admin` returns a 404. Admin login is only at `/admin1`.

---

## 10. Feature Reference

### Owner Features

| Feature | Free | Basic | Premium |
|---------|------|-------|---------|
| Restaurants | 1 | 5 | Unlimited |
| Menu Items | 20 | Unlimited | Unlimited |
| QR Code Generation | ✅ | ✅ | ✅ |
| Customer Ordering | ✅ | ✅ | ✅ |
| Live Order Tracking | ✅ | ✅ | ✅ |
| Daily & Monthly Earnings | ✅ | ✅ | ✅ |
| Customer Ratings & Reviews | ✅ | ✅ | ✅ |
| PDF Receipt per Order | ✅ | ✅ | ✅ |
| Monthly Analytics Dashboard | ❌ | ✅ | ✅ |
| Best Selling Items Report | ❌ | ✅ | ✅ |
| Menu Categories | ❌ | ✅ | ✅ |
| Order History & Filters | ❌ | ✅ | ✅ |
| Lifetime Analytics | ❌ | ❌ | ✅ |
| Popular Categories Insights | ❌ | ❌ | ✅ |
| Most Active Hours Report | ❌ | ❌ | ✅ |
| Custom Restaurant Theme Color | ❌ | ❌ | ✅ |

### Plan Upgrade Flow
Clicking **Basic** or **Premium** plan on the homepage redirects to WhatsApp:
```
https://wa.me/{WHATSAPP_NUMBER}?text=I+would+like+to+purchase+Basic+plan
```
The WhatsApp number is set in Admin → Settings → WhatsApp Number (include country code, e.g. `919876543210`).

---

## 11. URL / Route Reference

### Public
| URL | Description |
|-----|-------------|
| `/` | Homepage (hero, search, plans, features) |
| `/restaurants` | Search all restaurants |
| `/r/{slug}` | Restaurant public profile + reviews |
| `/m/{slug}` | Restaurant menu page (cart + ordering) |
| `/cart` | Cart & order placement |
| `/order/{token}` | Order status tracking |
| `/privacy-policy` | Privacy policy |
| `/cookie-policy` | Cookie policy |
| `/sitemap.xml` | XML sitemap (auto-generated) |

### Owner (require Google login + phone verification)
| URL | Description |
|-----|-------------|
| `/owner/login` | Google OAuth login |
| `/owner/dashboard` | Owner home |
| `/owner/profile` | Edit profile, delete account |
| `/owner/restaurants` | List all restaurants |
| `/owner/restaurants/create` | Create new restaurant |
| `/owner/restaurants/{id}/edit` | Edit restaurant |
| `/owner/restaurants/{id}/menu` | Manage menu items & categories |
| `/owner/restaurants/{id}/orders` | Live order management |
| `/owner/restaurants/{id}/qr` | QR code generator & download |

### Admin (email + password, `/admin1` only)
| URL | Description |
|-----|-------------|
| `/admin1` | Admin login |
| `/admin1/dashboard` | Stats overview |
| `/admin1/owners` | All owners + plan assignment |
| `/admin1/owners/{id}` | Owner detail + their restaurants |
| `/admin1/restaurants` | Suspend/reactivate restaurants |
| `/admin1/reviews` | Review moderation |
| `/admin1/settings` | Site name, logo, support info, maintenance mode |

---

## 12. API Endpoints

All API endpoints return JSON. CSRF token required for POST requests (pass as `csrf_token` form field).

### Customer / Public
| Method | URL | Description |
|--------|-----|-------------|
| `POST` | `/api/order/place` | Place a new order |
| `GET`  | `/api/order/status?token={token}` | Poll order status |
| `POST` | `/api/review/submit` | Submit a review after order completion |

### Owner
| Method | URL | Description |
|--------|-----|-------------|
| `POST` | `/api/order/update` | Accept/reject/complete an order |
| `GET`  | `/api/orders/pending?restaurant_id={id}` | Poll pending order count (for sound alert) |
| `GET`  | `/api/menu/items?restaurant_id={id}` | Get menu items |
| `POST` | `/api/menu/item/add` | Add menu item |
| `POST` | `/api/menu/item/edit` | Edit menu item |
| `POST` | `/api/menu/item/delete` | Delete menu item |
| `POST` | `/api/menu/category/add` | Add category |
| `POST` | `/api/menu/category/delete` | Delete category |
| `GET`  | `/api/order/bill?order_id={id}` | Get HTML bill for PDF export |

### Admin
| Method | URL | Description |
|--------|-----|-------------|
| `POST` | `/admin1/reviews/delete` | Delete a review (with `review_id`) |
| `POST` | `/admin1/owners/assign-plan` | Assign plan to owner |
| `POST` | `/admin1/restaurants/{id}/suspend` | Suspend restaurant |
| `POST` | `/admin1/restaurants/{id}/reactivate` | Reactivate restaurant |
| `POST` | `/admin1/settings/maintenance` | Toggle maintenance mode |

---

## 13. Subscription Plans

Plans are assigned by the super admin. They auto-expire **30 days** after assignment.

```
Plan: free   → free forever
Plan: basic  → ₹29/month, expires 30 days from assignment
Plan: premium → ₹49/month, expires 30 days from assignment
```

When a plan expires, the system falls back to `free` limits. Features not available in the current plan are displayed as locked/blurred overlays in the owner dashboard.

To manually extend a plan, the admin simply re-assigns it (resets the 30-day clock).

---

## 14. File Uploads & WebP Conversion

All uploaded images (restaurant logos and menu item images) are automatically converted to **WebP format** using PHP's GD library.

**Conversion rules:**
- Supported input: JPEG, PNG, GIF, WEBP, BMP
- Output: `.webp` at 80% quality
- Max file size: 5 MB
- Images saved to `public/uploads/logos/` or `public/uploads/menu/`

**Ensure GD is enabled:**
```bash
php -m | grep gd
```
If missing, install it:
```bash
sudo apt install php8.1-gd   # Ubuntu/Debian
sudo yum install php-gd      # CentOS/RHEL
```

**Site logo** (uploaded by admin) is saved to `public/uploads/site/`.

---

## 15. PWA & Offline Support

SQRM is a full **Progressive Web App** (PWA).

### Features
- **Add to Home Screen** — prompt shown to mobile users (dismissible, stored in `localStorage`)
- **Service Worker** (`/sw.js`) — network-first strategy with cache fallback
- **Offline banner** — yellow banner shown when `navigator.onLine` is false; disappears on reconnect
- **Offline page** (`/offline.html`) — shown when navigation request fails with no cache

### Cache Strategy
- Static assets cached on install (`style.css`, `app.js`, `offline.html`)
- Dynamic pages cached on first visit (network-first)
- API endpoints (`/api/*`) are never cached

### To update the service worker cache version:
In `public/sw.js`, increment the cache names:
```js
const CACHE_NAME   = 'sqrm-v2';   // bump this
const STATIC_CACHE = 'sqrm-static-v2';
```

---

## 16. Order Flow

```
Customer at table
    │
    ▼
Scans QR code ──► /m/{slug} (Menu Page)
    │
    ▼
Adds items to cart (stored in localStorage)
    │
    ▼
/cart — enters Name, Phone, Payment Method
    │         (Online shows owner payment info; no gateway)
    ▼
POST /api/order/place
    │
    ▼
Redirect to /order/{unique_token}
    │
    ▼ (polls /api/order/status every 3s)
Status: PENDING
    │
    ▼ (Owner dashboard polls /api/orders/pending every 4s)
Owner hears ding.mp3 (new order sound)
    │
   [Owner clicks Accept]          [Owner clicks Reject]
    │                                     │
    ▼                                     ▼
Status: ACCEPTED                   Owner enters reason
    │                              Status: REJECTED
    │                              Customer sees reason
    │                              + restaurant phone number
    │
   [Owner clicks Given/Completed]
    │
    ▼
Status: COMPLETED
PDF bill available for download (client-side jsPDF)
Review popup shown to customer (optional)
```

### Order Status Values
| Status | Meaning |
|--------|---------|
| `pending` | Submitted, waiting for owner |
| `accepted` | Owner accepted the order |
| `rejected` | Owner rejected (with reason) |
| `completed` | Order delivered, bill generated |

---

## 17. QR Code System

QR codes are generated client-side using **QRCode.js** (loaded from CDN on the QR page).

### Branded QR Design Includes:
- Restaurant logo (circular, with orange border)
- Restaurant name
- Location
- Phone number
- QR code canvas (links to `/m/{slug}`)
- "By Saksham Digital Menu" branding text

### Download Options
| Format | How |
|--------|-----|
| PNG | `canvas.toDataURL()` → `<a download>` |
| PDF | `jsPDF` → captures QR card with `html2canvas` → saves PDF |

Both downloads are entirely **client-side** — no server processing required.

---

## 18. Dark Mode

Dark mode is implemented via the `data-theme` HTML attribute:

```html
<html data-theme="light">  <!-- or "dark" -->
```

The theme is toggled by clicking the 🌙/☀️ button in the navbar and persisted in `localStorage` under the key `sqrm_theme`.

CSS variables switch automatically:
```css
:root { --bg: #ffffff; --text: #1a1a2e; ... }
[data-theme="dark"] { --bg: #111827; --text: #f3f4f6; ... }
```

The theme is applied **before page paint** (inline script in `<html>` load) to prevent flash.

---

## 19. Deployment Checklist

- [ ] PHP 8.0+ installed with `pdo_mysql`, `gd`, `curl`, `mbstring`
- [ ] MySQL database created and schema imported
- [ ] `config/database.php` updated with production credentials
- [ ] `config/app.php` — `APP_URL` set to HTTPS domain
- [ ] `config/google.php` — Google Client ID and Secret filled in
- [ ] Google OAuth redirect URI registered in Google Cloud Console
- [ ] `.htaccess` (Apache) or `nginx.conf` configured for URL rewriting
- [ ] `public/uploads/` and subdirectories writable (`chmod 777`)
- [ ] `public/assets/sounds/ding.mp3` file present
- [ ] PWA icons present: `public/assets/images/icon-192.png`, `icon-512.png`
- [ ] Admin account created in `admins` table
- [ ] HTTPS/SSL certificate active (required for Google OAuth + PWA)
- [ ] `/admin` URL returns 404 (not `/admin1`)
- [ ] Test QR code generation and download
- [ ] Test order placement and real-time status update
- [ ] Test image upload and WebP conversion

---

## 20. Security Notes

| Feature | Implementation |
|---------|---------------|
| CSRF Protection | All POST forms include `csrf_token` (generated via `csrf()` helper, stored in session) |
| SQL Injection | All queries use PDO prepared statements |
| XSS | All output uses `htmlspecialchars()` |
| File Upload | Validates MIME type via `getimagesize()`, only accepts image/* types |
| Admin Auth | bcrypt password hashing via `password_hash()` / `password_verify()` |
| Owner Auth | Google OAuth only — no passwords stored |
| Session | Regenerated on login to prevent fixation |
| Fake Phones | Rejects known fake numbers (1234567890, 0987654321, 9876543210) |
| Admin URL | `/admin` → 404; real admin only at `/admin1` |
| Direct File Access | Block `config/`, `includes/`, `app/`, `sql/` via web server rules |

### Recommended: Block sensitive directories in Apache `.htaccess`
```apache
# In sqrm/.htaccess — already included, verify these exist:
<FilesMatch "\.(php)$">
    Order Allow,Deny
    Allow from all
</FilesMatch>

# Block direct access to source directories
RewriteRule ^(config|includes|app|sql)/ - [F,L]
```

---

## 21. Troubleshooting

### "Database connection failed"
- Check `config/database.php` credentials
- Ensure MySQL is running: `sudo systemctl status mysql`
- Verify the database and user exist: `mysql -u root -p -e "SHOW DATABASES;"`

### Google OAuth not working
- Verify `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` in `config/google.php`
- Confirm the redirect URI in Google Console **exactly matches** `APP_URL . '/auth/google/callback'`
- HTTPS is required — OAuth will fail on HTTP

### Images not uploading / WebP conversion failing
- Confirm PHP GD extension: `php -m | grep gd`
- Check upload folder permissions: `ls -la public/uploads/`
- Ensure max upload size in `php.ini`: `upload_max_filesize = 10M`, `post_max_size = 12M`

### QR code not generating
- Confirm internet access (QRCode.js and jsPDF load from CDN)
- Check browser console for JS errors
- For offline use, download and self-host QRCode.js

### Sound alert not playing
- Browser requires a user interaction before audio can play
- Confirm `public/assets/sounds/ding.mp3` exists
- Check the `<audio id="ding-audio">` tag is present in the orders page

### 404 on all pages except homepage
- `.htaccess` not being read — ensure `AllowOverride All` in Apache config
- `mod_rewrite` not enabled — run `sudo a2enmod rewrite && sudo systemctl restart apache2`

### Maintenance mode locked out
- Log in directly at `/admin1` — maintenance mode does **not** block the admin panel
- Or disable via MySQL: `UPDATE site_settings SET setting_value='0' WHERE setting_key='maintenance_mode';`

### Session issues / login loops
- Verify `session.save_path` is writable in `php.ini`
- Check that `APP_URL` domain exactly matches the browser URL (no www vs non-www mismatch)

---

## Support

For platform support or plan upgrades, contact the admin via the Support Email configured in Admin → Settings.

---

*Saksham Digital Menu (SQRM) — Built with ❤️ for the food & restaurant industry.*
