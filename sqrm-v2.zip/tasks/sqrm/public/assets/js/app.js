/* ============================================================
   SQRM – app.js  |  Vanilla JS, no frameworks
   ============================================================ */

// ── Theme ─────────────────────────────────────────────────────
(function(){
  const saved = localStorage.getItem('sqrm_theme') || 'light';
  document.documentElement.setAttribute('data-theme', saved);
})();

document.addEventListener('DOMContentLoaded', () => {

  // Theme toggle
  document.querySelectorAll('.theme-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const cur = document.documentElement.getAttribute('data-theme');
      const next = cur === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem('sqrm_theme', next);
      updateThemeIcon();
    });
  });

  function updateThemeIcon() {
    const dark = document.documentElement.getAttribute('data-theme') === 'dark';
    document.querySelectorAll('.theme-toggle .theme-icon').forEach(el => {
      el.innerHTML = dark ? '&#9728;' : '&#9790;';
    });
  }
  updateThemeIcon();

  // ── Sidebar / Mobile Nav ───────────────────────────────────
  const hamburger = document.querySelector('.hamburger');
  const sidebar   = document.querySelector('.sidebar, .admin-sidebar');
  const overlay   = document.querySelector('.sidebar-overlay');

  function openSidebar() {
    sidebar?.classList.add('open');
    overlay?.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeSidebar() {
    sidebar?.classList.remove('open');
    overlay?.classList.remove('open');
    document.body.style.overflow = '';
  }

  hamburger?.addEventListener('click', openSidebar);
  overlay?.addEventListener('click', closeSidebar);
  sidebar?.querySelectorAll('a').forEach(a => a.addEventListener('click', closeSidebar));

  // ── Offline Banner ─────────────────────────────────────────
  const offlineBanner = document.getElementById('offline-banner');
  function updateOnlineStatus() {
    if (!navigator.onLine) {
      offlineBanner?.classList.remove('hidden');
    } else {
      offlineBanner?.classList.add('hidden');
    }
  }
  window.addEventListener('online',  updateOnlineStatus);
  window.addEventListener('offline', updateOnlineStatus);
  updateOnlineStatus();

  // ── PWA Install ────────────────────────────────────────────
  let deferredPrompt = null;
  const pwaBanner   = document.getElementById('pwa-install-banner');
  const installBtn  = document.getElementById('pwa-install-btn');
  const dismissBtn  = document.getElementById('pwa-dismiss-btn');

  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    if (!localStorage.getItem('pwa_dismissed')) {
      pwaBanner?.classList.remove('hidden');
    }
  });

  installBtn?.addEventListener('click', async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') pwaBanner?.classList.add('hidden');
    deferredPrompt = null;
  });

  dismissBtn?.addEventListener('click', () => {
    pwaBanner?.classList.add('hidden');
    localStorage.setItem('pwa_dismissed', '1');
  });

  // ── Service Worker ─────────────────────────────────────────
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }

  // ── Toast System ───────────────────────────────────────────
  window.showToast = function(msg, type='default', duration=3000) {
    let container = document.querySelector('.toasts');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toasts';
      document.body.appendChild(container);
    }
    const t = document.createElement('div');
    t.className = 'toast' + (type !== 'default' ? ` toast-${type}` : '');
    t.textContent = msg;
    container.appendChild(t);
    setTimeout(() => t.remove(), duration + 300);
  };

  // ── Modal Helpers ──────────────────────────────────────────
  window.openModal = function(id) {
    const m = document.getElementById(id);
    m?.classList.remove('hidden');
  };
  window.closeModal = function(id) {
    const m = document.getElementById(id);
    m?.classList.add('hidden');
  };

  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.classList.add('hidden');
    });
  });

  document.querySelectorAll('[data-modal-close]').forEach(btn => {
    btn.addEventListener('click', () => btn.closest('.modal-overlay')?.classList.add('hidden'));
  });

  // ── Star Rating Input ──────────────────────────────────────
  document.querySelectorAll('.stars-input').forEach(container => {
    const stars = container.querySelectorAll('span');
    const input = container.closest('form')?.querySelector('input[name="rating"]');
    stars.forEach((star, i) => {
      star.addEventListener('mouseenter', () => {
        stars.forEach((s, j) => s.classList.toggle('active', j <= i));
      });
      star.addEventListener('click', () => {
        if (input) input.value = i + 1;
        stars.forEach((s, j) => s.dataset.selected = j <= i ? '1' : '0');
      });
    });
    container.addEventListener('mouseleave', () => {
      const val = parseInt(input?.value || '0');
      stars.forEach((s, j) => s.classList.toggle('active', j < val));
    });
  });

  // ── Image preview on upload ────────────────────────────────
  document.querySelectorAll('input[type="file"][data-preview]').forEach(input => {
    input.addEventListener('change', () => {
      const previewId = input.getAttribute('data-preview');
      const preview   = document.getElementById(previewId);
      if (!preview || !input.files[0]) return;
      const reader = new FileReader();
      reader.onload = e => {
        if (preview.tagName === 'IMG') preview.src = e.target.result;
        else preview.style.backgroundImage = `url(${e.target.result})`;
        preview.classList.remove('hidden');
      };
      reader.readAsDataURL(input.files[0]);
    });
  });

  // ── Lazy loading ───────────────────────────────────────────
  if ('IntersectionObserver' in window) {
    const lazyImages = document.querySelectorAll('img[data-src]');
    const io = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          io.unobserve(img);
        }
      });
    }, { rootMargin: '200px' });
    lazyImages.forEach(img => io.observe(img));
  }

  // ── Confirm Delete ─────────────────────────────────────────
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', e => {
      if (!confirm(el.dataset.confirm || 'Are you sure?')) e.preventDefault();
    });
  });

  // ── Auto-hide alerts ───────────────────────────────────────
  document.querySelectorAll('.alert[data-auto-hide]').forEach(el => {
    setTimeout(() => el.remove(), parseInt(el.dataset.autoHide || '4000'));
  });

});

// ── Cart System ────────────────────────────────────────────────
const SQRM = {
  cart: {},
  restaurantId: null,
  restaurantSlug: null,

  init(restaurantId, restaurantSlug) {
    this.restaurantId   = restaurantId;
    this.restaurantSlug = restaurantSlug;
    const saved = localStorage.getItem(`sqrm_cart_${restaurantId}`);
    if (saved) {
      try { this.cart = JSON.parse(saved); } catch(e) { this.cart = {}; }
    }
    this.renderAll();
  },

  save() {
    localStorage.setItem(`sqrm_cart_${this.restaurantId}`, JSON.stringify(this.cart));
  },

  addItem(id, name, price, imageUrl) {
    if (this.cart[id]) {
      this.cart[id].qty++;
    } else {
      this.cart[id] = { id, name, price: parseFloat(price), qty: 1, image: imageUrl || '' };
    }
    this.save();
    this.renderItem(id);
    this.renderCartBar();
  },

  removeOne(id) {
    if (!this.cart[id]) return;
    this.cart[id].qty--;
    if (this.cart[id].qty <= 0) delete this.cart[id];
    this.save();
    this.renderItem(id);
    this.renderCartBar();
  },

  getTotal() {
    return Object.values(this.cart).reduce((s, i) => s + i.price * i.qty, 0);
  },

  getCount() {
    return Object.values(this.cart).reduce((s, i) => s + i.qty, 0);
  },

  renderItem(id) {
    const container = document.querySelector(`[data-item-id="${id}"]`);
    if (!container) return;
    const qty = this.cart[id]?.qty || 0;
    const addBtn = container.querySelector('.add-item-btn');
    const qtyCtrl= container.querySelector('.qty-control');
    const qtyNum = container.querySelector('.qty-num');
    if (qty > 0) {
      addBtn?.classList.add('hidden');
      qtyCtrl?.classList.remove('hidden');
      if (qtyNum) qtyNum.textContent = qty;
    } else {
      addBtn?.classList.remove('hidden');
      qtyCtrl?.classList.add('hidden');
    }
  },

  renderAll() {
    document.querySelectorAll('[data-item-id]').forEach(container => {
      this.renderItem(container.dataset.itemId);
    });
    this.renderCartBar();
  },

  renderCartBar() {
    const bar   = document.getElementById('cart-bar');
    const count = this.getCount();
    const total = this.getTotal();
    if (!bar) return;
    if (count > 0) {
      bar.classList.add('visible');
      const el = bar.querySelector('.cart-bar-info .count');
      const tl = bar.querySelector('.cart-bar-info .total');
      if (el) el.textContent = `${count} item${count > 1 ? 's' : ''}`;
      if (tl) tl.textContent = `₹${total.toFixed(2)}`;
    } else {
      bar.classList.remove('visible');
    }
  },

  goToCart() {
    if (this.getCount() === 0) {
      showToast('Your cart is empty.', 'error');
      return;
    }
    window.location.href = `/cart?restaurant=${this.restaurantSlug}`;
  },

  getCartForOrder() {
    return Object.values(this.cart).map(i => ({
      id: i.id, name: i.name, price: i.price, qty: i.qty, image: i.image
    }));
  },

  clearCart() {
    this.cart = {};
    this.save();
    this.renderAll();
  }
};

// ── Order Polling ──────────────────────────────────────────────
function pollOrderStatus(token, onUpdate) {
  let lastStatus = null;
  const interval = setInterval(async () => {
    try {
      const res  = await fetch(`/api/order/status?token=${encodeURIComponent(token)}`);
      const data = await res.json();
      if (data.status && data.status !== lastStatus) {
        lastStatus = data.status;
        onUpdate(data);
      }
      if (['completed','rejected'].includes(data.status)) {
        clearInterval(interval);
      }
    } catch(e) {}
  }, 3000);
  return interval;
}

// ── Owner Order Polling (with sound) ──────────────────────────
function pollPendingOrders(restaurantId, onNewOrder) {
  let lastCount = -1;
  const interval = setInterval(async () => {
    try {
      const res  = await fetch(`/api/orders/pending?restaurant_id=${restaurantId}`);
      const data = await res.json();
      if (lastCount >= 0 && data.pending_count > lastCount) {
        // New orders arrived
        const audio = document.getElementById('ding-audio');
        if (audio) { audio.currentTime = 0; audio.play().catch(() => {}); }
        onNewOrder(data);
      }
      if (lastCount !== data.pending_count) {
        lastCount = data.pending_count;
        onNewOrder(data);
      }
    } catch(e) {}
  }, 4000);
  return interval;
}
