<?php
// Google OAuth Configuration
// Set your Google Client ID and Secret here
define('GOOGLE_CLIENT_ID', '872690469008-s3tvqrs0tsqok0us8ohhhbpk8hk31rrk.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', APP_URL . '/auth/google/callback');
define('GOOGLE_AUTH_URL', 'https://accounts.google.com/o/oauth2/auth');
define('GOOGLE_TOKEN_URL', 'https://oauth2.googleapis.com/token');
define('GOOGLE_USERINFO_URL', 'https://www.googleapis.com/oauth2/v3/userinfo');
