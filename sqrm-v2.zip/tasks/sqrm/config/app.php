<?php
// Application Configuration
define('APP_NAME', 'Saksham Digital Menu');
define('APP_SHORT', 'SQRM');
define('APP_URL', 'https://sqrm.srpdigitalstudios.qzz.io');
define('APP_VERSION', '1.0.0');

// Upload paths
define('UPLOAD_PATH', __DIR__ . '/../public/uploads/');
define('UPLOAD_URL', APP_URL . '/uploads/');
define('LOGO_UPLOAD_PATH', UPLOAD_PATH . 'logos/');
define('MENU_UPLOAD_PATH', UPLOAD_PATH . 'menu/');
define('SITE_UPLOAD_PATH', UPLOAD_PATH . 'site/');

// Session
define('SESSION_NAME', 'sqrm_session');

// Plan limits
define('FREE_MAX_RESTAURANTS', 1);
define('FREE_MAX_MENU_ITEMS', 20);
define('BASIC_MAX_RESTAURANTS', 5);

// Fake phone numbers to reject
define('FAKE_PHONES', ['1234567890', '0987654321', '9876543210']);

// Timezone
date_default_timezone_set('Asia/Kolkata');
