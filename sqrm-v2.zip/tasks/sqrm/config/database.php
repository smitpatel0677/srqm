<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'srpdigit20_sqrm');
define('DB_USER', 'srpdigit20_sqrm');
define('DB_PASS', '15112010');
define('DB_CHARSET', 'utf8mb4');
