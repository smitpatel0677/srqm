<?php
require_once __DIR__ . '/Database.php';

class Settings {
 private static array $cache = [];

 public static function get(string $key, string $default = ''): string {
 if (!isset(self::$cache[$key])) {
 try {
 $row = Database::fetch('SELECT setting_value FROM site_settings WHERE setting_key = ?', [$key]);
 self::$cache[$key] = $row ? $row['setting_value'] : $default;
 } catch (Exception $e) {
 return $default;
 }
 }
 return self::$cache[$key] ?? $default;
 }

 public static function set(string $key, string $value): void {
 Database::execute(
 'INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?, updated_at = NOW()',
 [$key, $value, $value]
 );
 self::$cache[$key] = $value;
 }

 public static function isMaintenanceMode(): bool {
 return self::get('maintenance_mode', '0') === '1';
 }

 public static function getSiteName(): string {
 return self::get('site_name', 'Saksham Digital Menu');
 }

 public static function getSiteLogo(): string {
 $logo = self::get('site_logo', '');
 if ($logo && file_exists(SITE_UPLOAD_PATH . $logo)) {
 return UPLOAD_URL . 'site/' . $logo;
 }
 return '';
 }

 public static function getSupportNumber(): string {
 return self::get('support_number', '9876543210');
 }

 public static function getWhatsappNumber(): string {
 return self::get('whatsapp_number', '919876543210');
 }

 public static function getSupportEmail(): string {
 return self::get('support_email', 'support@sqrm.in');
 }

 public static function getAll(): array {
 try {
 $rows = Database::fetchAll('SELECT setting_key, setting_value FROM site_settings', []);
 $result = [];
 foreach ($rows as $row) {
 $result[$row['setting_key']] = $row['setting_value'];
 self::$cache[$row['setting_key']] = $row['setting_value'];
 }
 return $result;
 } catch (Exception $e) {
 return [];
 }
 }

 public static function clearCache(): void {
 self::$cache = [];
 }
}
