<?php
require_once __DIR__ . '/../config/database.php';

class Database {
 private static ?PDO $instance = null;

 public static function getInstance(): PDO {
 if (self::$instance === null) {
 $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
 $options = [
 PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
 PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
 PDO::ATTR_EMULATE_PREPARES => false,
 ];
 try {
 self::$instance = new PDO($dsn, DB_USER, DB_PASS, $options);
 } catch (PDOException $e) {
 die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
 }
 }
 return self::$instance;
 }

 public static function query(string $sql, array $params = []): PDOStatement {
 $stmt = self::getInstance()->prepare($sql);
 $stmt->execute($params);
 return $stmt;
 }

 public static function fetch(string $sql, array $params = []): ?array {
 return self::query($sql, $params)->fetch() ?: null;
 }

 public static function fetchAll(string $sql, array $params = []): array {
 return self::query($sql, $params)->fetchAll();
 }

 public static function insert(string $sql, array $params = []): int {
 self::query($sql, $params);
 return (int)self::getInstance()->lastInsertId();
 }

 public static function execute(string $sql, array $params = []): int {
 return self::query($sql, $params)->rowCount();
 }
}
