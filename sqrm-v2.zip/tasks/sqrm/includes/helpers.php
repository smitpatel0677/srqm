<?php
function slugify(string $text): string {
 $text = strtolower(trim($text));
 $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
 $text = preg_replace('/[\s-]+/', '-', $text);
 return trim($text, '-');
}

function uniqueSlug(string $table, string $base): string {
 $slug = slugify($base);
 $check = $slug;
 $i = 1;
 while (Database::fetch("SELECT id FROM $table WHERE slug = ?", [$check])) {
 $check = $slug . '-' . $i++;
 }
 return $check;
}

function generateToken(int $length = 32): string {
 return bin2hex(random_bytes($length));
}

function sanitize(string $input): string {
 return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function formatPrice(float $amount): string {
 return '₹' . number_format($amount, 2);
}

function timeAgo(string $datetime): string {
 $now = new DateTime();
 $then = new DateTime($datetime);
 $diff = $now->diff($then);
 if ($diff->y > 0) return $diff->y . ' year' . ($diff->y > 1 ? 's' : '') . ' ago';
 if ($diff->m > 0) return $diff->m . ' month' . ($diff->m > 1 ? 's' : '') . ' ago';
 if ($diff->d > 0) return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
 if ($diff->h > 0) return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
 if ($diff->i > 0) return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';
 return 'just now';
}

function redirect(string $url): never {
 header('Location: ' . $url);
 exit;
}

function isAjax(): bool {
 return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
 strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

function jsonResponse(array $data, int $code = 200): never {
 http_response_code($code);
 header('Content-Type: application/json');
 echo json_encode($data);
 exit;
}

function csrf(): string {
 if (empty($_SESSION['csrf_token'])) {
 $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
 }
 return $_SESSION['csrf_token'];
}

function verifyCsrf(): bool {
 $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
 return hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function starHtml(float $rating): string {
 $html = '';
 for ($i = 1; $i <= 5; $i++) {
 if ($rating >= $i) {
 $html .= '<span class="star filled"></span>';
 } elseif ($rating >= $i - 0.5) {
 $html .= '<span class="star half"></span>';
 } else {
 $html .= '<span class="star empty"></span>';
 }
 }
 return $html;
}

function planHas(string $ownerPlan, string $feature): bool {
 $features = [
 'free' => ['qr_code','digital_ordering','order_tracking','earnings_view','ratings_reviews','pdf_receipt'],
 'basic' => ['qr_code','digital_ordering','order_tracking','earnings_view','ratings_reviews','pdf_receipt',
 'monthly_analytics','best_selling','categories','order_history','order_filters'],
 'premium' => ['qr_code','digital_ordering','order_tracking','earnings_view','ratings_reviews','pdf_receipt',
 'monthly_analytics','best_selling','categories','order_history','order_filters',
 'lifetime_analytics','popular_categories','active_hours','custom_theme'],
 ];
 return in_array($feature, $features[$ownerPlan] ?? []);
}

function planMaxRestaurants(string $plan): int {
 return match($plan) {
 'basic' => BASIC_MAX_RESTAURANTS,
 'premium' => PHP_INT_MAX,
 default => FREE_MAX_RESTAURANTS,
 };
}

function planMaxMenuItems(string $plan): int {
 return match($plan) {
 'basic', 'premium' => PHP_INT_MAX,
 default => FREE_MAX_MENU_ITEMS,
 };
}

// Alias used in views
function planMaxItems(string $plan): int {
 return planMaxMenuItems($plan);
}

function view(string $path): string {
 return __DIR__ . '/../app/views/' . $path . '.php';
}

function getClientIP(): string {
 return $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}
