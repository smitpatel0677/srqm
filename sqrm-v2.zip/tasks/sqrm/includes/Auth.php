<?php
require_once __DIR__ . '/Database.php';

class Auth {
 public static function startSession(): void {
 if (session_status() === PHP_SESSION_NONE) {
 session_name(SESSION_NAME);
 session_start();
 }
 }

 public static function loginOwner(array $owner): void {
 self::startSession();
 $_SESSION['owner'] = [
 'id' => $owner['id'],
 'name' => $owner['name'],
 'email' => $owner['email'],
 'avatar' => $owner['avatar'],
 'plan' => $owner['plan'],
 'phone' => $owner['phone'],
 'phone_verified' => $owner['phone_verified'],
 ];
 }

 public static function loginAdmin(array $admin): void {
 self::startSession();
 $_SESSION['admin'] = ['id' => $admin['id'], 'email' => $admin['email']];
 }

 public static function isOwnerLoggedIn(): bool {
 self::startSession();
 return isset($_SESSION['owner']);
 }

 public static function isAdminLoggedIn(): bool {
 self::startSession();
 return isset($_SESSION['admin']);
 }

 public static function getOwner(): ?array {
 self::startSession();
 if (!isset($_SESSION['owner'])) return null;
 // Refresh from DB
 $owner = Database::fetch('SELECT * FROM owners WHERE id = ?', [$_SESSION['owner']['id']]);
 if ($owner) {
 $_SESSION['owner'] = [
 'id' => $owner['id'],
 'name' => $owner['name'],
 'email' => $owner['email'],
 'avatar' => $owner['avatar'],
 'plan' => $owner['plan'],
 'phone' => $owner['phone'],
 'phone_verified' => $owner['phone_verified'],
 ];
 }
 return $_SESSION['owner'] ?? null;
 }

 public static function getAdmin(): ?array {
 self::startSession();
 return $_SESSION['admin'] ?? null;
 }

 public static function requireOwner(): array {
 $owner = self::getOwner();
 if (!$owner) {
 header('Location: /owner/login');
 exit;
 }
 return $owner;
 }

 public static function requireAdmin(): array {
 $admin = self::getAdmin();
 if (!$admin) {
 header('Location: /admin1');
 exit;
 }
 return $admin;
 }

 public static function logout(): void {
 self::startSession();
 session_destroy();
 }

 public static function requirePhoneVerified(): void {
 $owner = self::getOwner();
 if ($owner && !$owner['phone_verified']) {
 header('Location: /owner/verify-phone');
 exit;
 }
 }

 public static function getOwnerPlan(): string {
 $owner = self::getOwner();
 if (!$owner) return 'free';
 // Check plan expiry
 $dbOwner = Database::fetch('SELECT plan, plan_expires_at FROM owners WHERE id = ?', [$owner['id']]);
 if ($dbOwner && $dbOwner['plan'] !== 'free' && $dbOwner['plan_expires_at']) {
 if (strtotime($dbOwner['plan_expires_at']) < time()) {
 Database::execute('UPDATE owners SET plan = "free", plan_expires_at = NULL WHERE id = ?', [$owner['id']]);
 return 'free';
 }
 }
 return $dbOwner['plan'] ?? 'free';
 }
}
