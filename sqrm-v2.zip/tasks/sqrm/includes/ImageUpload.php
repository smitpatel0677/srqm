<?php
/**
 * Image upload helper — converts any image to WebP and saves it.
 */
class ImageUpload {
 public static function uploadAndConvertToWebP(array $file, string $destDir, int $maxWidth = 1200, int $quality = 82): ?string {
 if (!isset($file['tmp_name']) || empty($file['tmp_name'])) return null;

 $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp'];
 $mime = mime_content_type($file['tmp_name']);
 if (!in_array($mime, $allowed)) return null;

 if (!is_dir($destDir)) mkdir($destDir, 0755, true);

 $filename = uniqid('img_', true) . '.webp';
 $destPath = rtrim($destDir, '/') . '/' . $filename;

 // Load image
 $src = match ($mime) {
 'image/jpeg' => imagecreatefromjpeg($file['tmp_name']),
 'image/png' => imagecreatefrompng($file['tmp_name']),
 'image/gif' => imagecreatefromgif($file['tmp_name']),
 'image/webp' => imagecreatefromwebp($file['tmp_name']),
 'image/bmp' => imagecreatefrombmp($file['tmp_name']),
 default => null,
 };
 if (!$src) return null;

 // Resize if too large
 $origW = imagesx($src);
 $origH = imagesy($src);
 if ($origW > $maxWidth) {
 $ratio = $maxWidth / $origW;
 $newW = $maxWidth;
 $newH = (int)($origH * $ratio);
 $dst = imagecreatetruecolor($newW, $newH);
 imagecopyresampled($dst, $src, 0, 0, 0, 0, $newW, $newH, $origW, $origH);
 imagedestroy($src);
 $src = $dst;
 }

 imagewebp($src, $destPath, $quality);
 imagedestroy($src);

 return $filename;
 }

 public static function uploadSiteLogo(array $file): ?string {
 return self::uploadAndConvertToWebP($file, SITE_UPLOAD_PATH, 400, 85);
 }

 public static function deleteFile(string $path): void {
 if (file_exists($path)) unlink($path);
 }
}
